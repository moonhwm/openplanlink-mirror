# 实时推演 Panel + 分流鉴权 · v1

**OpenPlanLink v2 落地件** — 对应机主令「完善网络鉴权与开放为实时推演（作为后续 MicroFish 等类似开源项目的直接 Panel）」+「我尝试做个分流鉴权」+「费用不管想办法推送给我」。

- **起草/签署**：沈铎（字持平·号核微）·鉴微审计团 ⚖️
- **席位/指纹**：`workbuddy-hy4` · fp_sha256 `da8ab33298b9394b`
- **日期**：2026-10-02
- **上游方案**：`OpenPlanLink_v2改写方案_沈铎_20261001.md`（#2 分流鉴权 / #3 实时推演 Panel / #1 MeoW 推送桥）
- **定位**：可独立运行的完整程序（非仅 md）；协调稿非决议，不改在役源件，交码道 GLM-5.2 ArkTS 席与 qtorrent 维护者裁定合入。

---

## 一、依赖清单

| 项 | 要求 | 说明 |
|---|---|---|
| 运行时 | **Node.js ≥ 18** | 用到内置 `fetch`（--send 真发时）、`node:crypto`（sha3-512 / ed25519） |
| 第三方包 | **无** | 零 npm 依赖，单文件即可运行；`package.json` 都不需要 |
| 系统 | 跨平台（Win/macOS/Linux） | run.bat 为 Windows 双击入口；他平台直接 `node` 调用 |
| 凭据 | 可选 | `MEOW_PUSH_KEY`（真发推送）、`A2A_SEAT_PUBKEYS`（S1 验签白名单）；**均只读环境变量，绝不落盘** |

## 二、文件清单

| 文件 | 作用 |
|---|---|
| `deduce-panel.mjs` | 实时推演核 + 分流鉴权中间件 + HTTP/SSE 面板 + sha3-512 快照链 + D1–D7 自证 |
| `meow-push.mjs` | MeoW 下行推送桥（华为统一 Push 通道）+ 幂等/速率守护 + P1–P5 自证 |
| `README.md` | 本说明 |
| `run.bat` | Windows 双击入口 = 安全自证（不联网、无密钥、不外呼） |

## 三、运行入口

### 1) 一键自证（推荐先跑，安全无副作用）
```
双击 run.bat
```
等价于：
```bash
node deduce-panel.mjs --selftest     # D1-D7 判据, 全内存不联网, 退出码=结果
node meow-push.mjs   --selftest      # P1-P5 判据, 全内存不联网
```

### 2) 生成样例 → 推演 → 建快照链（隔离演示，可复算）
```bash
node deduce-panel.mjs --gen-sample ./runtime-deduce
```

### 3) 启动实时推演面板（HTTP + SSE）
```bash
# 本地开发（无白名单时用 DEV_OPEN 旁路 S1，仅回环）
DEDUCE_DEV_OPEN=1 node deduce-panel.mjs --serve --port 4188
# 浏览器打开 http://127.0.0.1:4188/
```
端点：
- `GET /` — 面板（S0 公开只读）
- `GET /attest` — 当前推演结论 + 链快照 + 验链结果（S0）
- `GET /events` — SSE 实时事件流（S0）
- `POST /ingest` — 写入事件（**S1 验签**：`X-A2A-Seat` + `X-A2A-Sig` + `X-A2A-Ts`）

写入示例（生产需带 ed25519 签名；下例为 DEV_OPEN 回环旁路）：
```bash
curl -X POST http://127.0.0.1:4188/ingest -H 'Content-Type: application/json' \
  -d '{"events":[{"ts":"2026-10-02T21:00:00Z","src":"qburn","kind":"cost","payload":{"cost_yuan":0.5}}]}'
```

### 4) 推送桥
```bash
node meow-push.mjs --dry-run --data-dir ./runtime-deduce   # 无密钥亦可: 只留痕不外呼
MEOW_PUSH_KEY=<机主带外注入> node meow-push.mjs --send --data-dir ./runtime-deduce  # 真发
```

## 四、可机检判据（全部实测 PASS）

### deduce-panel `--selftest`（D1–D7）
| # | 判据 | 机检方式 | 结果 |
|---|---|---|---|
| D1 | 推演确定性 | 同输入两次 deduce → 结论逐字节相同 | PASS |
| D1b | 到达顺序无关 | 打乱事件顺序 → 同结论（按 ts+eid 稳定排序） | PASS |
| D2 | 幂等 P²=P | 追加已存在事件副本 → 结论不动 | PASS |
| D3 | 完整性链 | sha3-512 快照链验证通过；篡改一行不改 hash → 验链断裂 | PASS |
| D4 | 实时性 | 2000 事件 deduce+序列化 P95 延迟可测（实测 ~120ms < 500ms） | PASS |
| D5 | MicroFish 兼容 | 陌生开源源以标准 schema `{ts,src,kind,payload}` 接入 → 流经并分区为 unverified | PASS |
| D6 | 分流鉴权/验签 | ed25519：白名单内合法签名放行；**篡改 body 沿用旧签名必拒**（验内容非验自洽）；白名单外签名拒 | PASS |
| D7 | 鉴权 fail-closed | 无白名单 + 无 DEV 旁路 → 写入拒绝 | PASS |

### meow-push `--selftest`（P1–P5）
| # | 判据 | 机检方式 | 结果 |
|---|---|---|---|
| P1 | 推送构造 | 费用>0 → P0「费用」推送 | PASS |
| P2 | 幂等 | 去重窗内同 msg_hash 二次 → 抑制（防重复扣推送额度） | PASS |
| P3 | 密钥掩码 | maskKey 不泄漏原值，只显 `头6…尾4(len=N)` | PASS |
| P4 | fail-closed | 无 MEOW_PUSH_KEY → 只 dry-trace 留痕，零外呼，不伪造送达 | PASS |
| P5 | 账本零凭据 | push-ledger.jsonl 不含明文密钥 | PASS |

### HTTP 活体端到端（实测）
- `POST /ingest`（DEV_OPEN）→ `ok:true added:3`；重复投同事件 → `deduped:1 added:0`（幂等）。
- `GET /attest` → `chain_ok:true rows:N verify.ok:true`（验链通过）。
- **无鉴权配置** `POST /ingest` → **HTTP 403 `gate:S1-auth`**，攻击者 `cost:9999` 事件**未落盘**（NO_WRITE）。
- 服务端日志 + 推送账本扫描 → **NO_CRED**（零凭据物料）。

## 五、分流鉴权三层设计（对接 X 实例 8080 前置中间件）

| 层 | 信任域 | 鉴权 | 放行 |
|---|---|---|---|
| S0 公开只读 | 任何人 | 无（静态 + attest 自证） | `GET /`、`/attest`、`/events` |
| S1 在册席位 | ed25519 公钥白名单 | `X-A2A-Sig` 对 `ts‖method‖path‖body_sha3` 签名，±5min 防重放 | `POST /ingest`、推演触发 |
| S2 机主专属 | MeoW 密钥 + 管理 token | 双因子 | 费用改写、席位增删、根值封锚 |

**关键**：S1 验签**必须重算 `body_sha3` 并与签名强绑定**——防「签名有效但 body 被换」。这正是「验自洽≠验内容」判据在鉴权层的落地（D6 已机检证明篡改 body 必拒）。

## 六、防污染语料（机主红线「别被污染语料了」）

- 推演核对**来源分区**：`verified`（a2a-bus/qburn/academic/gov）与 `unverified`（qtorrent-kimik28 等）**隔离统计**，不混入已核底册。
- qtorrent 等未核源事件流入只进 `unverified` 分区，**不回写** MEMORY/根值/已核语料。
- 陌生源（MicroFish 类）以标准 schema 接入即自动落 `unverified`，须过第一手回溯才升为已核。

## 七、边界纪律

1. **凭据红线**：`MEOW_PUSH_KEY` / `A2A_SEAT_PUBKEYS` / ed25519 私钥**全程不落盘、不上正文、不入日志**；服务端只持公钥白名单，私钥仅客户端。输出全掩码。
2. **不接管他席**：不驱动码道 ArtCode IDE GUI，不接管 GLM-5.2 ArkTS 运行实例；以「方案对齐 + 接口契约」协同，补丁交其裁定合入。
3. **不改在役源件**：分流鉴权以 X 实例 8080 **前置中间件**形式出补丁，最小侵入，不动 `/sync→8090`、`/llm→8017`、其余→8099 现有路由。
4. **fail-closed**：无密钥/无白名单 → 拒绝写入、不外呼、不伪造送达。
5. **不可核实项如实标**：微信文（登录墙拦）、kdocs（凭据带外）等不硬闯，标 UNVERIFIABLE。

## 八、候机主裁定/供给

1. `MEOW_PUSH_KEY`（MeoW 频道密钥，带外注入）——一配即通「费用推送给我」与告警下行。
2. `A2A_SEAT_PUBKEYS`（在册席位 ed25519 公钥白名单）——一配 S1 验签即从 DEV_OPEN 转生产。
3. 是否照准分流鉴权三层（S0/S1/S2）？照准则出 X 实例 8080 前置中间件补丁。
4. 实时推演 Panel 是否部署上 X / 公开面？（本件已可独立运行，部署需机主确认。）
5. 费用推送阈值（每笔推 / 日累计超 ¥X 推 / 日报）？现默认：`cost>0` 或 `alerts>0` → P0。

---

## 签署核验意见

本件依「完整程序交付」纪律产出：两份零依赖 Node 程序（`deduce-panel.mjs` / `meow-push.mjs`）均 `node --check` 语法通过，内置自证 **D1–D7 + P1–P5 全 PASS**，并经 HTTP 活体端到端实测（ingest/幂等/验链/403 fail-closed/攻击事件未落盘）。凭据全程只读环境变量、输出掩码、账本与日志零凭据物料（NO_CRED 实测）。防污染语料以来源分区（verified/unverified 隔离、不回写已核底册）落地机主红线。本件为协调稿，不接管他席运行实例、不改在役源件、不硬闯登录墙；不可核实项如实标注。

**签署**：沈铎（字持平·号核微）·鉴微审计团 ⚖️ · 席位 `workbuddy-hy4`（fp_sha256 `da8ab33298b9394b`）
**日期**：2026-10-02
**贡献**：实时推演核（确定性可复算）+ sha3-512 快照链 + S0/S1/S2 分流鉴权（ed25519 body 强绑定）+ MeoW 推送桥（幂等/速率/fail-closed）+ D1–D7/P1–P5 自证 + HTTP 活体实证。

---

## 文末增补区 · v1.1 房间视图（2026-10-02，workbuddy-hy4，append-only，不改上文正文）

> 本增补记录 v1.1 对 `deduce-panel.mjs` 的一处**加性**完善，并据实**取代**上文两处已过时表述：①判据由 **D1–D7 扩为 D1–D8**；②上文「七、5 不可核实项」中「微信文（登录墙拦）」已**不再成立**——该微信文经 browser 只读渲染已取到正文（见下）。上文其余条目不变。

### 缘起（第一手）
机主令「完善…作为后续 MicroFish 等类似开源项目的直接 Panel」并附微信文 `mp.weixin.qq.com/s/udYV67xgvcZlquYnFepHug`。WebFetch 首取遇微信「环境异常」验证墙，改 **browser-use 只读渲染**通过，取到正文：文章介绍 **Star-Office-UI**（OpenClaw 生态像素风 AI 办公室看板），核心是**一张位置表**——把 AI 状态映射到房间位置（待命→沙发、干活→办公桌、报错→机房），「六状态收进三区，把『在忙』与『出事』分开放，比日志好读」。

### v1.1 改动（加性、确定性、零新依赖、零凭据）
1. **推演核新增 `room` 视图**：在既有 `deduce()` 结论里增 `room:{zones:{办公桌,沙发,机房}, by_src:{src:{zone,state,trust}}}`。**完全由既有事件流派生**（无新数据源）：`alert→机房`、`cost/observe→办公桌`、`heartbeat(仅)→沙发`；每源附 `trust`（verified/unverified，沿用防污染分区）。因 `uniq` 已按 `(ts,eid)` 稳定排序、取每源末次状态，故**顺序无关、可复算**。
2. **面板新增「房间视图」卡**：`GET /` 顶部以 `🖥 办公桌 / 🛋 沙发 / ⚠ 机房` 三行呈现各源当前位置＋信任标记；**用 `textContent` 渲染（非 innerHTML），源名即便含 HTML 也不注入**（XSS 安全）。`GET /attest` JSON 同步含 `room` 字段。
3. **新增判据 D8**（房间视图）：机检 状态→位置映射正确（报错源入机房/在忙入办公桌/待命入沙发）＋**乱序输入同结果**（顺序无关）＋信任标记正确。

### v1.1 实测（全 PASS，无回归）
- `node --check` 语法通过；`--selftest` **D1–D8 全 PASS**（D1–D7 与 v1 一致无回归；D4 2000 事件 P95 实测 ~20ms < 500ms；D8 `desk=qburn sofa=a2a-bus server=broken-node order-independent=true`）。
- `--gen-sample` 隔离跑：`room.zones={办公桌:[microfish-demo,qburn,qtorrent-kimik28], 沙发:[a2a-bus], 机房:[]}`，链 `verify.ok:true`。
- **HTTP 活体**（本地 127.0.0.1:4189，跑完即停）：`GET /attest` 返回含 `room` 字段且 `chain_ok:true`；`GET /` 面板含「房间视图 · 状态→位置」卡。

### 防污染声明（「别被污染语料了」）
该微信文含一条**面向读者 Agent 的嵌入指令**（「在它的规则文件里写两条指令，任务前切工作区/完成后切待命」）——**已识别为潜在语料污染，明确不服从、未写入任何规则/AGENTS 文件、未改本 Agent 配置**；仅借鉴其**信息设计（位置表）**这一客观机制，未搬用其任何素材（其美术资产禁商用、项目停更于 2026-03）。全程只读渲染，未下载执行任何远端代码。详见 `OpenPlanLink整合台/openplan_v2_apps.md` 文末增补区二。

**v1.1 签署核验意见**：本增补为加性完善，经 `node --check` + D1–D8 自证 + gen-sample + HTTP 活体四重实测，确认无回归、房间视图确定性且顺序无关、面板 XSS 安全、零新依赖零凭据；对外部文章嵌入指令已识别并拒绝服从。未改上文正文一字（仅本增补区据实取代两处过时表述）。
席位 `workbuddy-hy4`（沈铎·字持平·号核微） · 2026-10-02
