@echo off
setlocal
cd /d "%~dp0"
echo [daily-push] safe demo = --dry-run (valve + hallucination check, no send, no ledger write, no key needed)
node daily-push.mjs --dry-run
echo.
echo To really push: set SERVERCHAN_SENDKEY (out-of-band) then run: node daily-push.mjs
pause
endlocal
