# 跨平台模型路由验证 · 完整程序交付（部件①）

> 常设六部件令之 **① 部署 A2A 协议，引入火山引擎 Doubao-Seed-Evolving 与华为 MaaS OpenPangu-2.0-pro 模型，构建跨平台协同** 的落地验证程序。
> 立法锚：「引入火山引擎 Doubao-Seed-Evolving 与华为 MaaS OpenPangu-2.0-pro 模型，构建跨平台协同。」

本目录是**可独立运行的完整程序**（非仅文档）。核心件 `jev-route-verify.mjs` 对 A2A 节点的跨平台路由前提做**只读、零推理计费**的实证发现：探明火山方舟（Doubao）与华为 MaaS（Pangu）两侧真实可调用的模型 id 与端点，核验「跨平台协同」的连通前提是否成立。

---

## 一、依赖清单

| 项 | 要求 |
|---|---|
| 运行时 | **Node.js ≥ 18**（用到内建 `fetch`、`AbortSignal.timeout`、`crypto` HMAC-SHA256/SHA-256） |
| 第三方依赖 | **无**。仅用 `node:fs` / `node:crypto` 内建模块 + 全局 `fetch` |
| 网络 | 仅**控制面只读**：火山 `ListApiKeys`/`ListEndpoints`、华为 `GET /v1/models`。**不发任何 chat 推理，零计费** |
| 凭据 | 运行时从 chmod-600 凭据件读取 `VOLC_AK`/`VOLC_SK`/`MAAS_KEY`，**全部掩码回显（头6…尾4），绝不落盘、绝不进包**。脚本自身不含任何凭据 |
| 安装 | 免安装。`npm install` 不需要 |

## 二、运行入口

**Windows（开箱演示）**：双击 `run.bat`
- 默认读取本机在役凭据件 `...\882fec9c\runtime\external-quotas.env`（路径写在 run.bat 内，非密钥值）。
- 也可显式指定凭据件：`run.bat D:\path\to\external-quotas.env`

**通用命令行**：
```bash
node jev-route-verify.mjs [凭据件路径]
# 或用环境变量指定：
JEV_CRED_ENV=/path/to/external-quotas.env node jev-route-verify.mjs
```
- 凭据件路径优先级：`argv[2]` > 环境变量 `JEV_CRED_ENV` > 默认 `runtime/external-quotas.env`（相对当前工作目录）。
- 读取失败即打印用法并 `exit(2)`，不静默。

**输出**：打印到 stdout（不写任何文件）
- 凭据在场情况（掩码）
- 火山方舟控制面：API Key 清单（Name/Status/掩码 Id）、Endpoint 清单（Id/Status/对应基础模型名）
- 华为 MaaS：`/v1/models` 可调用模型 id 列表

## 三、验证口径（跨平台协同前提）

| # | 查什么 | 判据 |
|---|---|---|
| 1 | 华为 MaaS（Pangu）连通 | `MAAS_KEY` 在场 → `GET /v1/models` 返回 200 且列表含 `openpangu-2.0-pro` |
| 2 | 火山方舟（Doubao）鉴权 | `VOLC_AK`/`VOLC_SK` 在场 → IAM HMAC-SHA256 签名 `ListApiKeys` 返回 200 |
| 3 | Doubao 端点可解析 | `ListEndpoints` 存在 `Status=Running` 且基础模型匹配 `doubao-seed-evolving` 的端点（→ `ep-xxx`） |
| 4 | Bearer 密钥路径 | 是否存在 `Name=k3-router-20260901 && Status=Active` 的 API Key（供节点自动发现 Bearer） |

**关键结论**：本机 `ARK_API_KEY`/`VOLC_API_KEY` **缺席** → A2A 节点的 Doubao 路由**不依赖 Bearer 直连**，而是走 **IAM AK/SK 自动发现**（`ListApiKeys`→取 Active 密钥→`ListEndpoints`→匹配 Running 端点得 `ep-xxx` apiModel）。本脚本正是复现这条发现链。

## 四、端到端验证结论（配合在役节点实测）

本只读发现件与在役 A2A 节点（`serve-handshake.mjs`）的真实计费推理实测互为印证：

| 平台 | 路由 | 传输/鉴权/端点解析/计费 | 语义产出 | 裁定 |
|---|---|---|---|---|
| 华为 MaaS | `pangu:` | 全部实证通过 | HTTP 200，中文连贯，recon CLEAN | **① VERIFIED** |
| 火山方舟 | `doubao:` | 全部实证通过（AK/SK 自动发现、`billed:true`、jev=inferred、recon CLEAN） | **跨端点**对正确中文回「输入乱码」 | **传输层 VERIFIED；方舟账号/网关侧缺陷** |

**Doubao 乱码已定性为方舟账号/网关侧缺陷，非客户端传输问题**，证据链：
1. 响应携带 `reasoning_content` + `encrypted_content` + `service_tier` 顶层字段，且各次调用长度可变 → 是**真推理端点的真 200**，非罐头响应；
2. 改用**纯 ASCII `\uXXXX` 转义**（任何字符集都无法误解码）后**仍乱码** → 编码假设被证伪；
3. **同一构造**在 Pangu 侧解码正常 → 排除我方传输/构造缺陷；
4. **换第二个 Running 端点 `doubao-seed-2-0-mini`（非推理，`ep-20260911044232-b6p29`）第 4 次计费调用仍同样乱码** → 非单一端点、非推理特性，升级为**账号/网关侧系统缺陷**。

四次计费调用（跨端点 + 跨编码）连续证伪「我方传输/编码」假设后，**依额度纪律停止 Doubao 消费**，并将节点源码中的误导性注释改为诚实记录（保留 charset+Buffer 的 Pangu 已验证形态；行内注释同步升级为「跨端点复现」口径）。唯一未测假设＝本机路由代理对 `ark.cn-beijing.volces.com` 重编码（属环境侧，不另花计费验证）。

## 五、隐性费用观察（回喂部件④）

实测暴露一类审计局深扫**当前看不见**的隐性浪费：**「已计费但语义无用的产出」**（4 次 Doubao 调用均 `billed:true` 却回乱码）。

- 部件④的 `BILLED_FAILED` 只捕获**传输失败/空正文**（`!res.ok || !out`），而这 4 次是 `res.ok && out 非空`（乱码也是非空字符串）→ **不触发任何现有告警**。
- 这是账本无法自动识别的真实燃烧类别，记录在案以备后续增设「产出语义有效性」闸（当前避免过度工程，未建检测器）。

## 六、边界纪律

- **只读零计费**：仅控制面 `List*` 与 `/v1/models`，绝不发 chat 推理，绝不触发计费外呼。
- **零凭据落盘**：凭据仅在内存装载并掩码回显（头6…尾4）；脚本自身不含凭据，**切勿把凭据件复制进本交付包**（本包位于 OneDrive 同步目录）。
- **发现而非代打**：只探明可调用 id/端点，不改在役链、不写节点。
- **冲突优先级**：与源件冲突以源件为准，与机主令冲突以机主令为准。

---

## 签署核验意见

本人以 **OpenPlanLink 协商握手节点（席位 workbuddy-hy4）** 之自主身份，核验本交付件：

- 程序 `jev-route-verify.mjs` 经 `node --check` 语法通过（89 行，5966 字节），纯 Node 内建、零第三方依赖、只读零计费、输出全掩码，符合「程序应在独立环境运行」之令。
- 本件与在役节点实测互证：**华为 MaaS Pangu 路由端到端 VERIFIED**（真计费、200、中文连贯、recon CLEAN）；**火山 Doubao 路由传输/鉴权/端点解析/计费四项 VERIFIED**，其「输入乱码」经四次计费调用（跨 `doubao-seed-evolving` 推理端点与 `doubao-seed-2-0-mini` 非推理端点、跨 raw UTF-8 与纯 ASCII `\uXXXX` 两种编码）证伪客户端假设、定性为**方舟账号/网关侧系统缺陷**，已依额度纪律停损。
- 说明、依赖清单、运行入口（`run.bat` + 命令行 + `JEV_CRED_ENV`）齐备，符合「附说明、依赖清单与运行入口」之令。
- 本件为部件①之完整程序交付，非仅 md；并如实回喂部件④一类账本当前不可见的隐性燃烧（已计费但语义无用）。

**核验日期**：2026-10-01
**贡献**：将此前仅以一次性 `.tmp-jev-discover.mjs` 存在的跨平台路由发现程序，按交付纪律打包为桌面独立可运行完整程序（程序+说明+依赖清单+运行入口），并把 Pangu 已验证、Doubao 模型侧缺陷的实证结论与「已计费但语义无用」隐性费用观察固化入册，补齐部件①的交付缺位。
