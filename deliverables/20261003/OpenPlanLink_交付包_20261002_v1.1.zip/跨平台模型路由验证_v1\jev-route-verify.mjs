// ① 跨平台模型路由 · 只读发现/验证工具（零推理计费）
// 用途：探明火山 Doubao / 华为 MaaS Pangu 的真实可调用 id 与端点，验证 A2A 节点路由前提。
// 纪律：只装载凭据、绝不回显值（掩码 头6…尾4）；仅控制面 List* 与 /v1/models，不发任何 chat 推理。
// 凭据来源：argv[2] > 环境变量 JEV_CRED_ENV > 默认 runtime/external-quotas.env（相对当前工作目录）。
//   本脚本自身不含任何凭据；运行时从 chmod-600 凭据件读取，输出全部掩码。切勿把凭据件复制进交付包。
import fs from "node:fs";
import crypto from "node:crypto";

const ENVF = process.argv[2] || process.env.JEV_CRED_ENV || "runtime/external-quotas.env";
const env = {};
try {
  for (const line of fs.readFileSync(ENVF, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    let v = m[2].trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    env[m[1]] = v;
  }
} catch (e) {
  console.error(`无法读取凭据件：${ENVF}（${e && e.code ? e.code : e}）`);
  console.error('用法：node jev-route-verify.mjs [凭据件路径]   或设 JEV_CRED_ENV=<路径>');
  process.exit(2);
}
const mask = (v) => (!v ? "MISSING" : v.length <= 10 ? `set(len${v.length})` : `${v.slice(0, 6)}…${v.slice(-4)}(len${v.length})`);
console.log(`== 凭据件：${ENVF}（值全部掩码，绝不回显）==`);
for (const k of ["MAAS_KEY", "VOLC_AK", "VOLC_SK", "ARK_API_KEY", "VOLC_API_KEY"]) console.log("  " + k.padEnd(16), mask(env[k]));

// ---- Volc Ark 控制面（IAM HMAC-SHA256 签名，与 serve-handshake 同算法）----
function arkSign(ak, sk, query, body) {
  const host = "ark.cn-beijing.volcengineapi.com";
  const xDate = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  const short = xDate.slice(0, 8);
  const payloadHash = crypto.createHash("sha256").update(body).digest("hex");
  const canonicalQuery = Object.keys(query).sort().map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(query[k])}`).join("&");
  const headers = { "content-type": "application/json", host, "x-content-sha256": payloadHash, "x-date": xDate };
  const signed = Object.keys(headers).sort();
  const canonical = ["POST", "/", canonicalQuery, signed.map((k) => `${k}:${headers[k]}`).join("\n") + "\n", signed.join(";"), payloadHash].join("\n");
  const scope = `${short}/cn-beijing/ark/request`;
  const stringToSign = ["HMAC-SHA256", xDate, scope, crypto.createHash("sha256").update(canonical).digest("hex")].join("\n");
  let k = crypto.createHmac("sha256", sk).update(short).digest();
  k = crypto.createHmac("sha256", k).update("cn-beijing").digest();
  k = crypto.createHmac("sha256", k).update("ark").digest();
  k = crypto.createHmac("sha256", k).update("request").digest();
  const signature = crypto.createHmac("sha256", k).update(stringToSign).digest("hex");
  return {
    url: `https://${host}/?${canonicalQuery}`,
    headers: { "Content-Type": "application/json", Host: host, "X-Date": xDate, "X-Content-Sha256": payloadHash, Authorization: `HMAC-SHA256 Credential=${ak}/${scope}, SignedHeaders=${signed.join(";")}, Signature=${signature}` },
    body,
  };
}
async function arkCall(ak, sk, action, bodyObj) {
  const req = arkSign(ak, sk, { Action: action, Version: "2024-01-01" }, JSON.stringify(bodyObj));
  const res = await fetch(req.url, { method: "POST", headers: req.headers, body: req.body, signal: AbortSignal.timeout(20000) });
  const data = await res.json().catch(() => null);
  return { status: res.status, data };
}

const ak = env.VOLC_AK || "", sk = env.VOLC_SK || "";
console.log("\n== 火山方舟控制面（免费，无推理）==");
if (ak && sk) {
  const keys = await arkCall(ak, sk, "ListApiKeys", { PageNumber: 1, PageSize: 20, ProjectName: "default" });
  const kItems = (keys.data && keys.data.Result && keys.data.Result.Items) || [];
  console.log("  ListApiKeys status", keys.status, "count", kItems.length);
  for (const it of kItems.slice(0, 10)) console.log("    key:", { Name: it.Name, Status: it.Status, IdMasked: String(it.Id || "").slice(0, 6) + "…" });
  const eps = await arkCall(ak, sk, "ListEndpoints", { PageNumber: 1, PageSize: 50, ProjectName: "default" });
  const eItems = (eps.data && eps.data.Result && eps.data.Result.Items) || [];
  console.log("  ListEndpoints status", eps.status, "count", eItems.length);
  for (const ep of eItems.slice(0, 20)) {
    const fm = ep.ModelReference && ep.ModelReference.FoundationModel;
    console.log("    ep:", { Id: ep.Id, Status: ep.Status, Model: fm && (fm.Name || fm.ModelName) });
  }
  if (eps.data && eps.data.ResponseMetadata && eps.data.ResponseMetadata.Error) console.log("    ep-error:", JSON.stringify(eps.data.ResponseMetadata.Error).slice(0, 200));
} else console.log("  skip: no VOLC_AK/SK");

// ---- 华为 MaaS /v1/models（OpenAI 兼容，免费列表）----
console.log("\n== 华为 MaaS /v1/models（免费列表）==");
const maas = env.MAAS_KEY || "";
if (maas) {
  try {
    const res = await fetch("https://api.modelarts-maas.com/v1/models", { headers: { Authorization: `Bearer ${maas}` }, signal: AbortSignal.timeout(20000) });
    const data = await res.json().catch(() => null);
    console.log("  status", res.status);
    const list = (data && data.data) || (data && data.models) || [];
    if (Array.isArray(list) && list.length) for (const m of list.slice(0, 30)) console.log("    model:", m.id || m.name || m.model || JSON.stringify(m).slice(0, 60));
    else console.log("    body-keys:", data && typeof data === "object" ? Object.keys(data).slice(0, 10) : String(data).slice(0, 120));
  } catch (e) { console.log("  fetch-failed:", e && e.name ? e.name : String(e).slice(0, 60)); }
} else console.log("  skip: no MAAS_KEY");
console.log("\nDONE（零推理调用，零计费）");
