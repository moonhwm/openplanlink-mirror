@echo off
chcp 65001 >nul
REM ① 跨平台模型路由验证 · 运行入口（只读控制面，零推理计费）
REM 用法：双击运行（默认读本机在役凭据件）  或  run.bat <凭据件路径>
setlocal
set "CRED=%~1"
if "%CRED%"=="" set "CRED=C:\Users\欧阳宏俊\Documents\Qoder\2026-09-25\882fec9c\runtime\external-quotas.env"
echo [jev-route-verify] 凭据件: %CRED%
echo [jev-route-verify] 值全部掩码，仅控制面只读，不发推理、不计费。
echo.
node "%~dp0jev-route-verify.mjs" "%CRED%"
echo.
pause
endlocal
