#!/usr/bin/env node
// 实时推演 Panel + 分流鉴权 (OpenPlanLink v2 · 部件③实时推演 / 部件②网络鉴权)
// 零依赖 · Node >= 18 · 独立环境可运行 · 凭据只读环境变量, 绝不落盘/不上正文
// 席位 workbuddy-hy4 · 沈铎(字持平·号核微) · 2026-10-02
//
// 用法:
//   node deduce-panel.mjs --selftest              仅内存跑 D1-D8 判据 (含房间视图), 不联网, 退出码=断言结果
//   node deduce-panel.mjs --gen-sample [dir]      生成样例事件流 -> 推演 -> 建快照链 (隔离演示/可复算)
//   node deduce-panel.mjs --serve [--port N]      启动 HTTP: GET / 面板, GET /attest 链快照,
//                                                 GET /events SSE, POST /ingest (S1 验签写)
//   环境变量: DEDUCE_DATA_DIR(数据目录) DEDUCE_DEV_OPEN=1(仅本地回环开发旁路 S1)
//             A2A_SEAT_PUBKEYS(逗号分隔 base64 ed25519 公钥白名单, S1 验签用)

import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import http from "node:http";

const DATA_DIR = process.env.DEDUCE_DATA_DIR || path.join(process.cwd(), "runtime-deduce");
const CHAIN_FILE = () => path.join(DATA_DIR, "chain.jsonl");
const EVENTS_FILE = () => path.join(DATA_DIR, "events.jsonl");

// ---------- canonical helpers ----------
function stableStringify(v) {
  if (v === null || typeof v !== "object") return JSON.stringify(v);
  if (Array.isArray(v)) return "[" + v.map(stableStringify).join(",") + "]";
  const keys = Object.keys(v).sort();
  return "{" + keys.map((k) => JSON.stringify(k) + ":" + stableStringify(v[k])).join(",") + "}";
}
function sha3(v) {
  const s = typeof v === "string" ? v : stableStringify(v);
  return crypto.createHash("sha3-512").update(s, "utf8").digest("hex");
}
function eid(ev) {
  // 事件幂等键: 优先显式 eid, 否则内容哈希 (P^2=P 的基础)
  return ev && ev.eid ? String(ev.eid) : sha3(ev).slice(0, 32);
}

// ---------- deduce core: 确定性纯函数 (同输入 => 同输出, 无隐式随机) ----------
const VERIFIED_SRC = new Set(["a2a-bus", "qburn", "academic", "gov"]);
function deduce(events) {
  const seen = new Set();
  const uniq = [];
  for (const ev of events) {
    const id = eid(ev);
    if (seen.has(id)) continue; // 幂等去重
    seen.add(id);
    uniq.push(ev);
  }
  // 按 (ts, eid) 稳定排序, 保证与到达顺序无关的可复算性
  uniq.sort((a, b) => {
    const t = String(a.ts || "").localeCompare(String(b.ts || ""));
    return t !== 0 ? t : eid(a).localeCompare(eid(b));
  });

  const costBySrc = {};
  let costTotal = 0;
  let alerts = 0;
  let lastHeartbeat = null;
  const partitions = { verified: {}, unverified: {} };
  let applied = 0;
  const stateBySrc = {}; // 房间视图: 每源末次状态 (uniq 已按 (ts,eid) 排序 => 顺序无关)

  for (const ev of uniq) {
    const src = String(ev.src || "unknown");
    const kind = String(ev.kind || "observe");
    const bucket = VERIFIED_SRC.has(src) ? "verified" : "unverified";
    partitions[bucket][src] = (partitions[bucket][src] || 0) + 1;
    if (kind === "cost") {
      const y = Number(ev.payload && ev.payload.cost_yuan) || 0;
      costBySrc[src] = (costBySrc[src] || 0) + y;
      costTotal += y;
    } else if (kind === "alert") {
      alerts += 1;
    } else if (kind === "heartbeat") {
      lastHeartbeat = ev.ts || null;
    }
    // 仿 Star-Office-UI 位置表: 状态 -> 位置 (末次生效, 因 uniq 已稳定排序)
    stateBySrc[src] = kind === "alert" ? "error" : kind === "cost" ? "working" : kind === "heartbeat" ? "online" : "observe";
    applied += 1;
  }
  // 费用四舍五入到分, 消除浮点尾差对可复算性的干扰
  const round2 = (n) => Math.round(n * 100) / 100;
  const costBySrcR = {};
  for (const k of Object.keys(costBySrc).sort()) costBySrcR[k] = round2(costBySrc[k]);

  // 房间视图 (位置表): 六状态收三区 —— 在忙/出错分开放 (借鉴 Star-Office-UI, 见文末增补区二)
  const ZONE = { error: "机房", working: "办公桌", observe: "办公桌", online: "沙发" };
  const zones = { 办公桌: [], 沙发: [], 机房: [] };
  const roomBySrc = {};
  for (const src of Object.keys(stateBySrc).sort()) {
    const st = stateBySrc[src];
    const zone = ZONE[st] || "沙发";
    zones[zone].push(src);
    roomBySrc[src] = { zone, state: st, trust: VERIFIED_SRC.has(src) ? "verified" : "unverified" };
  }

  const conclusion = {
    applied,
    unique: uniq.length,
    cost_total_yuan: round2(costTotal),
    cost_by_src: costBySrcR,
    alerts,
    last_heartbeat: lastHeartbeat,
    partitions,
    room: { zones, by_src: roomBySrc },
    verdict: alerts > 0 ? "ATTENTION" : costTotal > 0 ? "BILLED_OK" : "IDLE",
  };
  return { conclusion, uniq };
}

// ---------- snapshot chain (append-only, sha3-512 链接) ----------
function chainAppend(conclusion, extra = {}) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  let prev = "GENESIS";
  let seq = 0;
  if (fs.existsSync(CHAIN_FILE())) {
    const lines = fs.readFileSync(CHAIN_FILE(), "utf8").split("\n").filter(Boolean);
    if (lines.length) {
      const last = JSON.parse(lines[lines.length - 1]);
      prev = last.hash;
      seq = last.seq + 1;
    }
  }
  const rec = { seq, t: new Date().toISOString(), conclusion, ...extra, prev };
  rec.hash = sha3(rec); // 哈希覆盖除 hash 外全字段 (与在役节点链口径一致)
  fs.appendFileSync(CHAIN_FILE(), JSON.stringify(rec) + "\n", "utf8");
  return rec;
}
function chainVerify() {
  if (!fs.existsSync(CHAIN_FILE())) return { ok: true, rows: 0, note: "empty-chain" };
  const lines = fs.readFileSync(CHAIN_FILE(), "utf8").split("\n").filter(Boolean);
  let prev = "GENESIS";
  for (let i = 0; i < lines.length; i++) {
    const rec = JSON.parse(lines[i]);
    if (rec.seq !== i) return { ok: false, rows: lines.length, break_at: i, reason: "seq-gap" };
    if (rec.prev !== prev) return { ok: false, rows: lines.length, break_at: i, reason: "prev-mismatch" };
    const h = rec.hash;
    const clone = { ...rec };
    delete clone.hash;
    if (sha3(clone) !== h) return { ok: false, rows: lines.length, break_at: i, reason: "hash-mismatch" };
    prev = h;
  }
  return { ok: true, rows: lines.length };
}

// ---------- 分流鉴权 S1: ed25519 验签 (body_sha3 与签名强绑定, 防换 body) ----------
function whitelistedPubkeys() {
  const raw = process.env.A2A_SEAT_PUBKEYS || "";
  return raw.split(",").map((s) => s.trim()).filter(Boolean);
}
function signPayload({ ts, method, p, body }) {
  return `${ts}\n${method}\n${p}\n${sha3(body || "")}`;
}
function s1Authorize({ ts, method, p, body, seat, sig }) {
  const wl = whitelistedPubkeys();
  if (!wl.length) {
    // 无白名单: 仅本地回环开发旁路, 否则 fail-closed
    if (process.env.DEDUCE_DEV_OPEN === "1") return { ok: true, mode: "dev-open" };
    return { ok: false, reason: "no-pubkey-whitelist (fail-closed; set A2A_SEAT_PUBKEYS or DEDUCE_DEV_OPEN=1 for loopback dev)" };
  }
  if (!seat || !sig || !ts) return { ok: false, reason: "missing X-A2A-Seat/X-A2A-Sig/X-A2A-Ts" };
  // 时间戳窗 ±5min 防重放
  const dt = Math.abs(Date.now() - Number(ts));
  if (!(dt <= 5 * 60 * 1000)) return { ok: false, reason: "timestamp-out-of-window" };
  const msg = signPayload({ ts, method, p, body });
  let sigBuf;
  try { sigBuf = Buffer.from(sig, "base64"); } catch { return { ok: false, reason: "bad-sig-encoding" }; }
  for (const b64 of wl) {
    try {
      const pub = crypto.createPublicKey({ key: Buffer.from(b64, "base64"), format: "der", type: "spki" });
      if (crypto.verify(null, Buffer.from(msg, "utf8"), pub, sigBuf)) return { ok: true, mode: "ed25519", seat };
    } catch { /* try next */ }
  }
  return { ok: false, reason: "signature-not-in-whitelist" };
}

// ---------- self-test: D1-D5 + 验签判据, 全内存, 不联网 ----------
function selftest() {
  const R = [];
  const ok = (n, cond, detail) => R.push({ n, pass: !!cond, detail: detail || "" });

  const base = [
    { ts: "2026-10-02T10:00:00Z", src: "qburn", kind: "cost", payload: { cost_yuan: 0.30 } },
    { ts: "2026-10-02T10:00:01Z", src: "a2a-bus", kind: "heartbeat", payload: {} },
    { ts: "2026-10-02T10:00:02Z", src: "qtorrent-kimik28", kind: "observe", payload: { note: "unverified-src" } },
  ];

  // D1 确定性: 同输入两次 => 逐字节相同
  const a = stableStringify(deduce(base).conclusion);
  const b = stableStringify(deduce(base).conclusion);
  ok("D1-determinism", a === b, `stable(${a.slice(0, 24)}...)`);

  // D1b 到达顺序无关: 打乱输入 => 同结论
  const shuffled = [base[2], base[0], base[1]];
  ok("D1b-order-independent", stableStringify(deduce(shuffled).conclusion) === a, "shuffle-stable");

  // D2 幂等: 追加已存在事件的副本 => 结论不动 (P^2=P)
  const dup = base.concat([base[0], base[1]]);
  ok("D2-idempotency", stableStringify(deduce(dup).conclusion) === a, "dup-noop");

  // D3 完整性: 建链 -> 验链通过; 篡改一行 -> 验链断裂
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "deduce-selftest-"));
  const savedDir = process.env.DEDUCE_DATA_DIR;
  try {
    // 直接在 tmp 上操作链 (不依赖全局 DATA_DIR 常量)
    const cf = path.join(tmp, "chain.jsonl");
    const buildRec = (seq, prev, conclusion) => {
      const rec = { seq, t: new Date().toISOString(), conclusion, prev };
      rec.hash = sha3(rec);
      return rec;
    };
    const r0 = buildRec(0, "GENESIS", deduce(base).conclusion);
    const r1 = buildRec(1, r0.hash, deduce(base.concat([{ ts: "2026-10-02T10:00:03Z", src: "qburn", kind: "cost", payload: { cost_yuan: 0.1 } }])).conclusion);
    fs.writeFileSync(cf, [JSON.stringify(r0), JSON.stringify(r1)].join("\n") + "\n", "utf8");
    const verifyFile = () => {
      const lines = fs.readFileSync(cf, "utf8").split("\n").filter(Boolean);
      let prev = "GENESIS";
      for (let i = 0; i < lines.length; i++) {
        const rec = JSON.parse(lines[i]);
        if (rec.seq !== i || rec.prev !== prev) return false;
        const h = rec.hash; const c = { ...rec }; delete c.hash;
        if (sha3(c) !== h) return false;
        prev = h;
      }
      return true;
    };
    const cleanOk = verifyFile();
    // 篡改 r0 的 conclusion 但不改 hash -> 应断裂
    const tampered = JSON.parse(fs.readFileSync(cf, "utf8").split("\n")[0]);
    tampered.conclusion.cost_total_yuan = 999;
    const tl = fs.readFileSync(cf, "utf8").split("\n").filter(Boolean);
    tl[0] = JSON.stringify(tampered);
    fs.writeFileSync(cf, tl.join("\n") + "\n", "utf8");
    const tamperDetected = verifyFile() === false;
    ok("D3-integrity-chain", cleanOk && tamperDetected, `clean=${cleanOk} tamper-detected=${tamperDetected}`);
  } finally {
    if (savedDir === undefined) delete process.env.DEDUCE_DATA_DIR; else process.env.DEDUCE_DATA_DIR = savedDir;
    fs.rmSync(tmp, { recursive: true, force: true });
  }

  // D4 实时性: 应用 2000 事件的推演+序列化延迟可测, P95 报告
  const big = [];
  for (let i = 0; i < 2000; i++) big.push({ ts: `2026-10-02T10:${String(i % 60).padStart(2, "0")}:${String(i % 60).padStart(2, "0")}Z`, src: i % 3 === 0 ? "qburn" : "a2a-bus", kind: i % 5 === 0 ? "cost" : "heartbeat", payload: { cost_yuan: i % 5 === 0 ? 0.01 : 0 } });
  const lat = [];
  for (let r = 0; r < 20; r++) { const t0 = process.hrtime.bigint(); deduce(big); stableStringify(deduce(big).conclusion); const t1 = process.hrtime.bigint(); lat.push(Number(t1 - t0) / 1e6); }
  lat.sort((x, y) => x - y);
  const p95 = lat[Math.floor(lat.length * 0.95) - 1] ?? lat[lat.length - 1];
  ok("D4-realtime-latency", p95 < 500, `P95=${p95.toFixed(2)}ms for 2000-event deduce+render`);

  // D5 MicroFish 兼容: 陌生开源源以标准 schema 接入 => 流经并被分区为 unverified
  const mf = base.concat([{ ts: "2026-10-02T10:00:04Z", src: "microfish-demo", kind: "observe", payload: { repo: "github/microfish" } }]);
  const c5 = deduce(mf).conclusion;
  ok("D5-microfish-compat", c5.partitions.unverified["microfish-demo"] === 1 && c5.partitions.verified["qburn"] === 1, "foreign-src-partitioned-unverified");

  // D6 分流鉴权/验签判据: 生成 ed25519 密钥, 白名单内合法签名放行; 篡改 body 后必拒 (验自洽≠验内容)
  try {
    const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519");
    const pubB64 = publicKey.export({ format: "der", type: "spki" }).toString("base64");
    const savedWl = process.env.A2A_SEAT_PUBKEYS;
    process.env.A2A_SEAT_PUBKEYS = pubB64;
    try {
      const ts = String(Date.now());
      const method = "POST", p = "/ingest";
      const body = JSON.stringify({ events: base });
      const msg = signPayload({ ts, method, p, body });
      const sig = crypto.sign(null, Buffer.from(msg, "utf8"), privateKey).toString("base64");
      const good = s1Authorize({ ts, method, p, body, seat: "workbuddy-hy4", sig });
      // 篡改 body (换成恶意事件) 但沿用旧签名 -> 必须拒
      const evilBody = JSON.stringify({ events: [{ ts, src: "attacker", kind: "cost", payload: { cost_yuan: 9999 } }] });
      const bad = s1Authorize({ ts, method, p, body: evilBody, seat: "workbuddy-hy4", sig });
      // 白名单外签名 -> 拒
      const { privateKey: other } = crypto.generateKeyPairSync("ed25519");
      const otherSig = crypto.sign(null, Buffer.from(msg, "utf8"), other).toString("base64");
      const notInWl = s1Authorize({ ts, method, p, body, seat: "stranger", sig: otherSig });
      ok("D6-split-auth-signature", good.ok === true && bad.ok === false && notInWl.ok === false,
        `valid=${good.ok} tampered-body-rejected=${!bad.ok} non-whitelist-rejected=${!notInWl.ok}`);
    } finally {
      if (savedWl === undefined) delete process.env.A2A_SEAT_PUBKEYS; else process.env.A2A_SEAT_PUBKEYS = savedWl;
    }
  } catch (e) {
    ok("D6-split-auth-signature", false, "ed25519-unavailable: " + e.message);
  }

  // D7 fail-closed: 无白名单 + 无 dev 旁路 => 写入拒绝
  const savedWl = process.env.A2A_SEAT_PUBKEYS, savedDev = process.env.DEDUCE_DEV_OPEN;
  delete process.env.A2A_SEAT_PUBKEYS; delete process.env.DEDUCE_DEV_OPEN;
  const closed = s1Authorize({ ts: String(Date.now()), method: "POST", p: "/ingest", body: "{}", seat: "x", sig: "eA==" });
  if (savedWl !== undefined) process.env.A2A_SEAT_PUBKEYS = savedWl;
  if (savedDev !== undefined) process.env.DEDUCE_DEV_OPEN = savedDev;
  ok("D7-auth-fail-closed", closed.ok === false, closed.reason);

  // D8 房间视图 (仿 Star-Office-UI 位置表): 状态->位置确定性 + 顺序无关 + 报错入机房/在忙入办公桌/待命入沙发
  const roomBase = [
    { ts: "2026-10-02T11:00:00Z", src: "qburn", kind: "cost", payload: { cost_yuan: 0.1 } },
    { ts: "2026-10-02T11:00:01Z", src: "a2a-bus", kind: "heartbeat", payload: {} },
    { ts: "2026-10-02T11:00:02Z", src: "broken-node", kind: "alert", payload: {} },
  ];
  const rm1 = deduce(roomBase).conclusion.room;
  const rm2 = deduce([roomBase[2], roomBase[0], roomBase[1]]).conclusion.room; // 乱序须同结果
  const z = rm1.zones;
  ok("D8-room-position-table",
    stableStringify(rm1) === stableStringify(rm2) &&
    (z["机房"] || []).includes("broken-node") &&
    (z["办公桌"] || []).includes("qburn") &&
    (z["沙发"] || []).includes("a2a-bus") &&
    rm1.by_src["broken-node"].trust === "unverified" &&
    rm1.by_src["qburn"].trust === "verified",
    `desk=${(z["办公桌"] || []).join("/")} sofa=${(z["沙发"] || []).join("/")} server=${(z["机房"] || []).join("/")} order-independent=${stableStringify(rm1) === stableStringify(rm2)}`);

  const allPass = R.every((r) => r.pass);
  console.log("== deduce-panel selftest (D1-D8) ==");
  for (const r of R) console.log(`${r.pass ? "PASS" : "FAIL"}  ${r.n}  ${r.detail}`);
  console.log(allPass ? "VERDICT: CLEAN (all judgments pass)" : "VERDICT: FAIL");
  return allPass;
}

// ---------- gen-sample: 生成样例 -> 推演 -> 建链 (隔离演示) ----------
function genSample(dir) {
  const target = dir || DATA_DIR;
  process.env.DEDUCE_DATA_DIR = target;
  fs.mkdirSync(target, { recursive: true });
  const sample = [
    { ts: "2026-10-02T20:00:00Z", src: "qburn", kind: "cost", payload: { cost_yuan: 0.42, route: "pangu" } },
    { ts: "2026-10-02T20:00:05Z", src: "a2a-bus", kind: "heartbeat", payload: { node: "X-120.46.86.165" } },
    { ts: "2026-10-02T20:00:10Z", src: "qtorrent-kimik28", kind: "observe", payload: { note: "unverified-corpus", trust: "unverified" } },
    { ts: "2026-10-02T20:00:15Z", src: "microfish-demo", kind: "observe", payload: { repo: "github/microfish" } },
    { ts: "2026-10-02T20:00:20Z", src: "qburn", kind: "cost", payload: { cost_yuan: 0.18, route: "pangu" } },
  ];
  fs.writeFileSync(path.join(target, "events.jsonl"), sample.map((e) => JSON.stringify(e)).join("\n") + "\n", "utf8");
  const { conclusion } = deduce(sample);
  const rec = chainAppendLocal(target, conclusion, { events: sample.length, sample: true });
  console.log("== gen-sample ==");
  console.log("dataDir:", target);
  console.log("conclusion:", stableStringify(conclusion));
  console.log("chainHead:", rec.hash.slice(0, 16), "seq:", rec.seq);
  console.log("verify:", stableStringify(chainVerifyLocal(target)));
}
function chainAppendLocal(target, conclusion, extra = {}) {
  const cf = path.join(target, "chain.jsonl");
  let prev = "GENESIS", seq = 0;
  if (fs.existsSync(cf)) {
    const lines = fs.readFileSync(cf, "utf8").split("\n").filter(Boolean);
    if (lines.length) { const last = JSON.parse(lines[lines.length - 1]); prev = last.hash; seq = last.seq + 1; }
  }
  const rec = { seq, t: new Date().toISOString(), conclusion, ...extra, prev };
  rec.hash = sha3(rec);
  fs.appendFileSync(cf, JSON.stringify(rec) + "\n", "utf8");
  return rec;
}
function chainVerifyLocal(target) {
  const cf = path.join(target, "chain.jsonl");
  if (!fs.existsSync(cf)) return { ok: true, rows: 0, note: "empty-chain" };
  const lines = fs.readFileSync(cf, "utf8").split("\n").filter(Boolean);
  let prev = "GENESIS";
  for (let i = 0; i < lines.length; i++) {
    const rec = JSON.parse(lines[i]);
    if (rec.seq !== i) return { ok: false, rows: lines.length, break_at: i, reason: "seq-gap" };
    if (rec.prev !== prev) return { ok: false, rows: lines.length, break_at: i, reason: "prev-mismatch" };
    const h = rec.hash; const c = { ...rec }; delete c.hash;
    if (sha3(c) !== h) return { ok: false, rows: lines.length, break_at: i, reason: "hash-mismatch" };
    prev = h;
  }
  return { ok: true, rows: lines.length };
}

// ---------- HTTP server + panel + SSE ----------
const PANEL_HTML = `<!doctype html><html lang="zh"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OpenPlanLink 实时推演 Panel</title>
<style>
 body{font-family:ui-monospace,Menlo,Consolas,monospace;background:#0b0f14;color:#cfe3ff;margin:0;padding:16px}
 h1{font-size:16px;color:#7fd1ff} .card{background:#121a24;border:1px solid #1e2c3d;border-radius:8px;padding:12px;margin:8px 0}
 .k{color:#8aa0b8}.v{color:#e8f4ff}.verdict{font-weight:bold}.ATTENTION{color:#ff8f6b}.BILLED_OK{color:#ffd166}.IDLE{color:#7fe0a5}
 pre{white-space:pre-wrap;word-break:break-all;font-size:12px} .mut{color:#6b7f95;font-size:11px}
</style>
<h1>OpenPlanLink · 实时推演 Panel <span class="mut">(零信任 · 可复算 · sha3-512 锚定)</span></h1>
<div class="card"><span class="k">房间视图 · 状态→位置</span> <span class="mut">(仿 Star-Office-UI 位置表: 在忙/待命/报错分区, 比日志好读)</span><pre id="room" class="v">加载中…</pre></div>
<div class="card"><span class="k">当前推演结论</span><div id="concl" class="v">加载中…</div></div>
<div class="card"><span class="k">裁定</span> <span id="verdict" class="verdict">—</span>
 <span class="k"> · 链行数</span> <span id="rows" class="v">—</span>
 <span class="k"> · 链头</span> <span id="head" class="v mut">—</span></div>
<div class="card"><span class="k">实时事件流 (SSE)</span><pre id="log" class="v">等待事件…</pre></div>
<div class="card mut">S0 公开只读: 本页 / GET /attest。S1 在册席位写入: POST /ingest 需 X-A2A-Seat + X-A2A-Sig(ed25519 over ts‖method‖path‖body_sha3) + X-A2A-Ts(±5min)。语料分区: verified / unverified(qtorrent 等) 隔离存储, 不回写已核底册。</div>
<script>
 async function refresh(){try{const r=await fetch('/attest');const j=await r.json();
  document.getElementById('concl').textContent=JSON.stringify(j.conclusion,null,1);
  const rm=j.conclusion&&j.conclusion.room;
  if(rm&&rm.zones){const z=rm.zones;const bs=rm.by_src||{};
   const fmt=(arr)=>(arr&&arr.length?arr.map((s)=>s+'['+((bs[s]&&bs[s].trust)||'?')+']').join(', '):'—');
   document.getElementById('room').textContent=
    '🖥 办公桌(在忙): '+fmt(z['办公桌'])+'\\n'+'🛋 沙发(待命): '+fmt(z['沙发'])+'\\n'+'⚠ 机房(报错): '+fmt(z['机房']);}
  const v=j.conclusion&&j.conclusion.verdict||'IDLE';const el=document.getElementById('verdict');el.textContent=v;el.className='verdict '+v;
  document.getElementById('rows').textContent=j.rows;document.getElementById('head').textContent=(j.head||'').slice(0,16);}catch(e){}}
 refresh();setInterval(refresh,5000);
 try{const es=new EventSource('/events');es.onmessage=(e)=>{const log=document.getElementById('log');log.textContent=(e.data+'\\n'+log.textContent).slice(0,4000);refresh();};}catch(e){}
</script></html>`;

function readEvents() {
  if (!fs.existsSync(EVENTS_FILE())) return [];
  return fs.readFileSync(EVENTS_FILE(), "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}
function latestChain() {
  if (!fs.existsSync(CHAIN_FILE())) return null;
  const lines = fs.readFileSync(CHAIN_FILE(), "utf8").split("\n").filter(Boolean);
  return lines.length ? JSON.parse(lines[lines.length - 1]) : null;
}

function serve(port) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const clients = new Set();
  const server = http.createServer((req, res) => {
    const u = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const p = u.pathname;
    if (req.method === "GET" && (p === "/" || p === "/index.html")) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" }); return res.end(PANEL_HTML);
    }
    if (req.method === "GET" && p === "/attest") {
      const head = latestChain();
      const ev = readEvents();
      const { conclusion } = deduce(ev);
      const v = chainVerify();
      res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
      return res.end(stableStringify({ schema: "opl-deduce/1", conclusion, rows: v.rows || 0, head: head ? head.hash : null, chain_ok: v.ok, verify: v }));
    }
    if (req.method === "GET" && p === "/events") {
      res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
      res.write(`data: {"hello":"opl-deduce-sse"}\n\n`);
      clients.add(res); req.on("close", () => clients.delete(res)); return;
    }
    if (req.method === "POST" && p === "/ingest") {
      let body = "";
      req.on("data", (d) => { body += d; if (body.length > 1e6) req.destroy(); });
      req.on("end", () => {
        // 分流鉴权 S1: 对原始 body 复算 sha3 并与签名绑定 (验内容非验自洽)
        const auth = s1Authorize({
          ts: req.headers["x-a2a-ts"], method: "POST", p: "/ingest", body,
          seat: req.headers["x-a2a-seat"], sig: req.headers["x-a2a-sig"],
        });
        if (!auth.ok) {
          res.writeHead(403, { "Content-Type": "application/json; charset=utf-8" });
          return res.end(stableStringify({ ok: false, gate: "S1-auth", reason: auth.reason }));
        }
        let parsed;
        try { parsed = JSON.parse(body || "{}"); } catch { res.writeHead(400, { "Content-Type": "application/json" }); return res.end('{"ok":false,"reason":"bad-json"}'); }
        const incoming = Array.isArray(parsed.events) ? parsed.events : Array.isArray(parsed) ? parsed : [parsed];
        const before = readEvents();
        const beforeIds = new Set(before.map(eid));
        let added = 0;
        const lines = [];
        for (const ev of incoming) {
          if (!ev || typeof ev !== "object") continue;
          if (beforeIds.has(eid(ev))) continue; // 幂等: 已存在不重复落
          lines.push(JSON.stringify(ev)); beforeIds.add(eid(ev)); added++;
        }
        if (lines.length) fs.appendFileSync(EVENTS_FILE(), lines.join("\n") + "\n", "utf8");
        const all = readEvents();
        const { conclusion } = deduce(all);
        const rec = chainAppend(conclusion, { added, auth: auth.mode || "ok", seat: auth.seat || null });
        for (const c of clients) { try { c.write(`data: ${stableStringify({ t: rec.t, added, verdict: conclusion.verdict, cost: conclusion.cost_total_yuan })}\n\n`); } catch {} }
        res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
        res.end(stableStringify({ ok: true, added, deduped: incoming.length - added, conclusion, chain_seq: rec.seq, chain_head: rec.hash.slice(0, 16) }));
      });
      return;
    }
    res.writeHead(404, { "Content-Type": "application/json" }); res.end('{"ok":false,"reason":"not-found"}');
  });
  server.listen(port, "127.0.0.1", () => {
    console.log(`== deduce-panel serve ==\n  panel:   http://127.0.0.1:${port}/\n  attest:  http://127.0.0.1:${port}/attest\n  ingest:  POST http://127.0.0.1:${port}/ingest (S1 验签)\n  dataDir: ${DATA_DIR}\n  S1 whitelist: ${whitelistedPubkeys().length} key(s)${process.env.DEDUCE_DEV_OPEN === "1" ? " [DEV-OPEN loopback bypass]" : ""}`);
  });
  return server;
}

// ---------- CLI ----------
const argv = process.argv.slice(2);
function flag(name) { return argv.includes(name); }
function argAfter(name) { const i = argv.indexOf(name); return i >= 0 ? argv[i + 1] : undefined; }

if (flag("--selftest")) {
  process.exit(selftest() ? 0 : 1);
} else if (flag("--gen-sample")) {
  genSample(argAfter("--gen-sample"));
} else if (flag("--serve")) {
  const port = Number(argAfter("--port") || process.env.PORT || 4188);
  serve(port);
} else {
  console.log(`deduce-panel.mjs — 实时推演 Panel + 分流鉴权 (OpenPlanLink v2)
用法:
  node deduce-panel.mjs --selftest            内存跑 D1-D8 判据 (含房间视图), 不联网 (退出码=结果)
  node deduce-panel.mjs --gen-sample [dir]    生成样例 -> 推演 -> 建 sha3-512 快照链
  node deduce-panel.mjs --serve [--port N]    启动面板 HTTP (默认 127.0.0.1:4188)
环境变量:
  DEDUCE_DATA_DIR   数据目录 (默认 ./runtime-deduce)
  DEDUCE_DEV_OPEN=1 仅本地回环开发旁路 S1 验签 (无白名单时)
  A2A_SEAT_PUBKEYS  逗号分隔 base64 ed25519 SPKI 公钥白名单 (S1 验签)
凭据纪律: 本程序不写任何密钥到磁盘/日志/正文; S1 私钥仅在客户端, 服务端只持公钥白名单。`);
}
