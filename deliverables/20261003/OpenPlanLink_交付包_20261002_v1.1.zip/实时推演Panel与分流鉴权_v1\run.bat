@echo off
chcp 65001 >nul
REM 实时推演 Panel + 分流鉴权 · 一键安全自证入口
REM 双击运行: 只跑内存自证判据 (D1-D7 + P1-P5), 不联网、不需密钥、不外呼、不落任何生产数据。
REM 席位 workbuddy-hy4 · 沈铎 · 2026-10-02

cd /d "%~dp0"
echo ============================================================
echo   OpenPlanLink v2 · 实时推演 Panel + 分流鉴权 · 安全自证
echo   (零依赖 · 不联网 · 无密钥 · 不外呼)
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [错误] 未检测到 Node.js。请安装 Node.js 18 或更高版本后重试。
  echo 下载: https://nodejs.org/
  pause
  exit /b 1
)

echo [1/3] node --check 语法校验...
node --check deduce-panel.mjs && node --check meow-push.mjs
if errorlevel 1 ( echo [失败] 语法校验未通过 & pause & exit /b 1 )
echo       OK
echo.

echo [2/3] deduce-panel --selftest (D1-D7)...
node deduce-panel.mjs --selftest
if errorlevel 1 ( echo [失败] 推演/鉴权判据未全过 & pause & exit /b 1 )
echo.

echo [3/3] meow-push --selftest (P1-P5)...
node meow-push.mjs --selftest
if errorlevel 1 ( echo [失败] 推送桥判据未全过 & pause & exit /b 1 )
echo.

echo ============================================================
echo   全部判据 PASS · VERDICT: CLEAN
echo   下一步(可选):
echo     生成样例:  node deduce-panel.mjs --gen-sample ./runtime-deduce
echo     启动面板:  set DEDUCE_DEV_OPEN=1 ^&^& node deduce-panel.mjs --serve --port 4188
echo     推送 dry:  node meow-push.mjs --dry-run --data-dir ./runtime-deduce
echo   真发推送需机主带外注入 MEOW_PUSH_KEY (本入口不涉任何凭据)。
echo ============================================================
pause
