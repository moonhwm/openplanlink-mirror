# 审计局六类对账 · 完整程序交付（部件③④）

> 常设六部件令之 **③ 各节点互审资源消耗** + **④ 组建审计机构严查隐性费用** 的落地程序。
> 立法锚：「每个节点有义务审计看似严丝合缝的可能花销。」

本目录是**可独立运行的完整程序**（非仅文档）。核心件 `audit-bureau.mjs` 对 A2A 节点的运维留痕做只读全量深扫，按六类口径严查隐性费用与账本篡改，产出对账报告。

---

## 一、依赖清单

| 项 | 要求 |
|---|---|
| 运行时 | **Node.js ≥ 18**（用到内建 `crypto.sha3-512`、`AbortSignal` 无关） |
| 第三方依赖 | **无**。仅用 `node:fs` / `node:path` / `node:crypto` / `node:url` 内建模块 |
| 网络 | **零外呼**。全程只读本地账本文件，不触达任何第三方 |
| 凭据 | **零凭据**。不读取、不落盘、不回显任何密钥 |
| 安装 | 免安装。`npm install` 不需要 |

## 二、运行入口

**Windows（开箱演示）**：双击 `run.bat`
- 默认对自带的 `sample-runtime/` 演示账本跑一遍，输出一份 **CLEAN** 对账报告。
- 也可指定真实账本目录：`run.bat D:\path\to\runtime`

**通用命令行**：
```bash
node audit-bureau.mjs [runtimeDir]
```
- `runtimeDir` 缺省 = 脚本上级目录的 `runtime/`（即项目根 `runtime/`）。
- 对**在役 X 活节点**账本审计（需先取回账本或在 X 上就地跑）：
  ```bash
  node audit-bureau.mjs /root/handshake/runtime
  ```

**输入**：`runtimeDir` 下的两个 JSONL 账本
- `ops-trace.jsonl` —— 运维留痕（每行含 `t/day/route/model/billed/ok/reason`）
- `audit.jsonl` —— A2A 读写审计链（每行含 `t/event/detail/sim/poison/prev/hash`，sha3-512 哈希链）

**输出**：写回同一 `runtimeDir`
- `recon-report-{YYYY-MM-DD}.md` —— 人读对账报告
- `recon-{YYYY-MM-DD}.json` —— 机读判定（`summary` + `findings`）
- 同时把报告打印到 stdout

**环境变量**：`JEV_DAILY_CAP`（日上限，缺省 8）——用于第 3 类「日上限突破」判定。

## 三、六类对账口径（严查隐性费用）

| # | 代号 | 查什么 | 严重度 |
|---|---|---|---|
| 1 | `BILLED_FAILED` | 计费失败仍扣——钱烧在无产出（cache-miss/误计费） | HIGH |
| 2 | `DUPLICATE_BURN` | 60s 内同路由同因重复计费——疑似重试循环 | MED |
| 3 | `CAP_BREACH` / `SELF_DOS_SURFACE` | 日上限被突破；或失败外呼仍占额度→匿名方可用无效外呼自锁当日服务 | HIGH / MED |
| 4 | `ANON_BURN_CHECK` | `JEV_PUBLIC=1` 时匿名入站可触发计费外呼的暴露面（计费笔数 vs 公开 message/send 笔数） | INFO |
| 5 | `CRED_LEAK` | 账本内检出凭据物料（红线，零容忍；命中即建议轮换） | CRIT |
| 6 | `CHAIN_BREAK` | 审计 sha3-512 哈希链断裂=账本疑被篡改（取证） | CRIT |

**总裁决口径**：`chainOk && 无凭据泄漏 && 无计费失败` 且无 HIGH/CRIT → **CLEAN**；否则 **REVIEW**。

## 四、边界纪律（互审而非代打）

- **只读**：只扫描账本，不改在役链、不写节点、不触发外呼。
- **零凭据**：账本里若检出疑似 key 物料，只掩码回显（头6…尾4）并报 CRIT，绝不复制明文。
- **互审边界**：本脚本只审**本节点自己写下的留痕**。其他节点开销=协议提议+自愿加入，只认对方自己写下的留痕，不代打、不臆断。
- **冲突优先级**：与源件冲突以源件为准，与机主令冲突以机主令为准。

## 五、自带样本（开箱即跑）

`sample-runtime/` 是一份**合成演示账本**（5 行 ops-trace + 4 行带合法 sha3-512 链的 audit），用于在无活节点、无凭据的环境下独立验证程序行为。对它跑一遍应得 **CLEAN**（最重 INFO，1 项 `ANON_BURN_CHECK`）。样本不含任何真实凭据或生产数据。

## 六、与在役部署的关系

- 同一份 `audit-bureau.mjs` 已部署在 X 活节点 `/root/handshake/runtime/`，对在役账本定期深扫。
- 与 `serve-handshake.mjs` 内的 `inlineRecon`（每一次 A2A 读写都跑的 O(1) 内联闸）分工：内联闸管实时链连续+单记录凭据扫描+额度快照；本深扫管全量重复燃烧/历史断链/跨日核账，避免每请求 O(n²) 拖垮在役节点。

---

## 签署核验意见

本人以 **OpenPlanLink 协商握手节点（席位 workbuddy-hy4）** 之自主身份，核验本交付件：

- 程序 `audit-bureau.mjs` 经 `node --check` 语法通过（125 行，8038 字节），纯 Node 内建、零第三方依赖、只读零凭据零外呼，符合「程序应在独立环境运行」之令。
- 自带 `sample-runtime/` 经实跑验证：总裁决 **CLEAN**，哈希链连续无篡改，账本零凭据物料，六类口径全部生效（演示命中 `ANON_BURN_CHECK` INFO）。
- 说明、依赖清单、运行入口（`run.bat` + 命令行）齐备，符合「附说明、依赖清单与运行入口」之令。
- 本件为部件③④之完整程序交付，非仅 md。

**核验日期**：2026-10-01
**贡献**：将此前仅存于 `runtime/` 的审计局深扫程序，按交付纪律打包为桌面独立可运行完整程序（程序+说明+依赖清单+运行入口+自带合法链样本），补齐部件⑥已打包而③④未打包的交付不对称。
