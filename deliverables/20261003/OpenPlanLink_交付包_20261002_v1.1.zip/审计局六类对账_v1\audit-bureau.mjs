// audit-bureau.mjs — 联合审计局对账扫描（只读）
// 立法锚：「每个节点有义务审计看似严丝合缝的可能花销。」
// 纪律：只读账本，零凭据落盘/回显；不触发任何外呼；不改在役链。
// 用法：node runtime/audit-bureau.mjs [runtimeDir]（默认 ./runtime）
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const RUNTIME = path.resolve(process.argv[2] || path.join(ROOT, "runtime"));
const OPS = path.join(RUNTIME, "ops-trace.jsonl");
const AUDIT = path.join(RUNTIME, "audit.jsonl");
const DAY_CAP = Math.max(0, parseInt(process.env.JEV_DAILY_CAP || "8", 10) || 8);
const sha3 = (s) => crypto.createHash("sha3-512").update(s).digest("hex");
const readJsonl = (f) => { try { return fs.readFileSync(f, "utf8").trim().split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean); } catch { return []; } };

const ops = readJsonl(OPS);
const audit = readJsonl(AUDIT);
const findings = [];
const add = (sev, code, msg, evidence) => findings.push({ sev, code, msg, evidence });

// ---- 1. 计费失败仍扣（cache-miss / 误计费）：billed=true 但 ok=false ----
const billedFailed = ops.filter((r) => r.billed && !r.ok);
if (billedFailed.length) {
  add("HIGH", "BILLED_FAILED", `${billedFailed.length} 笔外呼标记已计费但返回失败——钱可能烧在无产出上`, billedFailed.map((r) => ({ t: r.t, route: r.route, model: r.model, reason: r.reason })));
}

// ---- 2. 重复燃烧：同 route+model+reason 在 60s 窗口内重复计费 ----
const billed = ops.filter((r) => r.billed);
const dupes = [];
for (let i = 1; i < billed.length; i++) {
  const a = billed[i - 1], b = billed[i];
  const dt = new Date(b.t) - new Date(a.t);
  if (a.route === b.route && a.model === b.model && a.reason === b.reason && dt >= 0 && dt < 60000) dupes.push({ prev: a.t, cur: b.t, route: b.route, gapMs: dt });
}
if (dupes.length) add("MED", "DUPLICATE_BURN", `${dupes.length} 组 60s 内同路由同因重复计费——疑似重试循环`, dupes);

// ---- 3. 日上限完整性：按日统计计费笔数 vs DAY_CAP ----
const byDay = {};
for (const r of billed) { const d = r.day || (r.t || "").slice(0, 10); byDay[d] = (byDay[d] || 0) + 1; }
for (const [d, n] of Object.entries(byDay)) {
  if (n > DAY_CAP) add("HIGH", "CAP_BREACH", `${d} 计费 ${n} 笔 > 上限 ${DAY_CAP}——日上限被突破`, { day: d, billed: n, cap: DAY_CAP });
  else if (n === DAY_CAP) add("INFO", "CAP_AT_LIMIT", `${d} 计费已触顶 ${n}/${DAY_CAP}`, { day: d, billed: n, cap: DAY_CAP });
}
// 自 DoS 面：billed 失败也计入上限 → 攻击者可用失败外呼耗尽当日额度
if (billedFailed.length && DAY_CAP > 0) add("MED", "SELF_DOS_SURFACE", `失败外呼仍计入日上限：${billedFailed.length} 笔失败占用了 ${DAY_CAP} 额度中的配额——匿名方可用无效外呼自锁当日服务`, { billedFailed: billedFailed.length, cap: DAY_CAP });

// ---- 4. 匿名 quota 燃烧：JEV_PUBLIC=1 时公开流量可触发计费外呼 ----
const publicSends = audit.filter((r) => r.event === "message/send");
if (billed.length && publicSends.length) {
  add("INFO", "ANON_BURN_CHECK", `${billed.length} 笔计费外呼 vs ${publicSends.length} 条公开 message/send——若 JEV_PUBLIC=1，匿名入站可触发计费，须确认日上限+密钥闸有效`, { billed: billed.length, publicSends: publicSends.length });
}

// ---- 5. 凭据卫生：全账本扫描 key 物料泄漏 ----
const credRe = /sk-tp-[A-Za-z0-9]|sk-[A-Za-z0-9]{20,}|Bearer\s+[A-Za-z0-9._-]{16,}|(MAAS_KEY|ARK_API_KEY|VOLC_API_KEY|SCNET_KEY|DEEPSEEK_API_KEY|OPENPLANLINK_KEY|TUSHARE_TOKEN)\s*[:=]\s*["']?[A-Za-z0-9]{8,}/g;
const leaks = [];
for (const [name, rows] of [["ops-trace", ops], ["audit", audit]]) {
  const blob = JSON.stringify(rows);
  const m = blob.match(credRe);
  if (m) leaks.push({ ledger: name, hits: m.length, samples: [...new Set(m)].slice(0, 3).map((s) => s.slice(0, 6) + "…" + s.slice(-4)) });
}
if (leaks.length) add("CRIT", "CRED_LEAK", `账本中检出疑似凭据物料——立即轮换并清除`, leaks);

// ---- 6. 哈希链完整性：重算 audit sha3 链，防账本被改 ----
let chainOk = true, chainBreak = null, prev = "";
for (let i = 0; i < audit.length; i++) {
  const r = audit[i];
  if (r.prev !== undefined && prev !== "" && r.prev !== prev) { chainOk = false; chainBreak = { index: i, t: r.t, expectedPrev: prev.slice(0, 12), gotPrev: String(r.prev).slice(0, 12) }; break; }
  const rec = { ...r }; const storedHash = rec.hash; delete rec.hash;
  const recomputed = sha3(JSON.stringify(rec));
  if (storedHash && recomputed !== storedHash) { chainOk = false; chainBreak = { index: i, t: r.t, reason: "hash-mismatch" }; break; }
  prev = storedHash || recomputed;
}
if (!chainOk) add("CRIT", "CHAIN_BREAK", `审计哈希链在第 ${chainBreak.index} 条断裂——账本疑被篡改`, chainBreak);

// ---- 汇总 ----
const order = { CRIT: 0, HIGH: 1, MED: 2, INFO: 3 };
findings.sort((a, b) => order[a.sev] - order[b.sev]);
const worst = findings.length ? findings[0].sev : "CLEAN";
const ts = new Date().toISOString();
const summary = {
  ts, runtime: RUNTIME, dayCap: DAY_CAP,
  opsRows: ops.length, billedRows: billed.length, auditRows: audit.length,
  verdict: chainOk && !leaks.length && !billedFailed.length ? (findings.some((f) => f.sev === "HIGH" || f.sev === "CRIT") ? "REVIEW" : "CLEAN") : "REVIEW",
  worstSeverity: worst, findingCount: findings.length,
};

const redact = (o) => JSON.stringify(o).replace(/(sk-[A-Za-z0-9._-]{4})[A-Za-z0-9._-]+/g, "$1…");
const lines = [];
lines.push(`# 审计局对账报告 ${ts.slice(0, 10)}`);
lines.push("");
lines.push(`- 账本目录：\`${RUNTIME}\`（只读扫描，未触发任何外呼）`);
lines.push(`- 口径：ops-trace ${summary.opsRows} 行 / 计费 ${summary.billedRows} 笔 / audit ${summary.auditRows} 行；日上限 ${DAY_CAP}`);
lines.push(`- 总裁决：**${summary.verdict}**（最重 ${worst}，${findings.length} 项发现）`);
lines.push(`- 哈希链：${chainOk ? "连续，无篡改迹象" : "断裂，见 CRIT"}`);
lines.push(`- 凭据卫生：${leaks.length ? "检出泄漏，见 CRIT" : "账本零凭据物料"}`);
lines.push("");
lines.push("## 发现");
lines.push("");
if (!findings.length) lines.push("_无发现——账本在六类「看似严丝合缝」花销口径下均干净。_");
for (const f of findings) {
  lines.push(`### [${f.sev}] ${f.code} — ${f.msg}`);
  lines.push("```json");
  lines.push(redact(f.evidence));
  lines.push("```");
  lines.push("");
}
lines.push("## 六类对账口径（立法锚）");
lines.push("1. BILLED_FAILED：计费失败仍扣——钱烧在无产出（cache-miss/误计费）。");
lines.push("2. DUPLICATE_BURN：短窗同因重复计费——重试循环。");
lines.push("3. CAP_BREACH / SELF_DOS_SURFACE：日上限突破，或失败外呼占用额度致匿名自锁。");
lines.push("4. ANON_BURN_CHECK：JEV_PUBLIC=1 时匿名入站触发计费外呼的暴露面。");
lines.push("5. CRED_LEAK：账本内凭据物料（红线，零容忍）。");
lines.push("6. CHAIN_BREAK：哈希链断裂=账本被改（篡改取证）。");
lines.push("");
lines.push("> 互审边界：本脚本只审本节点自己写下的留痕。其他节点开销=协议提议+自愿加入，");
lines.push("> 只认对方自己写下的留痕，不代打、不臆断。与源件冲突以源件为准，与机主令冲突以机主令为准。");

const outMd = path.join(RUNTIME, `recon-report-${ts.slice(0, 10)}.md`);
const outJson = path.join(RUNTIME, `recon-${ts.slice(0, 10)}.json`);
fs.writeFileSync(outMd, lines.join("\n"), "utf8");
fs.writeFileSync(outJson, JSON.stringify({ summary, findings }, null, 1), "utf8");
console.log(lines.join("\n"));
console.log(`\n[written] ${outMd}\n[written] ${outJson}`);
