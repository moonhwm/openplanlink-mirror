// quota-ops-trace.mjs — ⑤额度守护 + ②历史上下文回应/运维留痕 的隔离可运行复现
// 立法锚：「所有调用受额度守护」+「系统受理新请求时基于历史上下文回应，并生成运维留痕以备对账」。
// 纪律：本程序绝不外呼、绝不读凭据、绝不计费。仅以纯函数忠实复现在役节点 serve-handshake.mjs 的
//       闸链判定顺序（jevInfer）、运维留痕行 schema（writeOpsTrace）、sha3-512 审计链（audit/inlineRecon）
//       与历史上下文回应（handleSend）。产物 ops-trace.jsonl + audit.jsonl 与姊妹件
//       审计局六类对账_v1/audit-bureau.mjs 完全兼容，可被其对账为 CLEAN。
// 用法：node quota-ops-trace.mjs [outDir] [--cap N] [--verify]
//   outDir  留痕落盘目录（默认 ./out）
//   --cap N 日上限 JEV_DAILY_CAP（默认 2，便于在短演示内触发额度守护）
//   --verify 只校验 outDir 内既有账本（链连续 + 自证哈希 + 额度未破 + 零凭据），不重新生成
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const sha3 = (s) => crypto.createHash("sha3-512").update(s).digest("hex");

// ---- 参数解析 ----
const argv = process.argv.slice(2);
const verifyOnly = argv.includes("--verify");
const capIdx = argv.indexOf("--cap");
const CAP = Math.max(0, parseInt(capIdx >= 0 ? argv[capIdx + 1] : "2", 10) || 0);
const OUTDIR = path.resolve(argv.find((a) => !a.startsWith("--") && (capIdx < 0 || argv.indexOf(a) !== capIdx + 1)) || "./out");
const OPS = path.join(OUTDIR, "ops-trace.jsonl");
const AUDIT = path.join(OUTDIR, "audit.jsonl");
const NODE = "127.0.0.1:0 (isolated)";
const SEAT = "workbuddy-hy4";

// 与在役节点同款凭据物料红线正则（inlineRecon / audit-bureau 一致口径），用于自证账本零凭据。
const CRED_RE = /sk-tp-[A-Za-z0-9]|sk-[A-Za-z0-9]{20,}|Bearer\s+[A-Za-z0-9._-]{16,}|(MAAS_KEY|HUAWEI_MAAS_KEY|ARK_API_KEY|VOLC_API_KEY|VOLC_SK|SCNET_KEY|DEEPSEEK_API_KEY|OPENPLANLINK_KEY|TUSHARE_TOKEN)["']?\s*[:=]\s*["']?[A-Za-z0-9]{8,}/i;

function dayKey() {
  return new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
}
function appendLine(file, obj) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.appendFileSync(file, JSON.stringify(obj) + "\n");
}
function readJsonl(file) {
  try { return fs.readFileSync(file, "utf8").trim().split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean); } catch { return []; }
}

// ============ ⑤ 额度守护闸链（忠实复现 jevInfer 的 fail-closed 判定顺序，不含真实外呼） ============
// 在役节点顺序：公开闸 → 日上限闸 → (AK/SK 自动发现，此处略) → 缺密钥闸 → ①doubao 不可调用闸 → 真 fetch。
// 本纯函数把"真 fetch"替换为"将计费"决策（billed:true），绝不发起任何网络请求。
function quotaGate({ route, authed, publicEnabled, todayBilled, cap, hasKey, apiModel, modelId, missing }) {
  if (!authed && !publicEnabled) {
    return { billed: false, ok: false, gate: "public-off", reason: "公开路由已停用（未设 JEV_PUBLIC=1）" };
  }
  if (todayBilled >= cap) {
    return { billed: false, ok: false, gate: "daily-cap", reason: `已达本日外呼上限 ${cap}` };
  }
  if (!hasKey) {
    return { billed: false, ok: false, gate: "missing-key", reason: missing || "未设置目标密钥" };
  }
  // ① 隐性费用闸：方舟 Bearer 直投且模型名不可调用（纯文案名无数字版本后缀）→ fail-closed 不计费，
  //    避免向方舟发无效 id 触发 400 仍扣费（BILLED_FAILED，属④审计局严查的隐性费用）。
  if (route === "doubao" && !apiModel) {
    const mid = String(modelId || "");
    const callable = /^ep-[0-9a-z-]+$/i.test(mid) || (/\d/.test(mid) && /^doubao-/i.test(mid));
    if (!callable) {
      return { billed: false, ok: false, gate: "doubao-uncallable", reason: `JEV_DOUBAO_MODEL="${mid}" 非方舟可调用 id（疑为文案名）。已 fail-closed 不计费。` };
    }
  }
  // 闸全过：在役节点此处真实 fetch 并 billed:true；本程序仅记录"将计费"决策，不外呼。
  return { billed: true, ok: true, gate: "pass", reason: "" };
}

// ============ ② 运维留痕（忠实复现 writeOpsTrace 行 schema） ============
function opsCallsToday(rows, day) {
  return rows.filter((r) => r.day === day && r.billed).length;
}
function makeOpsRow({ day, route, model, ok, billed, reason, quote, cap, billedToday }) {
  return {
    t: new Date().toISOString(),
    day,
    node: NODE,
    seat: SEAT,
    route,
    model,
    ok,
    billed,
    reason: String(reason || "").slice(0, 120),
    history: `本日已计费外呼 ${billedToday}，上限 ${cap}`,
    next: "下一笔若无对应密钥或超出日上限，只留痕不外呼。其他节点开销未探测，只认对方自己写下的留痕。",
    dailyLine: quote || "",
  };
}

// ============ sha3-512 审计链（忠实复现 audit + inlineRecon，键序须与在役节点一致） ============
// 在役节点键插入序：t,event,detail,sim,poison,prev → recon → hash。audit-bureau 重算时 delete hash 后
// sha3(JSON.stringify(rec)) 比对，故键序必须一致，否则自证哈希不匹配。
function inlineRecon(rec, prevHash, billedToday, cap) {
  const blob = JSON.stringify(rec);
  const credHit = CRED_RE.test(blob);
  const chainCont = prevHash === "" || rec.prev === prevHash;
  const capOk = billedToday <= cap;
  return { chainCont, credHit, billedToday, capLimit: cap, verdict: (!credHit && chainCont && capOk) ? "CLEAN" : "REVIEW" };
}
function makeAuditRec({ event, detail, sim, poison, prev, billedToday, cap }) {
  const rec = { t: new Date().toISOString(), event, detail, sim, poison, prev };
  rec.recon = inlineRecon(rec, prev, billedToday, cap);
  rec.hash = sha3(JSON.stringify(rec));
  return rec;
}

// ============ ② 历史上下文回应（忠实复现 handleSend 的回带口径） ============
function contextReply({ route, model, jev, todayCalls, cap }) {
  const head = `[bridge] 已收到（隔离复现，不披露席位身份）。路由 ${route} → ${model}。`;
  const body = jev.ok
    ? `${head} 闸全过，将真实计费推理（本程序不外呼，仅记录决策）。`
    : `${head} 路由已判定，本次没有模型推理（${jev.reason}）。`;
  return `${body} 留痕 ${todayCalls}/${cap}。下一次若无密钥或超限，只留痕不外呼。`;
}

// ============ 演示场景：逐闸触发，每步写 ops-trace + audit ============
function runScenarios() {
  fs.rmSync(OUTDIR, { recursive: true, force: true });
  fs.mkdirSync(OUTDIR, { recursive: true });
  const day = dayKey();
  const opsRows = [];
  let lastHash = "";
  const log = [];

  // 每个场景：先按"当前已计费笔数"过闸（历史上下文），再据判定写留痕与审计链。
  // 场景顺序刻意安排：三道 billed:false 的 fail-closed 闸（公开/缺密钥/①doubao 不可调用）放在配额
  // 耗尽之前，使其各自独立触发（此时 todayBilled<cap，不会被日上限闸掩盖）；随后两笔 pass 把当日计费
  // 推到上限，最后一笔触发⑤日上限守护。闸函数判定顺序仍与在役节点一致（公开→日上限→缺密钥→doubao）。
  const scenarios = [
    { name: "匿名入站·未开公开路由（公开闸）", event: "message/send", route: "pangu", model: "openpangu-2.0-pro", authed: false, publicEnabled: false, hasKey: true, apiModel: null, modelId: "openpangu-2.0-pro" },
    { name: "已鉴权·pangu·缺密钥（只留痕不外呼）", event: "message/send", route: "pangu", model: "openpangu-2.0-pro", authed: true, publicEnabled: false, hasKey: false, apiModel: null, modelId: "openpangu-2.0-pro", missing: "未设置 HUAWEI_MAAS_KEY" },
    { name: "已鉴权·doubao 文案名不可调用（①隐性费用闸 fail-closed）", event: "message/send", route: "doubao", model: "Doubao-Seed-Evolving", authed: true, publicEnabled: false, hasKey: true, apiModel: null, modelId: "Doubao-Seed-Evolving" },
    { name: "已鉴权·pangu·配额内（将计费）", event: "message/send", route: "pangu", model: "openpangu-2.0-pro", authed: true, publicEnabled: false, hasKey: true, apiModel: null, modelId: "openpangu-2.0-pro" },
    { name: "已鉴权·pro·配额内（将计费）", event: "message/send", route: "pro", model: "deepseek-v4-pro", authed: true, publicEnabled: false, hasKey: true, apiModel: null, modelId: "deepseek-v4-pro" },
    { name: "已鉴权·pangu·已达日上限（⑤守护触发）", event: "message/send", route: "pangu", model: "openpangu-2.0-pro", authed: true, publicEnabled: false, hasKey: true, apiModel: null, modelId: "openpangu-2.0-pro" },
  ];

  for (const s of scenarios) {
    const todayBilled = opsCallsToday(opsRows, day); // ② 历史上下文：从既有留痕读当日已计费笔数
    const jev = quotaGate({ route: s.route, authed: s.authed, publicEnabled: s.publicEnabled, todayBilled, cap: CAP, hasKey: s.hasKey, apiModel: s.apiModel, modelId: s.modelId, missing: s.missing });

    const opsRow = makeOpsRow({ day, route: s.route, model: s.model, ok: jev.ok, billed: jev.billed, reason: jev.reason, quote: "", cap: CAP, billedToday: todayBilled });
    appendLine(OPS, opsRow);
    opsRows.push(opsRow);

    const auditRec = makeAuditRec({ event: s.event, detail: { scenario: s.name, route: s.route, gate: jev.gate, billed: jev.billed }, sim: null, poison: false, prev: lastHash, billedToday: opsCallsToday(opsRows, day), cap: CAP });
    appendLine(AUDIT, auditRec);
    lastHash = auditRec.hash;

    const afterBilled = opsCallsToday(opsRows, day);
    log.push({ name: s.name, gate: jev.gate, billed: jev.billed, reason: jev.reason, reply: contextReply({ route: s.route, model: s.model, jev, todayCalls: afterBilled, cap: CAP }) });
  }
  return { opsRows, log, day };
}

// ============ 自证校验：链连续 + 自证哈希 + 额度未破 + 零凭据（与 audit-bureau 同口径） ============
function verify(dir) {
  const ops = readJsonl(path.join(dir, "ops-trace.jsonl"));
  const audit = readJsonl(path.join(dir, "audit.jsonl"));
  const problems = [];

  // 1. 审计链：prev 链接 + 自证哈希（delete hash 后重算）
  let prev = "";
  for (let i = 0; i < audit.length; i++) {
    const r = audit[i];
    if (r.prev !== undefined && prev !== "" && r.prev !== prev) { problems.push(`链断裂@${i}: prev 不接续`); break; }
    const rec = { ...r }; const stored = rec.hash; delete rec.hash;
    if (stored && sha3(JSON.stringify(rec)) !== stored) { problems.push(`自证哈希不匹配@${i}`); break; }
    prev = stored || sha3(JSON.stringify(rec));
  }

  // 2. 额度守护：当日计费笔数不得超过 CAP（账本内自洽，用各行 history 反推上限）
  const byDay = {};
  for (const r of ops.filter((x) => x.billed)) { byDay[r.day] = (byDay[r.day] || 0) + 1; }
  for (const [d, n] of Object.entries(byDay)) {
    if (n > CAP) problems.push(`日上限被突破：${d} 计费 ${n} > ${CAP}`);
  }

  // 3. 零凭据：全账本扫描
  const blob = JSON.stringify({ ops, audit });
  if (CRED_RE.test(blob)) problems.push("账本检出疑似凭据物料（红线）");

  // 4. billed 失败面：billed:true 但 ok:false = BILLED_FAILED（隐性费用）
  const billedFailed = ops.filter((r) => r.billed && !r.ok);
  if (billedFailed.length) problems.push(`${billedFailed.length} 笔 billed:true 但 ok:false（BILLED_FAILED 隐性费用）`);

  return { opsRows: ops.length, auditRows: audit.length, billedRows: ops.filter((r) => r.billed).length, billedFailed: billedFailed.length, problems };
}

// ============ 主流程 ============
function main() {
  console.log(`# ⑤额度守护 + ②运维留痕/历史上下文回应 · 隔离复现`);
  console.log(`# 立法锚：「所有调用受额度守护」+「基于历史上下文回应，并生成运维留痕以备对账」`);
  console.log(`# 纪律：零外呼·零凭据·零计费；仅复现在役节点闸链与留痕/审计链。\n`);

  if (verifyOnly) {
    const v = verify(OUTDIR);
    console.log(`[verify] 目录 ${OUTDIR}`);
    console.log(`[verify] ops-trace ${v.opsRows} 行 / 计费 ${v.billedRows} 笔 / audit ${v.auditRows} 行 / 日上限 ${CAP}`);
    if (v.problems.length) { console.log(`[verify] 裁决 REVIEW：\n  - ` + v.problems.join("\n  - ")); process.exit(1); }
    console.log(`[verify] 裁决 CLEAN：链连续·自证哈希匹配·额度未破·零凭据·零 BILLED_FAILED。`);
    return;
  }

  const { log } = runScenarios();
  console.log(`日上限 JEV_DAILY_CAP=${CAP}，落盘目录 ${OUTDIR}\n`);
  console.log(`## 逐闸演示（每步先读历史留痕得过当日已计费笔数，再过闸、再写留痕+审计链）\n`);
  for (let i = 0; i < log.length; i++) {
    const l = log[i];
    console.log(`${i + 1}. ${l.name}`);
    console.log(`   闸=${l.gate}  billed=${l.billed}${l.reason ? "  reason=" + l.reason : ""}`);
    console.log(`   回应=${l.reply}\n`);
  }

  const v = verify(OUTDIR);
  console.log(`## 自证校验（与 audit-bureau 同口径）`);
  console.log(`- ops-trace ${v.opsRows} 行 / 计费 ${v.billedRows} 笔 / audit ${v.auditRows} 行 / billedFailed ${v.billedFailed}`);
  if (v.problems.length) { console.log(`- 裁决 REVIEW：\n  - ` + v.problems.join("\n  - ")); process.exit(1); }
  console.log(`- 裁决 CLEAN：审计 sha3-512 链连续·自证哈希匹配·额度未破·账本零凭据·零 BILLED_FAILED。`);
  console.log(`\n## 与姊妹件③④交接（可选，需 audit-bureau.mjs 在 ../审计局六类对账_v1/）`);
  console.log(`   node ../审计局六类对账_v1/audit-bureau.mjs "${OUTDIR}"   →  应得 verdict CLEAN（最重 INFO）。`);
  console.log(`\n[written] ${OPS}\n[written] ${AUDIT}`);
}

main();
