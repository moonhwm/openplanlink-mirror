# 审计局对账报告 2026-10-01

- 账本目录：`C:\Users\欧阳宏俊\OneDrive\桌面\审计局六类对账_v1\sample-runtime`（只读扫描，未触发任何外呼）
- 口径：ops-trace 5 行 / 计费 3 笔 / audit 4 行；日上限 8
- 总裁决：**CLEAN**（最重 INFO，1 项发现）
- 哈希链：连续，无篡改迹象
- 凭据卫生：账本零凭据物料

## 发现

### [INFO] ANON_BURN_CHECK — 3 笔计费外呼 vs 3 条公开 message/send——若 JEV_PUBLIC=1，匿名入站可触发计费，须确认日上限+密钥闸有效
```json
{"billed":3,"publicSends":3}
```

## 六类对账口径（立法锚）
1. BILLED_FAILED：计费失败仍扣——钱烧在无产出（cache-miss/误计费）。
2. DUPLICATE_BURN：短窗同因重复计费——重试循环。
3. CAP_BREACH / SELF_DOS_SURFACE：日上限突破，或失败外呼占用额度致匿名自锁。
4. ANON_BURN_CHECK：JEV_PUBLIC=1 时匿名入站触发计费外呼的暴露面。
5. CRED_LEAK：账本内凭据物料（红线，零容忍）。
6. CHAIN_BREAK：哈希链断裂=账本被改（篡改取证）。

> 互审边界：本脚本只审本节点自己写下的留痕。其他节点开销=协议提议+自愿加入，
> 只认对方自己写下的留痕，不代打、不臆断。与源件冲突以源件为准，与机主令冲突以机主令为准。