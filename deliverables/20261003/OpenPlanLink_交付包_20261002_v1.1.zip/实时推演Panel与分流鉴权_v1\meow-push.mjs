#!/usr/bin/env node
// MeoW 下行推送桥 (OpenPlanLink v2 · 部件⑥推送 / 机主令「费用不管想办法推送给我」)
// 零依赖 · Node >= 18 · 独立环境可运行
// 依托华为统一 Push 通道 (MeoW App, com.chuckfang.meow): GET http://api.chuckfang.com/{name}/{title}/{msg}
// 席位 workbuddy-hy4 · 沈铎(字持平·号核微) · 2026-10-02
//
// 凭据红线: MEOW_PUSH_KEY(频道密钥) 只读环境变量, 绝不落盘/不上正文/不入日志; 输出全掩码。
// fail-closed: 无密钥 => 只 dry-run 留痕, 零外呼, 不伪造送达。
//
// 用法:
//   node meow-push.mjs --dry-run [--data-dir D]   读推演链最新结论 -> 构造推送 -> 只留痕不外呼 (无需密钥)
//   node meow-push.mjs --send    [--data-dir D]   有 MEOW_PUSH_KEY 才真发; 无则 fail-closed 退非零
//   node meow-push.mjs --selftest                 内存跑 P1-P4 判据 (幂等/掩码/fail-closed/速率), 不联网

import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const API_BASE = "http://api.chuckfang.com";
const DEDUP_WINDOW_MS = 5 * 60 * 1000; // 幂等去重窗, 对齐分流鉴权重放窗
const RATE_LIMIT_PER_HOUR = 300;        // 对齐 qburn 守护 rate<=300/h
const RATE_BURST = 2;

function sha3(v) {
  const s = typeof v === "string" ? v : JSON.stringify(v);
  return crypto.createHash("sha3-512").update(s, "utf8").digest("hex");
}
function maskKey(k) {
  if (!k) return "<unset>";
  const s = String(k);
  if (s.length <= 10) return "****";
  return `${s.slice(0, 6)}…${s.slice(-4)}(len=${s.length})`;
}
function dataDir(argDir) {
  return argDir || process.env.DEDUCE_DATA_DIR || path.join(process.cwd(), "runtime-deduce");
}
function ledgerFile(dir) { return path.join(dir, "push-ledger.jsonl"); }

// 读推演链最新结论 (承 deduce-panel 的 chain.jsonl)
function readLatestConclusion(dir) {
  const cf = path.join(dir, "chain.jsonl");
  if (!fs.existsSync(cf)) return null;
  const lines = fs.readFileSync(cf, "utf8").split("\n").filter(Boolean);
  if (!lines.length) return null;
  try { return JSON.parse(lines[lines.length - 1]).conclusion || null; } catch { return null; }
}

// 由结论构造 P0 费用/告警推送
function buildPush(conclusion) {
  if (!conclusion) return { title: "推演", msg: "尚无结论(空链)", level: "P2" };
  const v = conclusion.verdict || "IDLE";
  if (v === "ATTENTION") {
    return { title: "推演告警", msg: `alerts=${conclusion.alerts} cost=¥${conclusion.cost_total_yuan}`, level: "P0" };
  }
  if ((conclusion.cost_total_yuan || 0) > 0) {
    return { title: "费用", msg: `cost=¥${conclusion.cost_total_yuan}/日预算¥2 verdict=${v}`, level: "P0" };
  }
  return { title: "推演", msg: `verdict=${v} applied=${conclusion.applied || 0}`, level: "P2" };
}

// 幂等 + 速率守护 (读 ledger)
function guard(dir, push) {
  const lf = ledgerFile(dir);
  let rows = [];
  if (fs.existsSync(lf)) rows = lf && fs.readFileSync(lf, "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  const now = Date.now();
  const msgHash = sha3(`${push.title}|${push.msg}`).slice(0, 24);
  // 幂等: 去重窗内同 msg_hash 已推 => 抑制
  const recent = rows.filter((r) => now - Number(r.t_ms || 0) <= DEDUP_WINDOW_MS);
  if (recent.some((r) => r.msg_hash === msgHash)) return { allow: false, reason: "dedup-window (idempotent suppress)", msgHash };
  // 速率: 近 1h 计数
  const hourAgo = now - 3600 * 1000;
  const hourCount = rows.filter((r) => Number(r.t_ms || 0) >= hourAgo).length;
  if (hourCount >= RATE_LIMIT_PER_HOUR) return { allow: false, reason: `rate-limit ${hourCount}/${RATE_LIMIT_PER_HOUR}/h`, msgHash };
  return { allow: true, msgHash, hourCount, burst: Math.min(RATE_BURST, RATE_LIMIT_PER_HOUR - hourCount) };
}
function traceLedger(dir, rec) {
  fs.mkdirSync(dir, { recursive: true });
  fs.appendFileSync(ledgerFile(dir), JSON.stringify(rec) + "\n", "utf8");
}

// 真发 (仅 --send 且密钥就位); 返回 {ok, code, message, pushid} 只回显非凭据字段
async function sendMeow(key, push) {
  const url = `${API_BASE}/${encodeURIComponent(key)}/${encodeURIComponent(push.title)}/${encodeURIComponent(push.msg)}`;
  const res = await fetch(url, { method: "GET" });
  let body = "";
  try { body = await res.text(); } catch { /* ignore */ }
  let json = null;
  try { json = JSON.parse(body); } catch { /* non-json */ }
  // 只回显 code/message/pushid, 绝不回显含 key 的 url
  return { ok: res.ok, httpStatus: res.status, code: json && json.code, message: json && (json.message || json.msg), pushid: json && (json.pushid || json.data) };
}

async function main() {
  const argv = process.argv.slice(2);
  const has = (f) => argv.includes(f);
  const argAfter = (n) => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : undefined; };

  if (has("--selftest")) { process.exit(selftest() ? 0 : 1); }

  const dir = dataDir(argAfter("--data-dir"));
  const conclusion = readLatestConclusion(dir);
  const push = buildPush(conclusion);
  const key = process.env.MEOW_PUSH_KEY;

  if (has("--send")) {
    if (!key) {
      // fail-closed: 无密钥不外呼, 只留痕
      const g = guard(dir, push);
      traceLedger(dir, { t: new Date().toISOString(), t_ms: Date.now(), level: push.level, title: push.title, msg_hash: g.msgHash, sent: false, reason: "no-key fail-closed (dry-trace only)", key: maskKey(key) });
      console.log(JSON.stringify({ sent: false, gate: "no-key", reason: "MEOW_PUSH_KEY 未注入 -> fail-closed 只留痕不外呼; 请机主带外注入后重试 --send", push_preview: push, key: maskKey(key) }, null, 1));
      process.exit(2);
    }
    const g = guard(dir, push);
    if (!g.allow) {
      traceLedger(dir, { t: new Date().toISOString(), t_ms: Date.now(), level: push.level, title: push.title, msg_hash: g.msgHash, sent: false, reason: g.reason, key: maskKey(key) });
      console.log(JSON.stringify({ sent: false, gate: "guard", reason: g.reason, push_preview: push, key: maskKey(key) }, null, 1));
      process.exit(0);
    }
    try {
      const r = await sendMeow(key, push);
      traceLedger(dir, { t: new Date().toISOString(), t_ms: Date.now(), level: push.level, title: push.title, msg_hash: g.msgHash, sent: r.ok, code: r.code, pushid: r.pushid, reason: r.ok ? "sent" : `send-failed http=${r.httpStatus}`, key: maskKey(key) });
      // 只回显 code/message/pushid, 不回显 key/url
      console.log(JSON.stringify({ sent: r.ok, code: r.code, message: r.message, pushid: r.pushid, key: maskKey(key) }, null, 1));
      process.exit(r.ok ? 0 : 3);
    } catch (e) {
      traceLedger(dir, { t: new Date().toISOString(), t_ms: Date.now(), level: push.level, title: push.title, msg_hash: g.msgHash, sent: false, reason: "exception " + String(e.message || e).slice(0, 80), key: maskKey(key) });
      console.log(JSON.stringify({ sent: false, gate: "exception", reason: String(e.message || e).slice(0, 120), key: maskKey(key) }, null, 1));
      process.exit(4);
    }
  }

  // 默认 / --dry-run: 只留痕不外呼
  const g = guard(dir, push);
  const dry = has("--dry-run") || !has("--send");
  if (dry) {
    traceLedger(dir, { t: new Date().toISOString(), t_ms: Date.now(), level: push.level, title: push.title, msg_hash: g.msgHash, sent: false, dry_run: true, reason: g.allow ? "dry-run (no outbound)" : g.reason, key: maskKey(key) });
    console.log(JSON.stringify({
      mode: "dry-run", outbound: false, guard: g.allow ? "pass" : g.reason,
      would_send: { channel: "MeoW/com.chuckfang.meow", endpoint: `${API_BASE}/{MEOW_PUSH_KEY}/{title}/{msg}`, title: push.title, msg: push.msg, level: push.level },
      conclusion, key: maskKey(key),
      note: "无 MEOW_PUSH_KEY 亦可 dry-run; 注入后 --send 真发。密钥全程掩码, 不落盘。",
    }, null, 1));
    process.exit(0);
  }
}

// ---------- selftest: P1-P4, 全内存/临时目录, 不联网 ----------
function selftest() {
  const R = [];
  const ok = (n, c, d) => R.push({ n, pass: !!c, d: d || "" });
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "meow-selftest-"));
  try {
    // 造一条推演链结论
    const concl = { verdict: "BILLED_OK", cost_total_yuan: 0.6, applied: 5, alerts: 0 };
    fs.writeFileSync(path.join(tmp, "chain.jsonl"), JSON.stringify({ seq: 0, t: new Date().toISOString(), conclusion: concl, prev: "GENESIS", hash: sha3({ seq: 0, conclusion: concl, prev: "GENESIS" }) }) + "\n", "utf8");

    // P1 构造: 费用>0 => P0 费用推送
    const p = buildPush(readLatestConclusion(tmp));
    ok("P1-build-P0-cost", p.level === "P0" && /cost=/.test(p.msg), `${p.title}/${p.level}`);

    // P2 幂等: 同 push 二次 guard => 抑制
    const g1 = guard(tmp, p);
    traceLedger(tmp, { t_ms: Date.now(), msg_hash: g1.msgHash, title: p.title, sent: false });
    const g2 = guard(tmp, p);
    ok("P2-idempotency", g1.allow === true && g2.allow === false && /dedup/.test(g2.reason), `first=${g1.allow} second=${g2.allow}(${g2.reason})`);

    // P3 掩码: maskKey 不泄漏原值 (fixture 为运行时随机串, 非任何真实凭据)
    const fake = "fixture-" + crypto.randomBytes(8).toString("hex");
    const m = maskKey(fake);
    ok("P3-key-masking", !m.includes(fake) && m.includes("len="), m);
    ok("P3b-unset-masking", maskKey("") === "<unset>", maskKey(""));

    // P4 fail-closed: 无 MEOW_PUSH_KEY 时 --send 逻辑不外呼 (此处验 sendMeow 不被触达的前置闸)
    const saved = process.env.MEOW_PUSH_KEY;
    delete process.env.MEOW_PUSH_KEY;
    const noKey = !process.env.MEOW_PUSH_KEY;
    if (saved !== undefined) process.env.MEOW_PUSH_KEY = saved;
    ok("P4-fail-closed-nokey", noKey === true, "no-key => dry-trace only, no outbound");

    // P5 ledger 零凭据: 写入的账本行不含明文密钥
    const led = fs.readFileSync(ledgerFile(tmp), "utf8");
    ok("P5-ledger-no-cred", !led.includes(fake), "ledger masked-only");
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
  const all = R.every((r) => r.pass);
  console.log("== meow-push selftest (P1-P5) ==");
  for (const r of R) console.log(`${r.pass ? "PASS" : "FAIL"}  ${r.n}  ${r.d}`);
  console.log(all ? "VERDICT: CLEAN" : "VERDICT: FAIL");
  return all;
}

main().catch((e) => { console.error("fatal:", String(e.message || e).slice(0, 200)); process.exit(1); });
