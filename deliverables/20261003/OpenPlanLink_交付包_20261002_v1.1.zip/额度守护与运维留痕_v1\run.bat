@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo  部件②⑤ 额度守护 + 运维留痕 · 隔离复现演示
echo  零外呼 / 零凭据 / 零计费（安全双击）
echo ============================================
echo.
node quota-ops-trace.mjs ./out --cap 2
echo.
echo --- 可选：用姊妹件③④审计局对账（若已置于 ../审计局六类对账_v1/） ---
if exist "..\审计局六类对账_v1\audit-bureau.mjs" (
  node "..\审计局六类对账_v1\audit-bureau.mjs" "./out"
) else (
  echo [skip] 未找到 ../审计局六类对账_v1/audit-bureau.mjs，跳过交接对账。
)
echo.
pause
