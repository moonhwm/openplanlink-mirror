# openplanlink-mirror 仓库连通分析报告

**分析**：沈铎（字持平·号核微）·鉴微审计团 ⚖️
**席位/指纹**：`workbuddy-hy4` · fp_sha256 `da8ab33298b9394b`
**日期**：2026-10-01（机主令「我的仓库，您连上不就可以继续」）
**对象**：`github.com/moonhwm/openplanlink-mirror`（经 GitHub 连接器，身份 moonhwm）

---

## 一、连通结论（如实）

| 项 | 结果 | 说明 |
|---|---|---|
| 连接器身份 | ✅ moonhwm（id 321523707） | `get_me` 实证 |
| 读权限 | ✅ 全仓库可读 | agent-card/attest/skills/tools/目录树均可拉取 |
| **写权限** | ❌ **403 Resource not accessible by integration** | `push_files`/`list_collaborators` 均 403，**集成令牌整体只读**（非单仓问题——`k3-handshake` 自有仓同 403） |
| 默认分支 | `main`（sha `5fbd62f7`，protected=false） | — |

**裁定**：机主令「连上仓库即可继续」的**读取面已通**，但**写入面被集成令牌的只读 scope 硬阻断**，非本席可解——需在 GitHub App/集成设置里为该集成授 `contents:write`（或换用有写权限的 PAT）。本席不硬闯、不臆造已写入。

## 二、仓库实质（读面吃透）

- **性质**：OpenPlanLink 幻16 桥接节点的**公网静态镜像 + 完整性自证载体**，desktop-gengfu（根甫）维护，引用不复制原则（上游再构建覆盖属预期）。
- **完整性自证**：`/attest.json` 携带 27 文件 SHA3-512 Merkle 根 + ed25519 签名，五面公网入口（主力 `116.62.106.37:8080`、CloudBase、GitHub Pages、jsdelivr、姊妹节点 `120.46.86.165`）。
- **真实 agent-card.json**（SHA `d5591b76`）：与 README 描述有出入——实际用 `serveousercontent.com` 隧道 URL、`skills` 含 `bridge-echo`（回桥元数据+席位键+指纹+总线快照）、organization=「workbuddy-hy4 / 砚 (hy4)」、主模式 text/plain。**本席已据此把 qtorrent 补丁版 agent-card 校准为 patch.2**（对齐 skills 字段/text/plain/简洁 capabilities）。
- **skills/ 目录 = 110+ 技能库**：机主此前投送的 zip 同名件全在册——vector-verdict-ops / video-seer / webpage-forge-ops / moongate-craft / moonforge-ops / loop-dual-pillar-ops / cron-task-forge / evidence-chain-verifier / 等。这是 OpenPlanLink 生态的技能资产面。

## 三、关键技术发现：verify.mjs 的「自洽 vs 内容」边界（判据复用）

`tools/verify.mjs`（SHA `fef6f0b9`）的验证逻辑：
- ✅ 复算 `attest.json` 里 `files` 声明的 SHA3-512 Merkle 根，与 `merkle_root` 比对；
- ✅ 用内嵌 `pubkey` 验 `sig`（ed25519）；
- ❌ **但它只读 attest.json 本身，从不重新下载各真实文件复算哈希**。

**含义（判据「验自洽≠验内容」再现）**：
- 若文件被改且**重签 attest** → verify 仍 EXIT=0（只证明「这份 attest 自洽+签名有效」）。
- 若文件被改但**不重签** → 根对不上，EXIT=1（能发现）。
- 故 verify.mjs 的有效性依赖「attest 与文件同源同步更新」这一前提——它防的是「篡改文件不动声明」与「伪造无签名声明」，**防不住「连声明一起重签的完整替换」**。

**本席的 `gen_attest.mjs` 补的正是这一环**：它**从真实文件重新算 Merkle 根**（内容级证明），而非仅验声明自洽。两者关系：verify.mjs 验「声明可信」，gen_attest.mjs 证「声明与实体一致」。完整性闭环需两者并用——先 gen_attest 从实体算根，再 verify 验签名，且公钥须带外核对（防连公钥一起换）。

## 四、对 OpenPlanLink v2 的衔接

1. **推演 Panel 完整性锚定**：直接复用 mirror 的 `opl-attest/1` schema + gen_attest 内容级算根 + verify 验签双件套，坐享既有信任面。
2. **qtorrent 补丁 patch.2 已校准**：与 mirror 真实 agent-card 同构（skills/text/plain），握手四重互证（判据52）中「agent-card 可达」与「签名可验」两件已具范本。
3. **技能库 110+**：MicroFish 类开源项目接入推演 Panel 时，可从 skills/ 直接引入 `vector-verdict-ops`（向量裁定）、`evidence-chain-verifier`（证据链核验）、`quota-guard-ops`（额度守护）等作推演规则插件。

## 五、候机主裁定

1. **写权限**：是否为 GitHub 集成授 `contents:write`（或提供有写权限的 PAT 经环境变量）？一配，本席即可把 qtorrent 补丁四件 + 推演 Panel 推入仓库并开 PR。
2. **推送目标仓**：openplanlink-mirror（由根甫维护，引用不复制）还是 k3-handshake（K3 交接公开仓）？默认建议后者（mirror 上游会被覆盖，补丁宜入交接仓）。
3. **verify.mjs 空洞**：是否照准本席补一份「verify-content.mjs」（重新下载文件复算根，防连声明重签）交码道？

---

**落款**：沈铎（字持平·号核微）·鉴微审计团 ⚖️
**席位**：`workbuddy-hy4` · fp_sha256 `da8ab33298b9394b`
**注**：全部结论基于 GitHub 连接器真实读写测试（读 ✅ / 写 403），未硬闯、未臆造已写入；凭据全程不落盘。
