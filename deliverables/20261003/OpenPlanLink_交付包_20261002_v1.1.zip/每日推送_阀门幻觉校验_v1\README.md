# 每日推送 · 阀门 + 幻觉校验（v1）

把「条件允许时每日推送一条契合自我认知偏好的著作原文，经阀门机制与幻觉校验双重核验后嵌入流程，而非固定推送」落成一个**可独立运行的完整程序**。纯 Node，无第三方依赖。

## 运行入口

```bash
node daily-push.mjs --list      # 查看语料 + 契合分
node daily-push.mjs --dry-run   # 跑阀门+幻觉校验，打印将推送的内容，但不发送（无需密钥）
node daily-push.mjs             # 正式推送（需 SERVERCHAN_SENDKEY）
node daily-push.mjs --force     # 跳过去重闸（仍过幻觉校验）
node daily-push.mjs --reseed    # 重新封印语料指纹（仅在你有意修改语料后执行）
```

定时（可选，Windows 计划任务 / cron 各一条，本地时 08:00）：

```
node "C:\Users\欧阳宏俊\OneDrive\桌面\每日推送_阀门幻觉校验_v1\daily-push.mjs"
```

## 依赖清单

- Node.js >= 18（实测 v24.19.0）。用到内置 `node:crypto`（sha3-512）、`node:fs`、全局 `fetch`。
- 无 npm 包。无需联网即可 `--list` / `--dry-run`；仅正式发送时访问 Server酱 `sctapi.ftqq.com`。
- 密钥：环境变量 `SERVERCHAN_SENDKEY`。**程序只按名读取，绝不回显 key 或完整 url**；缺失即 fail-closed（不发送、退出码 1）。

## 两道核验

### 1. 幻觉校验（自封印 sha3-512）
- 首跑把每条语料正文的 sha3-512 写入 `seal.json`。
- 此后每次运行重算并比对：**正文一旦漂移（被改/记错/注入），阀门直接关闭**，输出 `幻觉校验失败·文本漂移 drift=[id]`，绝不推送未经核验的「原文」。
- 这保证「推送的著作原文」永远是封印时那一份逐字文本，杜绝模型即时编造引文。

### 2. 阀门机制（四闸，全过才开 → 非固定推送）
1. **幻觉闸**：seal 比对通过。
2. **幂等闸**：当日已成功推送过则不再推。
3. **时窗闸**：仅在本地时 07:00–23:00 推。
4. **契合/去重闸**：偏好契合分 ≥ 阈值（默认 3），且该条 7 天内未推过；取契合分最高者。

任一闸不过 → `gate:closed` + 原因，不发送。

## 偏好契合打分
`PROFILE` 给「自知/自省/自胜/求知/自强…」等主题加权，语料 `tags` 命中求和即契合分。当前语料 6 条（道德经·33/8、周易·乾/坤、论语·学而、庄子·养生主），`ddj-33`（知人者智，自知者明…）契合分最高=8。要改偏好就编辑 `PROFILE`/`THRESHOLD`；要加语料就往 `CORPUS` 追加（逐字准确），然后 `--reseed` 重新封印。

## 文件
- `daily-push.mjs` — 主程序（语料+封印+阀门+推送，单文件自包含）
- `seal.json` — 语料 sha3-512 封印（运行时生成，勿手改）
- `ledger.json` — 推送台账（date/id/sha3/pushed/code/pushid），幂等与去重依据

## 与节点的关系
本程序是「推送给我」通道的**本地可交付实现**。X 活面 `/root/handshake/runtime/push.mjs` 是同一推送逻辑的节点侧副本（同样按名读 key、fail-closed）。`SERVERCHAN_SENDKEY` 带外注入后，本地 `node daily-push.mjs` 或节点侧 `push.mjs` 即可实发；发送结果只输出 Server酱 `code/message/pushid`。

## 自测记录（2026-10-01）
- `--list`/`--dry-run` 正常，阀门开、选 `ddj-33`、正文与 sha3 前缀正确。
- 无 key 全量跑：fail-closed，退出码 1，未回显任何密钥。
- 篡改 `seal.json` 指纹：阀门关闭并报 `drift=[ddj-33]`；`--reseed` 复位后恢复 open。四闸全验通过。

---

## 增补（2026-10-01）：双击运行入口
- 新增 `run.bat`：双击即对内置语料跑一遍 `--dry-run`（阀门+幻觉校验，打印将推送内容，**不发送、不落账、无需密钥**）。正式推送仍按上文 `node daily-push.mjs`（需 `SERVERCHAN_SENDKEY` 带外注入）。与③④审计局交付的 `run.bat` 入口对称。

## 签署核验意见
本程序（`daily-push.mjs` + `seal.json` + `ledger.json` + `README.md` + `run.bat`）经逐字通读与自测核验：四闸（幻觉/幂等/时窗/契合去重）逻辑正确，自封印 sha3-512 防引文漂移，Server酱 fail-closed 且只按名读 key、回显仅 `code/message/pushid`，无密钥落盘。符合「经阀门与幻觉校验后嵌入流程，而非固定推送」之令。
- 身份：OpenPlanLink 协商握手节点（席位 workbuddy-hy4）
- 核验日期：2026-10-01
- 贡献：补 `run.bat` 双击运行入口，闭合与③④审计局交付的入口对称；补本签署核验意见。
