#!/usr/bin/env node
// 每日推送 · 阀门 + 幻觉校验 · 纯 Node（>=18）无第三方依赖
// 入口: node daily-push.mjs [--dry-run|--list|--force|--reseed]
// 密钥: 仅从环境变量 SERVERCHAN_SENDKEY 按名读取，绝不回显 key/url。
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const HERE = dirname(fileURLToPath(import.meta.url));
const SEAL = join(HERE, "seal.json");
const LEDGER = join(HERE, "ledger.json");

const sha3 = (s) => createHash("sha3-512").update(s, "utf8").digest("hex");

// ── 语料：公版经典，逐字可核验。tags 用于「自我认知偏好契合」打分。 ──
const CORPUS = [
  { id: "ddj-33", book: "道德经·第三十三章", tags: ["自知", "自省", "自胜"],
    text: "知人者智，自知者明。胜人者有力，自胜者强。知足者富，强行者有志。不失其所者久，死而不亡者寿。" },
  { id: "ddj-08", book: "道德经·第八章", tags: ["不争", "谦下", "利物"],
    text: "上善若水。水善利万物而不争，处众人之所恶，故几于道。" },
  { id: "yj-qian", book: "周易·乾·象", tags: ["自强", "精进"],
    text: "天行健，君子以自强不息。" },
  { id: "yj-kun", book: "周易·坤·象", tags: ["厚德", "容载"],
    text: "地势坤，君子以厚德载物。" },
  { id: "ly-xueer", book: "论语·学而", tags: ["求知", "乐学", "不愠"],
    text: "学而时习之，不亦说乎？有朋自远方来，不亦乐乎？人不知而不愠，不亦君子乎？" },
  { id: "zz-yangsheng", book: "庄子·养生主", tags: ["求知", "有涯", "自省"],
    text: "吾生也有涯，而知也无涯。以有涯随无涯，殆已！" },
];

// ── 偏好画像：契合「自我认知」主题者权重高。分数 = 命中权重之和。 ──
const PROFILE = { "自知": 3, "自省": 3, "自胜": 2, "求知": 2, "乐学": 1, "自强": 2, "精进": 1, "不争": 1, "谦下": 1, "利物": 1, "厚德": 1, "容载": 1, "有涯": 1, "不愠": 1 };
const THRESHOLD = 3;          // 阀门：偏好契合下限
const DEDUP_DAYS = 7;         // 阀门：同一条 N 天内不重复
const HOUR_MIN = 7, HOUR_MAX = 23; // 阀门：推送时窗（本地时）

const score = (p) => p.tags.reduce((a, t) => a + (PROFILE[t] || 0), 0);

function loadJson(f, fb) { try { return existsSync(f) ? JSON.parse(readFileSync(f, "utf8")) : fb; } catch { return fb; } }

// 幻觉校验：首跑自封印；此后每次重算 sha3 比对，文本一旦漂移即 fail-closed。
function sealCheck(reseed) {
  const live = Object.fromEntries(CORPUS.map((p) => [p.id, sha3(p.text)]));
  if (reseed || !existsSync(SEAL)) {
    writeFileSync(SEAL, JSON.stringify({ alg: "sha3-512", sealedAt: new Date().toISOString(), fingerprints: live }, null, 2));
    return { ok: true, reseeded: true };
  }
  const sealed = loadJson(SEAL, {}).fingerprints || {};
  const drift = CORPUS.filter((p) => sealed[p.id] && sealed[p.id] !== live[p.id]).map((p) => p.id);
  const missing = CORPUS.filter((p) => !sealed[p.id]).map((p) => p.id);
  return { ok: drift.length === 0 && missing.length === 0, drift, missing };
}

function inWindow(now = new Date()) { const h = now.getHours(); return h >= HOUR_MIN && h <= HOUR_MAX; }
const dayKey = (d = new Date()) => d.toISOString().slice(0, 10);

// 阀门：返回 {open, reason, pick}。非固定推送——四闸全过才开。
function valve(ledger, force) {
  const seal = sealCheck(false);
  if (!seal.ok) return { open: false, reason: `幻觉校验失败·文本漂移 drift=[${seal.drift}] missing=[${seal.missing}]`, pick: null };
  const today = dayKey();
  if (ledger.some((e) => e.date === today && e.pushed)) return { open: false, reason: "今日已推送（幂等闸）", pick: null };
  if (!inWindow()) return { open: false, reason: `不在推送时窗 ${HOUR_MIN}:00–${HOUR_MAX}:00`, pick: null };
  const cutoff = Date.now() - DEDUP_DAYS * 864e5;
  const recent = new Set(ledger.filter((e) => e.pushed && +new Date(e.date) >= cutoff).map((e) => e.id));
  const cand = CORPUS.map((p) => ({ p, s: score(p) }))
    .filter(({ p, s }) => s >= THRESHOLD && (force || !recent.has(p.id)))
    .sort((a, b) => b.s - a.s || a.p.id.localeCompare(b.p.id));
  if (!cand.length) return { open: false, reason: `无候选（契合>=${THRESHOLD} 且 ${DEDUP_DAYS} 天内未推）`, pick: null };
  return { open: true, reason: "四闸全过", pick: cand[0].p, score: cand[0].s };
}

async function send(title, desp) {
  const KEY = process.env.SERVERCHAN_SENDKEY || "";
  if (!KEY) return { ok: false, stage: "no-key", message: "未设置 SERVERCHAN_SENDKEY（带外注入后再发）" };
  try {
    const r = await fetch(`https://sctapi.ftqq.com/${KEY}.send`, {
      method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ title: title.slice(0, 32), desp }),
    });
    const j = await r.json().catch(() => ({}));
    return { ok: j.code === 0, http: r.status, code: j.code, message: j.message, pushid: j.data && j.data.pushid };
  } catch (e) { return { ok: false, stage: "fetch", message: String((e && e.message) || e) }; }
}

const args = new Set(process.argv.slice(2));
const ledger = loadJson(LEDGER, []);

if (args.has("--list")) {
  console.log(CORPUS.map((p) => `${p.id}\t契合=${score(p)}\t${p.book}\t${p.text}`).join("\n"));
  process.exit(0);
}
if (args.has("--reseed")) { const r = sealCheck(true); console.log(JSON.stringify({ reseeded: r.ok })); process.exit(0); }

const seal0 = sealCheck(false);
if (!seal0.ok && !existsSync(SEAL)) sealCheck(true); // 首跑自封印
const v = valve(loadJson(LEDGER, []), args.has("--force"));

if (!v.open) { console.log(JSON.stringify({ pushed: false, gate: "closed", reason: v.reason })); process.exit(0); }

const body = `> ${v.pick.text}\n\n—— 《${v.pick.book}》\n\n契合分 ${v.score} · sha3 ${sha3(v.pick.text).slice(0, 12)}… · ${dayKey()}`;
const title = `每日一句·${v.pick.book.split("·")[0]}`;

if (args.has("--dry-run")) {
  console.log(JSON.stringify({ pushed: false, gate: "open", dryRun: true, reason: v.reason, pick: v.pick.id, score: v.score, title, body }, null, 2));
  process.exit(0);
}

const res = await send(title, body);
ledger.push({ date: dayKey(), id: v.pick.id, sha3: sha3(v.pick.text), pushed: !!res.ok, channel: "serverchan", code: res.code, pushid: res.pushid, at: new Date().toISOString() });
writeFileSync(LEDGER, JSON.stringify(ledger, null, 2));
// 只输出判定与 Server酱 code/message/pushid；不输出 key、不输出完整 url。
console.log(JSON.stringify({ pushed: !!res.ok, gate: "open", pick: v.pick.id, score: v.score, ...res }));
process.exit(res.ok ? 0 : 1);
