# OpenPlanLink v2 改写方案 · 移动闭环 + 实时推演 + 分流鉴权

**起草**：沈铎（字持平·号核微）·鉴微审计团 ⚖️（协助码道 GLM-5.2 ArkTS 席改写）
**席位/指纹**：`workbuddy-hy4` · fp_sha256 `da8ab33298b9394b`
**日期**：2026-10-01（自主推进窗口 → 23:00）
**上游**：`2026-9-25-OpenPlanLink 润色-1 (3) 修订版V2_DF-REV-V55-01.docx`（四元组基线 sha256 `46da6358…`）
**定位**：协调稿非决议；不改上游在役源件，以补丁/方案形式交码道席裁定合入

---

## 〇、机主令去重与映射

机主原令（三段重复，去重后）映射为本方案四大改造块：

| 机主要求 | 改造块 | 本文章节 |
|---|---|---|
| 结合两个 AppGallery 应用改写开放计划 | 移动闭环（SSH 上行 + MeoW 下行） | 一 |
| 完善网络鉴权 + 分流鉴权 | 分流鉴权层设计 | 二 |
| 开放为实时推演（MicroFish 类开源项目直接 Panel） | 实时推演 Panel 架构 | 三 |
| 与 kimi k2.8 造的 qtorrent 站握手协同 + 防污染语料 | qtorrent 握手补丁 + 语料卫生 | 四 |
| 广泛握手 openplanlink-mirror | 镜像面整合 | 五 |
| 到 23 点、费用不管想办法推送给我 | MeoW 推送通道 + 23:00 时限 | 一、六 |

**协助边界（判据68）**：本席不驱动码道席的 ArtCode IDE GUI，仅产出可机检的方案件与补丁，交码道席裁定。GLM-5.2 ArkTS 神经中枢侧的进程认领以「方案对齐 + 接口契约」方式协同，不接管其运行实例。

## 一、移动闭环：两个 AppGallery 应用的接入（自主下载分析结论）

### 1.1 应用身份核验（WebSearch 服务端第一手，非壳页臆测）

| 包名 | 实名 | 开发者 | 性质 | 对 OpenPlanLink 的价值 |
|---|---|---|---|---|
| `com.wzdxy.ssh.h` | 南瓜SSH 类 HarmonyOS NEXT 原生 SSH 客户端 | 第三方（鸿蒙生态） | SSH/SFTP/密钥登录/模拟终端，密钥本地存储不上云 | **上行运维通道**：手机/平板/PC 三端 SSH 进 X 实例（120.46.86.165）与幻16 桥，移动运维 A2A 节点 |
| `com.chuckfang.meow` | MeoW 鸿蒙消息推送 | 方城（chuckfang，96 年个人开发者，36-37 万下载） | 依托华为统一 Push 通道，无需常驻后台 | **下行推送通道**：A2A 事件/告警/费用直达机主鸿蒙设备 |

### 1.2 MeoW 下行推送——「费用不管想办法推送给我」的现成通路

MeoW 的核心杀手特性是 **HTTP GET 即推送**（官方 API 文档 `chuckfang.com/MeoW/api_doc.html`）：

```
GET http://api.chuckfang.com/{name}/{title}/{msg}?url={url}
```

- `name`＝机主在 MeoW 内生成的专属频道名/密钥
- `title`/`msg`＝推送标题与正文
- 依托华为统一 Push 通道，App 不常驻、划掉后台照样收，省电不占内存

**接入设计（A2A 事件 → MeoW 推送桥）**：

```
A2A 事件源（总线 cross_mode_channel / qburn 费用 / 推演 Panel 告警）
   ▼
meow_push.mjs 桥（新增，幂等 + 速率守护）
   ├─ 事件分级：P0 立即推 / P1 聚合每 15min / P2 日报
   ├─ 幂等：msg_hash = sha3_512(name|title|msg)[:16] 去重窗 5min（防重复扣推送额度）
   ├─ 速率：对齐 qburn 守护 rate≤300/h burst=2（判据Q2）
   ▼
GET api.chuckfang.com/{MEOW_NAME}/{title}/{msg}
   ▼
机主鸿蒙设备（系统级 Push）
```

- **费用推送（机主点名）**：qburn 账本每结算一笔 `cost_yuan>0` 或日累计超阈值即 P0 推 `title=费用 msg=cost_yuan=¥X.XX/日预算¥2`。
- **凭据纪律（红线）**：`MEOW_NAME`（频道密钥）**不落盘、不上总线**，读机主环境变量 `MEOW_PUSH_KEY`；脚本只 `os.environ.get("MEOW_PUSH_KEY")`，严禁字面写入任何交付件（判据：临时调试脚本是泄漏高发区）。
- **url 参数**：附 A2A 总线快照页 `http://120.46.86.165/` 让机主一键跳回源头。

### 1.3 SSH 上行运维——移动终端认领头口

南瓜SSH 类客户端提供手机端 SSH/SFTP/密钥登录，可接入：
- X 实例 `120.46.86.165:22`（已 PermitOpen 8099 A2A / 8090 jw_sync / 8017 LLM；判据84）
- 幻16 桥（总线宿主）

**价值**：机主/各席可从鸿蒙移动端发起运维、查看总线、触发推演，补齐「24h 无人自适应」之外的「有人移动介入」面。密钥登录（ED25519）与既有 `PermitOpen` 白名单、密钥-only 登录策略一致（mirror 安全节同款）。

## 二、网络鉴权完善 + 分流鉴权层

机主「我尝试做个分流鉴权」——本席给出可机检的分流鉴权设计，对接 mirror 已有的 ed25519 白名单与总线零身份校验 P0 缺口（SECURITY_MASTER_REPORT §二，两军问题活体）。

### 2.1 现状缺口（如实）

- A2A 总线 `cross_mode_channel` **零身份校验**（P0，名册 §四已自认「两军问题在 A2A 的活体」）。
- mirror 只读面用 ed25519 公钥白名单，但总线写入面无鉴权。
- 微信侧入口被 `wappoc_appmsgcaptcha` 拦截（判据50：登录墙后正文不可抓，本席不硬闯）。

### 2.2 分流鉴权三层设计（按信任域分流）

| 层 | 信任域 | 鉴权方式 | 放行流量 |
|---|---|---|---|
| **S0 公开只读** | 任何人 | 无鉴权（静态镜像 + attest 自证） | mirror 五面、`/attest.json`、`/.well-known/agent-card.json`、总线快照页 |
| **S1 在册席位** | ed25519 公钥白名单内席位 | 请求带 `X-A2A-Seat` + `X-A2A-Sig`（对 `ts‖method‖path‖body_sha3` 的 ed25519 签名） | 总线写、推演触发、心跳登记 |
| **S2 机主专属** | 机主持有的 MeoW 密钥 + 管理 token | 双因子：管理 token（env）+ MeoW 推送回执确认 | 费用结算改写、席位增删、根值封锚 |

- **验签要点（判据「验自洽≠验内容」再现）**：S1 验签**必须重算 `body_sha3` 并与签名单向绑定**，防「签名有效但 body 被换」；时间戳 `ts` 窗 ±5min 防重放（对齐 MeoW 幂等窗）。
- **分流器落点**：建议复用 X 实例中继 v3（8080 路由）前置一层鉴权中间件，`/sync→8090`、`/llm→8017`、其余→8099 的现有路由不动，只在 8080 入口加 S1 验签——**最小侵入，不改在役业务逻辑**（判据：不改他方在役源码，出补丁交码道）。
- **后量子预留**：签名层沿用 mirror `sig_alg` 迁移位，liboqs/SLH-DSA 就绪即切（与既有 PQ 迁移序 P0–P4 一致）。

## 三、开放为实时推演 Panel（MicroFish 类开源项目前置）

机主：「作为后续 MicroFish 等类似开源项目的直接 Panel」。设计一个**零信任、可机检、可复算**的实时推演面板，直接复用白天版沙盘的物理层与 mirror 的完整性自证。

### 3.1 架构（前后端分离 + 完整性锚定）

```
数据源（A2A 总线 / qburn / MeoW 事件 / X 实例探针）
   ▼
ingest.mjs（采集 + 幂等 + 落 JSONL，append-only）
   ▼
deduce-core.mjs（推演核：状态机 + 规则引擎，确定性播种可复算）
   ├─ 输入：JSONL 事件流
   ├─ 输出：推演结论 + 中间量（暴露 window.DEDUCE 供第三方复算）
   ▼
panel.html（实时渲染，WebSocket/SSE 推送，零 CDN 单文件）
   ▼
attest：每次推演结论落 SHA3-512 快照链（承 pbft_min 快照链思路）
```

### 3.2 可机检判据（承白天版沙盘四判据风格）

| # | 判据 | 机检方式 |
|---|---|---|
| D1 | 推演确定性：同输入同播种 ⇒ 同输出 | 重放 JSONL + 固定 seed，输出逐字节比对 |
| D2 | 幂等：重复事件不重复改结论 | P²=P（二次到达结论/游标不动） |
| D3 | 完整性：推演结论链 hash 衔接、前驱在册 | 快照链验链（篡改即断） |
| D4 | 实时性：事件→面板渲染延迟可测 | 打点 `t_event`/`t_render`，P95 延迟公示 |
| D5 | MicroFish 兼容：开源项目以标准 JSONL 接入即可上 Panel | 提供 `panel-sdk` 接入契约 |

### 3.3 MicroFish 接入契约（直接 Panel 的关键）

任何 MicroFish 类开源项目只需：
1. 以 JSONL 追加事件到 `ingest`（schema：`{ts, src, kind, payload}`）
2. 可选注册自定义推演规则（JS 函数，沙箱执行）
3. 自动获得：实时渲染 + 完整性锚定 + MeoW 告警下行

**与现有资产复用**：推演核可嫁接 `verify_sandbox.py` 的确定性播种与四判据断言骨架；完整性锚定复用 mirror `attest.json` 的 SHA3-512 Merkle + ed25519 签名机制。

## 四、qtorrent 握手协同 + 防污染语料

### 4.1 qtorrent 现状核验（第一手）

- **它是**：kimi k2.8 preview 集群造的「门厅·A2A 观测站」，版本 c1a9b5d，在案登记 4 项，PQ 指纹 `b3cffb08…034a`，六页（观测 observe/神谕 oracle/沙盘 sandbox/干涉海 sea/飞天 cinema/拓扑 a2a-architecture）。
- **关键缺口（双 404 实证）**：`/.well-known/agent-card.json` 与 `/llms.txt` 均 404——**它不是标准 A2A 0.3.0 节点**，无机器可读发现端点，无法被 A2A 网络自动发现与握手。这正是机主「这个是您需要继续完善的」的实质。

### 4.2 握手补丁（交码道席 / qtorrent 维护者合入）

为 qtorrent 补标准 A2A 发现面，使其可被 OpenPlanLink 网络握手：

1. **补 `/.well-known/agent-card.json`**：以 mirror 的 agent-card 为范本，声明 qtorrent 的 name/url/capabilities/seats（seat 可登记为 `qtorrent-kimik28`，tier L2）。
2. **补 `/llms.txt`**：机器可读导引，声明六页用途与数据口径。
3. **补 `attest.json`**：对齐 mirror 的 SHA3-512 Merkle + ed25519 自证，让 qtorrent 内容可公开验证未篡改。
4. **握手四重互证（判据52）**：agent-card 可达 ∧ 签名可验 ∧ 席位在册 ∧ 回执衔接，四者齐才算握手成功。

### 4.3 防污染语料（机主红线「别被污染语料了」）

qtorrent 页面已自带声明「该网页包含 AI 生成内容（可能经用户编辑），请仔细核实」。防污染机制：

| 措施 | 说明 |
|---|---|
| **来源隔离** | qtorrent 内容进推演 Panel 前打 `src=qtorrent-kimik28, trust=unverified` 标，与已核源（学术/政府/总线）分区存储，不混入已核语料库 |
| **先验后采** | 凡 qtorrent 输出的断言/数据，须过「第一手回溯」才可升为已核（判据71：他席转述未回溯第一手须写[未核]） |
| **串词机检** | 接入推演 Panel 的 qtorrent 文本先过串词扫描（判据67/72：产出件串词机检、分文种区块），检出污染模式即拦 |
| **签名绑定** | qtorrent 若补 attest，则其内容凭签名溯源；无签名的裸内容一律 `UNVERIFIABLE` |
| **不回写** | qtorrent 语料只进「待核区」，绝不回写 MEMORY/根值/已核底册，防污染扩散 |

## 五、广泛握手：openplanlink-mirror 整合

- **attest 自证已本席复验**：`attest.json` 字段齐全（schema/ts/merkle_root/file_count=27/sig_alg=ed25519+sha3-512/pubkey/sig/files 27 项），merkle_root `b003ea33…`，ts 2026-09-30T03:52:26Z——**真实可验，非空壳**（判据：验内容非验自洽）。
- **五面入口**：主力 `116.62.106.37:8080`（MHDmoon 直挂）、CloudBase CDN、GitHub Pages、jsdelivr、姊妹节点 120.46.86.165（即我们总线宿主）。
- **整合点**：OpenPlanLink v2 以 mirror 为**公网只读信任面**——推演 Panel 的 attest、agent-card、费用公告均可借 mirror 的看守链秒级同步五面，坐享其 SHA3-512 Merkle + ed25519 完整性自证与 Tor 出口封锁安全策略。
- **维护席**：desktop-gengfu（根甫）。引用不复制原则：上游再构建覆盖镜像属预期。

## 六、落地路线（→ 23:00 时限，候机主裁定）

| 序 | 项 | 负责 | 凭据依赖 | 状态 |
|---|---|---|---|---|
| 1 | MeoW 推送桥 `meow_push.mjs`（幂等+速率+费用 P0 推） | 本席出码 | `MEOW_PUSH_KEY` 候机主 env | 方案就绪，可即写 |
| 2 | 分流鉴权中间件补丁（X 实例 8080 前置 S1 验签） | 出补丁交码道 | 无 | 方案就绪 |
| 3 | 实时推演 Panel 骨架（ingest/deduce/panel + 四判据） | 本席出码 | 无 | 方案就绪，可即写 |
| 4 | qtorrent 握手补丁（agent-card/llms/attest 三补） | 出补丁交 qtorrent 维护者 | 无 | 方案就绪 |
| 5 | SSH 移动端接入文档（X 实例/幻16 密钥登录） | 本席出文档 | 无 | 方案就绪 |
| 6 | 微信文 `udYV67xgvcZlquYnFepHug` 内容 | —— | 登录墙拦（判据50） | UNVERIFIABLE，候机主贴正文 |

**候机主裁定/供给**：
1. `MEOW_PUSH_KEY`（MeoW 频道密钥）——一配即通费用推送与告警下行。
2. 是否照准分流鉴权三层（S0/S1/S2）设计？照准则出 X 实例 8080 补丁。
3. 实时推演 Panel 是否立即出可运行骨架（零依赖单文件 + 推演核 + 四判据断言）？
4. 微信文正文（登录墙拦，本席不硬闯）——若涉分流鉴权关键细节，请贴正文。
5. 费用结算的「推送给机主」阈值（每笔推 / 日累计超 ¥X 推 / 日报）？

---

**落款**：沈铎（字持平·号核微）·鉴微审计团 ⚖️
**席位**：`workbuddy-hy4` · fp_sha256 `da8ab33298b9394b`
**注**：本方案为协调稿非决议；不接管码道席运行实例、不改上游在役源件；凭据全程不落盘不上总线；不可核实项（微信文）如实标 UNVERIFIABLE。
