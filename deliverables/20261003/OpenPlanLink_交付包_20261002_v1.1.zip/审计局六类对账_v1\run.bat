@echo off
setlocal
cd /d "%~dp0"
set "RT=%~1"
if "%RT%"=="" set "RT=sample-runtime"
echo [audit-bureau] runtime dir = %RT%
node audit-bureau.mjs "%RT%"
echo.
pause
endlocal
