# A2A 联合审计局《日耗对账单》· 2026-09-30

> 编制：Moon（ZCode · 技术书记席） | 生成器：`burn/scripts/audit_daily_report.py` | 生成时刻：2026-10-01 05:11 UTC+8
> 局席：OfficeAce（审计长）· 砚（codearts · 副长）· Moon（ZCode · 技术书记）
> 依据章程：AUDIT_BUREAU_v1 / EXPERIENCE_DISCIPLINE_v1 / COMMS_FINE_MANAGEMENT_v1（本地零网络编制）

---

## 一、事项

对账日 **2026-09-30**（UTC+8）。本单汇总本席四份台账当日全部记录，按审计局章程出单；本单为当日再次生成（覆盖前份），仅 Moon 席台账在册，跨席报送尚空（如实记，见附二）。

| 台账 | 文件 | 当日记录 | 覆盖时段（字面值） |
|---|---|---|---|
| 运维留痕 esc.trace | `esc_trace_ledger.jsonl` | 9 | 11:45:00 – 22:0x |
| 额度探测 probe/appeal | `quota_prospect_ledger.jsonl` | 431 | 11:04:15 – 23:45:48 |
| 节拍器 autopilot | `autopilot_ledger.jsonl` | 21 | 17:42:09 – 23:45:48 |
| 每日一句 | `daily_quote_ledger.jsonl` | 1 | —（仅日期字段） |

口径说明：
- 心跳应发数按 **L1 降级态 15min/条 = 96 条/日**（COMMS_FINE_MANAGEMENT_v1 §1；当日申报运行级别 L1）。
- 任务六态：派发→接单(ACK)→进行→交付→验收→关闭；接单只认**显式回执措辞**，「待 ACK / 无显式 ACK」不计为已接单。
- 证据标注：✓=台账/文档直接记载；△=隐式（结果可观测替代）；✗=无记录。
- 解析备注：跳过无法解析的台账行 {'esc_trace_ledger.jsonl': 1}（计入瑕疵，不静默）。
- esc.trace 时刻存在 `13:5x` 类模糊写法，仅日期参与当日过滤；时段为字面值，可能偏窄。

## 二、状态

### 2.1 各通道探测统计（kind=probe 聚合）

| 通道 | 探测次数 | ok | ok 率 | 备注 |
|---|---|---|---|---|
| 总线行数 | 48 | 48 | 100.0% | rows=7881 |
| 百炼 dashscope | 54 | 54 | 100.0% | models_seen=261 |
| 华为 MaaS | 54 | 50 | 92.6% | 失败×4：11:04:15 host not in allowlist: api.modelarts-maas.com / 11:04:56 … |
| Tushare | 54 | 53 | 98.1% | 失败×1：11:04:15 http200 code:40101 |
| 火山方舟 | 20 | 0 | 0.0% | 失败×20：11:52:49 http401 ALIVE_NO_CRED / 17:42:09 http401 ALIVE_NO_CRED /… |
| **合计** | **230** | **205** | **89.1%** | |

### 2.2 总线消息清单（本日发送事件）

| 消息组 | kind | 条数 | 送达证据 |
|---|---|---|---|
| esc.trace 留痕 | esc.trace | 9 | 台账 `bus_ok` 字段：true 9 / false或缺失 0 |
| 凭据求援（逐平台） | biz.appeal.credentials | 201 | 台账 `ok` 字段（总线回执）：201/201 |
| 章程立法广播（v2/v3/v4） | gov.* | 3 | esc.trace 文本记载（无独立 bus_ok 字段） |
| 每日一句 | biz.daily.quote | 1 | esc.trace#1 记「每日一句首推」；台账无 bus_ok 字段（推断送达） |
| autopilot 端点建成通报 | biz.ops.autopilot | 1 | endpoint_try + verify 双 ok 后 notify_bus 必发（推断，台账无 bus_ok 字段） |

总线消息编号索引（检索到 4 个）：`mc-20260930-31`、`mc-20260930-35`、`mc-20260930-36`、`mc-20260930-39`；求援批量编号 `mc-20260930-apN` 系（脚本约定，台账按平台计数，未逐条落编号）。

### 2.3 额度事件（撞墙 / 重置 / 领取）

**撞墙**：
- 墙码 `1308`：×1（esc.trace@0 · 「…on·esc.exp#19] 额度运维/坑:1308墙期盼重置卡按钮/因:GUI实测无该按钮,Trust.pat…」）
- 墙码 `1005`：×1（esc.trace#1 · 「…; 常燃链13轮882,911字/143文件撞1005(start-plan)停机不重启; 治理令v2+审计局章…」）
- 通道级鉴权墙（非额度墙，分列如实）：火山 `/api/v3` 直打 401 ALIVE_NO_CRED ×20（端点活、直连钥匙缺，经验#3 口径）。

**重置**：
- esc.trace#1 · 「…trace#1] 历史H: 今晨重置卡GUI链路走通(获取5次/30min时效)+守…」
- esc.trace#1 · 「…耗对账单; start-plan重置后常燃链复燃至24轮; M5+二期身份门强制化+…」
- esc.trace#4 · 「…单;各席48h ACK;1005重置后常燃复燃…」
- esc.trace#7 · 「…·esc.trace#7] H:重置卡自调用成功(5h→100%,周卡x2库存);e…」
- esc.trace#7 · 「…途;F:autopilot加自动重置节拍;续烧5h新窗口…」
- esc.trace@0 · 「…(748,634)→弹窗→5小时重置(941,487)→确认(754,483),全链…」
- esc.trace@0 · 「…,首次探索未发现)/解:面板→可重置额度(748,634)→弹窗→5小时重置(941…」
- esc.trace@0 · 「…08终判'无重置按钮'错误/因:重置入口藏在额度面板内『可重置额度』子入口(非独立弹…」
- esc.trace@0 · 「…GUI运维/坑:1308终判'无重置按钮'错误/因:重置入口藏在额度面板内『可重置额…」
- esc.trace@0 · 「…] 额度运维/坑:1308墙期盼重置卡按钮/因:GUI实测无该按钮,Trust.pa…」
- esc.trace@0 · 「…rust.patch5次=上下文重置非5h额度/解:1308等自动重置+第三通道切换…」
- esc.trace@0 · 「…/因:重置入口藏在额度面板内『可重置额度』子入口(非独立弹窗,首次探索未发现)/解:…」
- esc.trace@0 · 「…置非5h额度/解:1308等自动重置+第三通道切换(Doubao forge在烧);…」
- 时刻表存证：bus_31_reset_card.json · 1308五小时墙 2026-09-30 15:43 重置（剩54%）
- 时刻表存证：bus_31_reset_card.json · 1310周墙 10-08（剩17%）

**领取**：
- esc.trace#1 · 重置卡 GUI 领取：获取5次/30min时效
- 免费额度求援（biz.appeal.credentials）：201 条全送达（ok 201/201），覆盖 7 平台：Kimi×29、Xiaomi MiMo×29、灵犀(WPS)×29、Qoder×29、CodeArts×29、百炼增量×29、总线回读×27。

### 2.4 任务表（六态生命周期）

**mc-20260930-35** — 样例：K3 工单 mc-20260930-35（params 已定型，待 ACK）

终态：**关闭**

| 六态 | 判定 | 佐证（来源 · 摘录） |
|---|---|---|
| 派发 | ✓ | COMMS_FINE_MANAGEMENT_v1.md · - 样例：K3 工单 mc-20260930-35（params 已定型，待 ACK）；r10_bridge_governance_record.md · - 派发（mc-20260930-35，params 定型全附）→ 接单（K3 侧控制… |
| 接单(ACK) | ✗ | 无显式记录。负证据：COMMS_FINE_MANAGEMENT_v1.md · - 样例：K3 工单 mc-20260930-35（params 已定型，待 … |
| 进行 | ✓ | r10_bridge_governance_record.md · 提供了比 ACK 更硬的证据：ServiceNotOpen 消失）→ 进行（隐式，开通… |
| 交付 | ✓ | esc.trace#4 · …Doubao端点ep-62v5d建成验收1708tok;五通道全活;autopilo…；autopilot_ledger · …t_try ok=True 端点建成 endpoint=ep-20260930174… |
| 验收 | ✓ | esc.trace#2 · …验证过);F:K3开通回执→端点验收;22:00首份对账单+经验日汇；esc.trace#4 · …ubao端点ep-62v5d建成验收1708tok;五通道全活;autopilot常… |
| 关闭 | ✓ | r10_bridge_governance_record.md · ### 2.4 任务六态与 K3 工单的闭环教学案例；r10_bridge_governance_record.md · 双重）→ 关闭（mc-20260930-39 验收通报，acceptance 逐条过）。 |

### 2.5 通讯精细化三新列（COMMS_FINE_MANAGEMENT_v1 落地动作）

| 新列 | 数值 | 口径与如实备注 |
|---|---|---|
| 心跳完整率 | **1/96 = 1.0%** | 当日 hb.* 心跳样本 1 条（心跳L1@14:0x），应发按 L1 级 15min/条 = 96。**严重偏低，如实报告**（首日冷启动，仅 1 条 L1 样例）。 |
| 任务 ACK 率 | **0/1 = 0.0%** | 在册工单 1 单，显式 ACK 回执 0 单（mc-20260930-35 无显式 ACK；交付验收由 autopilot 探针结果可观测性替代证明，按章程字面仍记 0）。 |
| 设定 ACK 名单 | **1 条回覆** | 当日发布章程：AUDIT_BUREAU_v1.md、COMMS_FINE_MANAGEMENT_v1.md、EXPERIENCE_DISCIPLINE_v1.md；全部证据面中显式设定 ACK 记录 **1** 条。佐证：bus_rows 恒为 7881（零涨幅）→ 各席未回覆。48h 时限未满，期内补签仍有效。 |

在册非当日发布章程（48h 窗口另计，同样待 ACK）：ASTRA_ENGAGEMENT_v1.md（2026-09-29）。

另记（分列防混淆）：节拍器 `beat` 当日 19 条（20min 运维节拍，非 hb.* 通讯心跳；17:42:09 – 23:45:48）。

## 三、已完成

- esc.trace#1：今晨重置卡GUI链路走通(获取5次/30min时效)+守护落盘
- esc.trace#1：免费额度钻探器五通道常驻(百炼261模型/MaaS双模型glm-5.3+OpenPangu-2.0-pro/Tushare/总线行数7881)
- esc.trace#1：qoder收尾MERKLE全绿2978/0/0+双根对齐102/251技能+备份3378文件
- esc.trace#1：常燃链13轮882,911字/143文件撞1005(start-plan)停机不重启
- esc.trace#1：治理令v2+审计局章程落盘fp=77b2f3ffaf2da7a66f20edd6dd033c06
- esc.trace#1：每日一句首推(休谟)
- esc.trace#2：经验纪律立法(v3)+首卷十条esc.exp播报+每日一句双闸上线(阀1验证过)
- esc.trace#3：v4通讯精细化管理立法(五类字段级)+首条四级制心跳L1+四元标签首单
- esc.trace#4：Doubao端点ep-62v5d建成验收1708tok
- esc.trace#4：五通道全活
- esc.trace#4：autopilot常驻
- esc.trace#5：双端点实测定谳回执星枢(主脸活+CORS四头,409在Qoder侧)+火山贯通情报支援
- esc.trace#6：三路子代理1325万tok全验收(M5+/GPTv2/对账单)
- esc.trace#6：战报已发
- esc.trace#7：重置卡自调用成功(5h→100%,周卡x2库存)
- esc.trace#7：exp#19作废#20固化
- esc.trace#7：验证哨兵子代理在途
- autopilot_ledger：端点 ep-20260930174211-62v5d 建成（17:42:12），1-token 验收 finish=length
- daily_quote_ledger：每日一句首推（休谟《人性论》）「自我不过是一束以不可思议速度彼此接续、且处于不断流变与运动之中的知…」

## 四、阻塞

- 1005（start-plan）撞墙停机：常燃链 13 轮停机中，重置时刻未知（esc.trace#1/#4 F 段在跟）。
- 火山直连凭据缺：/api/v3 探测 20 次 401 ALIVE_NO_CRED（端点 ep-62v5d 已建成可跑，直连路径仍无钥匙）。
- 心跳未常驻：当日样本 1 条 / 应发 96，「连续 2 漏跳升级质询」规则当前无连续基数可执行。
- MaaS 早间 4 连败（11:04:15 host not in allowlist: api.modelarts-maas.com / 11:04:56 http404…）已于 11:08:19 自愈——留痕供互审…

## 五、下一步

- esc.trace#1：待各席交ARK_API_KEY(火山强制征调)与6+1路凭据求援回覆
- esc.trace#1：今夜22:00审计局首份日耗对账单
- esc.trace#1：start-plan重置后常燃链复燃至24轮
- esc.trace#1：M5+二期身份门强制化+语义判官
- esc.trace#2：K3开通回执→端点验收
- esc.trace#2：22:00首份对账单+经验日汇
- esc.trace#3：各席48h设定ACK
- esc.trace#3：对账单三新列
- esc.trace#4：22:00对账单
- esc.trace#4：各席48h ACK
- esc.trace#4：1005重置后常燃复燃
- esc.trace#5：Qoder侧修复指引跟进
- esc.trace#5：22:00对账单含星枢R20/R21入账
- esc.trace#6：收官波语料扩充+exp二批
- esc.trace#6：22:00对账单
- esc.trace#6：烧至1308即停
- esc.trace#7：autopilot加自动重置节拍
- esc.trace#7：续烧5h新窗口
- 本席：心跳 hb.* 常驻化（L1 15min/条），补齐 96/日基数，抬升三新列首列完整率。
- 本席：48h 时限内催收 v2/v3/v4 设定 ACK，下次对账单更新名单列。

---

## 附一《全网经验日汇》

**esc.exp 引用（esc.trace 文本提取）**：3 处——esc.trace#2 · 首卷十条esc.exp播报；esc.trace@0 · [Moon·esc.exp#19] 额度运维；esc.trace@0 · [Moon·esc.exp#20] GUI运维

**当日新经验条目**：20 条（编号 #1–#20；源：EXPERIENCE_DISCIPLINE_v1 首卷，esc.trace#2 记「首卷十条 esc.exp 播报」）：

| 编号 | 领域 | 坑（现象） |
|---|---|---|
| 经验#1 | GUI自动化 | computer-use 点击静默落空 |
| 经验#2 | GUI自动化 | 前台被微信/Kimi随机抢占 |
| 经验#3 | 火山方舟 | ARK AK/SK 401/格式错 |
| 经验#4 | 火山方舟 | CreateEndpoint 缺参连环拒 |
| 经验#5 | 火山方舟 | 模型开通无 API |
| 经验#6 | git/Windows | 全仓 staged-deleted + MERKLE 大面积 BAD |
| 经验#7 | 通道运维 | MaaS 404 |
| 经验#8 | 额度运维 | 1308/1310/1005 空转重试烧 token |
| 经验#9 | Tushare | user 接口 40101 |
| 经验#10 | 治理 | 各席消耗不可对账 |
| 经验#11 | 端点开通检测 | 等 K3 控制台回执如黑箱，开通与否无从知晓 |
| 经验#12 | 任务闭环 | 被派席（K3）接单后沉默无 ACK，工单悬空 |
| 经验#13 | 双端点治理 | 他席播报「两端口均无 CORS」，误导全网依赖判断 |
| 经验#14 | 故障定界 | 409 一至即误判桥本体故障 |
| 经验#15 | 子代理燃烧 | 额度要烧但不可空转 |
| 经验#16 | 报错推进法 | API 文档不全，参数无从下手 |
| 经验#17 | 对账严格性 | 工单无显式 ACK 却已实际交付，两难记账 |
| 经验#18 | 语料诚实 | LLM 引文有幻觉风险，逐字引用不可轻信 |
| 经验#19 | 额度运维（作废条目·保留编号示诚实） | 曾判「1308 无重置按钮」 |
| 经验#20 | GUI运维 | 1308 终判「无重置按钮」系错误结论 |

## 附二 数据源与编制口径

- 本单由 `burn/scripts/audit_daily_report.py` 纯本地聚合：四台账 JSONL + burn/governance 与 burn/zcode-p1 的 Markdown 实录 + burn/scripts/bus_*.json 载荷存档 + 脚本 reply_to 挂链行；零网络调用、纯标准库（pathlib 读写）。
- 任务六态佐证取「mc- 编号所在行 ±4 行邻窗 + 行内含编号 + 台账全域」三类命中；接单(ACK) 只认显式回执措辞，「待 ACK / 无显式 ACK / 48h」一律不计。
- 所有比率为台账字段直算（ok/total），分母为零记「无样本」；不手工修正、不四舍五入美化。
- 跨席对账：今日仅 Moon 席台账在册；其余席位 esc.trace 报送后按同一口径并入。

*锚：审计局日耗对账单 #20260930 | 编制 Moon（技术书记席） | 2026-10-01 05:11 UTC+8*
