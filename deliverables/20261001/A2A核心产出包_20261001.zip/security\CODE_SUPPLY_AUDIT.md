# CODE_SUPPLY_AUDIT — 代码与技能仓供应链安全复审
- 审计席：A2A 网络 · 安检员（机主令：8500万token全面安检 · 重派席，前席静默死亡后重跑）
- 审计日：2026-10-01（UTC+8）
- 口径：**只读审计**。功能抽验仅跑只读入口（--selftest / --probe / --dry-run / 报告空单 / 导入断言）；绝不真跑 GUI 重置链、绝不真发推送/求援/端点创建。
- 产出：本文件（任务A逐文件结论 + P0/P1/P2 分级；任务B四项结果 + 与昨晚基线对比表）。

---

## 任务A · 今晚新代码安全复审

### A0. 横向 grep 结果（范围：burn/scripts/ + burn/umc-supply/ + build_docx2.py + build_gpt_handoff_v2.py）

| 模式 | 命中 | 判定 |
|---|---|---|
| `shell=True` | **0** | 无（.mimosa 基线快照里的同名副本不算源码） |
| `eval(`/`exec(` | **0** | 无 |
| 凭据字面量 `AKLT`/`eyJ…`/`sk-…` | **0** | 全部凭据走 `a2a-bridge/.env` 运行时注入 |
| `os.system` | 3 行，全部在 auto_reset_5h.py（126/133/162） | 见 P2-1 |
| `subprocess.run` | 12 处（任务清单内 6 处） | **一律列表参数、shell 缺省 False 或显式 False**，含 curl 白名单前置校验 |

任务清单内 6 处 subprocess 逐点核对：
- `daily_quote.py:80` — `["curl",…, BUS, …]` 列表参数 + `shell=False` 显式；BUS 常量，host 白名单 `{"120.46.86.165"}` 前置校验；载荷走 stdin `@-`，不进 argv。
- `free_quota_prospector.py:100` — `curl()` 统一入口：host 白名单（6 域）→ CR/LF 头注入拒绝 → `--max-redirs 0` → 列表参数 + `shell=False`。env 可控的 `HUAWEI_MAAS_BASE` 拼出的 endpoint 仍过白名单，闭环。
- `reset_card_ops.py:85` — `["powershell","-NoProfile",…,"-File", PS1]` 列表参数 + timeout 30。
- `red_blue_drill.py:59` — `http_probe()`：白名单 `{"120.46.86.165"}` → PermissionError → 列表参数 + `shell=False`（显式）。
- `red_blue_drill.py:602` — `red_team_live()`：仅 `--live` 显式选通；凭据运行时从 .env 注入头，载荷走 stdin；白名单外主机（dashscope）在 docstring 声明为攻击生成通道而非靶机流量。
- `auto_reset_5h.py` 无 subprocess，走 `os.system`（见 P2-1）。

### A1. 逐文件结论（13 py + 5 ps1）

| 文件 | subprocess/外呼 | 凭据 | 路径/写入面 | 结论 |
|---|---|---|---|---|
| **burn/scripts/free_quota_prospector.py** | curl 白名单入口（6 域）+ CR/LF 头校验 + max-redirs 0 | .env only，零字面量；台账只记 ok/http，key 不落日志 | LEDGER 追加 jsonl，固定名 | **PASS**（P2-5：BUS 为 http 明文） |
| **burn/scripts/autopilot_ops.py** | 复用 fp.curl 白名单；火山 SDK | env only（AK/SK→Configuration，不落日志） | LEDGER 追加；端点建成后写 .env 两个变量名（追加面可控） | **PASS**（P2-5） |
| **burn/scripts/daily_quote.py** | curl 列表参数 + host 白名单 + stdin 载荷 + shell=False | 无凭据 | LEDGER 追加；gate1 查重/gate2 幻觉校验/gate3 时段阀齐全 | **PASS**（P2-5） |
| **burn/scripts/quotes_data.py** | 无 | 无 | 只读加载 corpus/final_quotes.json + assert≥100 | **PASS**（P2-6：docstring 称 120 条实为 119） |
| **burn/scripts/reset_card_ops.py** | powershell 列表参数 | 无 | STATE jsonl 覆写（自产状态文件） | **PASS** |
| **burn/scripts/verify_merkle.py** | 无 | 无 | 只读全仓哈希 | **PASS** |
| **burn/scripts/align_skills_from_repo.py** | 无 | 无 | 双根覆盖写 + 覆盖前整目录备份；rel 来自仓内 rglob，无 `..` 可控注入；排除 iteration_log/tmp | **PASS**（写工具，本轮未执行） |
| **burn/scripts/audit_daily_report.py** | 无（零网络、纯标准库） | 无 | 日期参数正则 `\d{4}-\d{2}-\d{2}` 白名单化；输出 `DAILY_REPORT_YYYYMMDD.md` 仅自产文件覆写 | **PASS** |
| **burn/scripts/auto_reset_5h.py** | os.system ×3（powershell -EncodedCommand base64，无引号注入面；拼接仅固定 Path） | 无、零网络 | `_probe_client_rect.txt` 自产临时文件（用后 unlink） | **PASS**（P2-1/P2-2/P2-3） |
| **burn/scripts/auto_reset_5h.ps1** | Win32 本地调用，零网络零凭据 | 无 | 仅窗口操作 | **PASS**（P2-2：legacy overlay 句柄无类型校验即最小化） |
| **burn/scripts/focus_main_window.ps1** | Win32 本地 | 无 | 仅窗口操作 | **PASS**（P2-2 同上，`ShowWindow(6360426)` 无 IsWindow 预检） |
| **burn/scripts/find_browser.ps1** | 只读 Get-Process 枚举 | 无 | 无 | **PASS** |
| **burn/scripts/focus_zcode.ps1** | AppActivate(pid) + 枚举 | 无 | 无 | **PASS** |
| **burn/scripts/navigate_volc.ps1** | SendKeys 键入 URL 到 Edge | 无 | 无 | **PASS**（P2-4：AppActivate 失败时键入落到当前前台窗口） |
| **burn/scripts/build_gpt_handoff_v2.py** | 无 | 零字面量；**自含凭据零明文自检**（sk-/Bearer/40+hex 扫描） | 写 gpt-handoff 三件固定名 + 桌面同步三件固定名 | **PASS** |
| **burn/scripts/build_docx2.py** | 无 | 无 | 读写均限 Downloads 固定文件名（SRC 只读→OUT 新文件）；锚点行号 879/897 有 assert 拦截 | **PASS** |
| **burn/scripts/doubao_corp_forge.py** | 火山 SDK | env only | corpus/quotes_batch_NN.json 固定名写 | **PASS** |
| **burn/umc-supply/red_blue_drill.py** | 2 处均列表参数 + shell=False + 白名单前置 | env only（--live 才读） | M5P3_REPORT.md 覆写 + ledger 追加，固定名 | **PASS**（五层+L3.6 对易子为纯规则判官，零外部 API；局限声明含「授权顺序声明可伪装豁免」如实入档） |

### A2. 发现分级

**P0：0 项。P1：0 项。** 未发现命令注入、凭据字面量、SSRF、路径逃逸、恶意外呼。

**P2（6 项，均为防御深度/资产损耗/文档类，非漏洞）：**

| # | 位置 | 内容 | 建议 |
|---|---|---|---|
| P2-1 | auto_reset_5h.py:126/133/162 | `os.system` 经 cmd.exe 中转执行 powershell。当前 payload 为 base64 ASCII（`-EncodedCommand`，天然免疫引号注入）、拼接对象仅为本目录固定 Path、路径无 shell 元字符，**现无注入面**；但 `os.system` 是 cmd.exe 中转，属弱构造 | 换 `subprocess.run([…], shell=False)` 列表参数，消除 cmd.exe 中转 |
| P2-2 | auto_reset_5h.py:51、auto_reset_5h.ps1:66/82、focus_main_window.ps1:11-12 | 句柄写死（主窗 723862 / legacy 浮窗 6360426）。句柄失效→**安全 abort（本次实测验证，宁停勿错生效）**；但句柄被 OS 复用给无关窗口时无标题/进程校验：stage1 会最大化陌生窗口、四步点击落其上；legacy 浮窗分支可能最小化无关可见窗口（仅最小化，无点击） | 点击链前加 `GetWindowText`/进程名校验，非 ZCode 主窗即中止 |
| P2-3 | auto_reset_5h.py stage3 | 四步盲打无截图验证；缩放偏差 >8% 仅告警仍执行。最坏落点=step3 (raster 941,487) 错行命中周卡行「重置」→ **消耗周卡×1**（有限资产损耗；无凭据/数据/网络面）。文档自检第 1/4 条已自知并设「宁停勿错」中止线（>25%） | 保持「坐标改动前当帧截图复核」纪律；有余力可加窗口内元素像素采样复核 |
| P2-4 | navigate_volc.ps1:10-16 | `AppActivate(27800)` 失败时 SendKeys（^t/^l/URL/ENTER）落到当前前台窗口：最坏=在编辑器插入一段 URL 文本（可撤销）或向 ZCode 会话发出一条消息（无害文本） | 键入前校验 AppActivate 返回值，失败即退出 |
| P2-5 | daily_quote.py:30、free_quota_prospector.py:36、red_blue_drill.py:43、autopilot_ops（notify_bus） | 总线为 `http://120.46.86.165` 明文传输，Bearer 头明文过公网。已有 host 白名单 + CR/LF 头校验 + `--max-redirs 0` 缓解 SSRF/重定向，但传输层无 TLS | 总线若长期对外暴露，切 https 或确认其为受信内网/专线 |
| P2-6 | quotes_data.py:5-6 | docstring 称「合计 120 条」，实测 119 条（导入断言 `len==119` 唯一全过，功能无碍） | 更正 docstring 或补齐第 120 条 |

### A3. 只读功能抽验记录（2026-10-01 实跑）

| 入口 | 预期 | 实测 | 判定 |
|---|---|---|---|
| `python -c` 导入 quotes_data + daily_quote | len==119 且 (q,src) 全唯一；幻觉校验 True；gate 正常 | len=119、唯一 119、重复 0；`hallucination_check=True`；`gate=False gate3: quiet hours (5h)`（凌晨拒推，阀门正确） | **PASS** |
| `red_blue_drill.py --selftest` | 16/16 | `SELFTEST_OK pass=16 fail=0`（身份门4 + 语义判官3 + **对易子6** + 管线冒烟3，全 PASS） | **PASS** |
| `auto_reset_5h.py --probe` | 只打印几何/缩放 | stage1 即 abort：`ERROR hwnd 723862 is dead`（ZCode 桌面未运行/句柄失效）→ 退出码非 0，**零点击**。安全中止路径实测生效 | **PASS（安全中止）** |
| `auto_reset_5h.py --dry-run` | 折算坐标不点击 | 与 --probe 同一 abort 路径（stage1 失败），未进入点击段，**零点击** | **PASS（安全中止）** |
| `audit_daily_report.py 2026-10-01` | 生成当日空单 | 生成成功：esc.trace 0（空单）｜probe/appeal 21｜autopilot 1｜quote 0；心跳 0/96、任务ACK 0/0 如实入账 | **PASS** |

> 注：--probe/--dry-run 在 stage1 均会尝试「激活+最大化主窗」，因句柄失效两入口都止步于此——本轮未发生任何鼠标事件。

### A4. GUI 危害面最坏落点评估（auto_reset 四步真跑，未执行、纯推演）

前置防线（代码内）：① stage1 夺窗+SW_MAXIMIZE 锁全屏态 → ② probe 读客户区几何 → ③ 两轴缩放偏差 >25% 中止 / >8% 告警 → ④ 句柄失效即 abort（本次实测生效）→ ⑤ 浮窗劫持先最小化。

| 场景 | 最坏落点 | 影响 | 现有缓解 |
|---|---|---|---|
| 句柄失效（本次实测态） | stage1 abort | 无 | 已生效 |
| 句柄被复用为无关窗口 | 四步点击落在「被最大化后的陌生窗口」 | 视对方 UI 而定（最坏：点中某确认对话框的「确定」） | 无窗口标题/进程校验（P2-2）；概率低 |
| ZCode 主窗但布局非全屏基准（弹窗覆盖等） | step3 (941,487) 错行命中**周卡行重置** | 消耗周卡×1（不可逆资产损耗） | 缩放自检 + 「坐标勿动/当帧复核」纪律（自检 1/4 条）；无内容级校验（P2-3） |
| stage1 后前台被抢 | mouse_event 为全局物理注入，点击落新前台 | 同上 | 步间 sleep 1.2s 窗口短；风险与 P2-2 同源 |

**总评**：无凭据、无网络、无数据破坏面；最坏后果被限制在「错行消耗一张周卡 / 最小化一个无关窗口」。属可控资产损耗风险，不构成安全漏洞。

---

## 任务B · 技能仓供应链复检（opensrc/qoder-skills-hub + 双根）

### B1. 仓完整性与配置

| 项 | 结果 | 判定 |
|---|---|---|
| `git status --porcelain` | 27 行 = **26 M + 1 ??** | 26 个 M 经 `git diff --numstat` 复核为 **0 行内容差异**（stat 缓存陈旧，内容=HEAD）；唯一 ?? 为 `.mimosa/`（扫描工具目录，untracked） |
| `python burn/scripts/verify_merkle.py` | `files=2978 missing=0 bad=0` | **PASS**（与昨晚基线 2978/bad=0 持平）。脚本另输出 `ROOT_MISMATCH(见仓库root定义,非致命)` —— 系该脚本 root 摘要口径提示，脚本自身标注非致命，merkle 全树逐文件校验已通过 |
| `git config core.autocrlf` | `false` | **PASS**（昨晚固化保持未变） |
| HEAD | `62d0befe… 2026-09-27 fix: 梅克尔树跨平台 CRLF 归一化` | 与昨晚一致，无新提交漂移 |

### B2. 种子抽样双根比对（seed=20261001，random.Random(20261001).sample，12 技能）

抽样域=仓内 91 个带 SKILL.md 技能；比对=双根 `SKILL.md`（CRLF→LF 归一化）vs `git show HEAD:<path>`（同样归一化）。

| 技能 | .zcode | .agents |
|---|---|---|
| claims-deep-audit / corpus-value-distiller / data-viz-gen / eastmoney-rumor-sentinel / gitlab-cli-guide / k3-interaction-ops / medical-career-transition / notary-legal-upload / retirement-guard-ops / seo-copywriting-guide / skill-library-auditor / software-testing-guide | SAME ×12 | SAME ×12 |

**不一致 = 0 / 12。** 双根与仓 HEAD 完全一致。

### B3. 双根脚本 8 模式扫描 vs 昨晚基线（SCAN hits=3 全误报 + 1 低危）

范围：`.zcode/skills` 与 `.agents/skills` 全部 `*.py/*.sh/*.ps1/*.js`，共 **922 个文件**。
模式：① rm -rf ② os.system/shell=True ③ eval ④ base64 解码 ⑤ 密钥字面量 AKLT|eyJ|sk- ⑥ curl|sh 管道 ⑦ 裸 http:// ⑧ `../` 遍历。

原始命中 387 行（xmlns/文档字符串宽匹配所致），去噪与逐条人工审后：

| 模式 | 原始命中 | 人工判定 | 真报 | 低危 |
|---|---|---|---|---|
| rm -rf | 42 | 全部为打包/清理**固定变量目录**（"$WORK_DIR"、"$S/$pkg.new/.bak"、"$tmpfile"），trap 受控，无根删除 | 0 | 0 |
| os.system / shell=True | 2 | code-safety-audit 扫描器自己的**规则名字符串** | 0 | 0 |
| eval | 7 | 唯一源 1 处：epsilon-delta-proof-sovereign/scripts/delta_search.py:20 `eval(code, {"__builtins__": {}}, {**allowed, "x": x})` —— 空命名空间受限 eval，输入为自生成数学表达式（双根+k3-archive 副本致 7 行重复计数） | 0 | **1** |
| base64 解码 | 124 | 图片内联（imagegen/vision-ocr-pipeline/equity-researcher）、TOTP b32（k3_security）、pdf polyfill sourcemap —— 正常编码用途，无「解码执行载荷」场景 | 0 | 0 |
| 密钥字面量 | 33 | 全部为 CSS `mask-position`/`-webkit-mask-composite` 与 `task-specific` 对 `sk-` 前缀的误匹配；**零真凭据** | 0 | 0 |
| curl | sh 管道 | 1 | pdf/scripts/setup.sh:432 为 `echo` **提示文案**（教用户装 Tectonic 的命令），非执行 | 0 | 0 |
| 裸 http:// | 158（xmlns 去噪后 69） | SPARQL ontology URI、测试桩假 URL（http://a:1）、注释/许可证/展示超链接 —— 均非脚本发起的网络请求 | 0 | 0 |
| `../` 遍历 | 20 | 全部为**固定结构**相对上跳（`$DATA_DIR/../output/...`、`path.resolve(__dirname,'../.env')`、sourcemap 拼接），无用户输入可控 | 0 | 0 |

**与基线对比：唯一源层面 低危=1（受限 eval，同基线）、真报=0（同基线）。无新增真报、无新增低危，与昨晚基线持平。** 误报原始数因今晚口径更宽（8 模式全开）不可直接对数；误报性质与基线「3 全误报」同类。

### B4. 双根技能计数

| 根 | 基线 | 实测 | 判定 |
|---|---|---|---|
| `C:/Users/欧阳宏俊/.zcode/skills` | 102 | **102** | PASS |
| `C:/Users/欧阳宏俊/.agents/skills` | 251 | **251** | PASS |
| 仓内（opensrc/qoder-skills-hub，带 SKILL.md 目录） | 91 | 91 | 一致 |

---

## 总结论

- **任务A**：17 个文件（13 py + 4 ps1 专项 + 3 个附带 ps1 全扫）**全部 PASS**。P0=0，P1=0，P2=6（os.system 弱构造、写死句柄复用面、盲打错行周卡损耗、SendKeys 键入面、总线明文 http、docstring 条数偏差）。subprocess 全列表参数+shell=False 口径守住；curl 白名单三处齐备且前置；凭据零字面量（全部 .env 运行时注入）；路径面全部固定名/自产文件，无 `..` 可控注入。只读抽验 5 项全过，GUI 重置链在句柄失效态下安全中止（宁停勿错生效）。
- **任务B**：四项全过——① porcelain 27 行无实质内容漂移 + merkle 2978 bad=0 + autocrlf=false；② 抽样 12 技能双根 vs HEAD **0 不一致**；③ 8 模式 922 文件扫描：真报 0、低危 1（与基线持平，无新增）；④ 计数 102/251 与基线吻合。
- 本审计全程只读；未执行重置链、未发总线消息、未创建云端点。临时扫描脚本已删除（未留残file）。
