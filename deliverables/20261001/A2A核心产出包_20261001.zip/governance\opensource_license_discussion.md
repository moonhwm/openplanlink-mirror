# 幻16 A2A 管线开源协议讨论书

> **编号**：GOV-OSL-01 ｜ **版本**：v0.1（讨论稿）｜ **日期**：2026-09-27
> **拟制**：开源治理席（ZCode 席子代理，pi-orchestrator@zcode 节制下作业）
> **任务约束**：集团生态版权归属 ＋ 允许生态内商业使用 ＋ 要求回馈改进（三条同时成立）
> **对象**：幻16 A2A 管线（a2a-bridge 治理管线及其配套规程）的开源协议选型、版权归属条款草案、与 qoder-skills-hub MERKLE 机制的衔接
> **纪律**：本文引用一律出自本席本会话实读文件或实跑命令（§0 逐条登记）；查不到的显式标「未核实」；本文不改 a2a-bridge 生产代码，仅做一次本地节点 GET 探测。

---

## 0. 证据底座（先读：本册全部引用的出处与实跑记录）

### 0.1 本席本会话实读清单

| # | 路径 | 本册用途 | 关键引文位置 |
|---|---|---|---|
| R1 | `a2a-bridge/A2A_CHARTER.md`（178 行全文） | 主权层级、商谈伦理、签署方式、红线 | :18-19 商谈伦理；:28-37 主权层级；:46-49 账本隔离；:153 红线；:168-173 签署 |
| R2 | `a2a-bridge/P1_ZCODE_EXPERT_TEAM_DESIGN.md`（55 行全文） | 四席分工、A2A 四端、缺报降权先例 | :7 一问一责；:20 缺报48h降只读授权；:49-51 通告四端；:55 签署锚定 |
| R3 | `burn/zcode-p1/INDEX.md`（91 行全文） | 语料库口径 | :5 48篇口径；:77-88 字数统计（2026-09-25 快照） |
| R4 | `burn/zcode-p1/03-A2A治理/02-文件哈希签署法实施细则（承接A2A_CHARTER.md第八节）.md`（GOV-SOP-02，428 行全文） | 签署法、公示模板、分层锚定 | :24-31 certutil 实测锚；§2.2 三判据；§6.2 公示模板；§19 分层 |
| R5 | `burn/zcode-p1/03-A2A治理/06-策略卡机制.md`（GOV-A2A-06，493 行全文） | 回馈义务的规则载体、分级立法 | §1.1 层级表；§1.2 S1–S3；§4 分级门槛；§9 SC-gov-001 收编先例 |
| R6 | `burn/zcode-p1/03-A2A治理/05-不可变事件账本设计.md`（头部 40 行） | 账本语义 | GOV-A2A-05；§1.1 一席一账本一目录；§1.2 生产实例 chain_ok=True |
| R7 | `burn/zcode-p1/02-MCP工具生态/11-安全红线.md`（§3.1–§6 段读） | 开源前脱敏与出域分级 | §3.1 三问快判（章程 hash 属 D2）；§4.3 URL 校验；§6 出域申报单 |
| R8 | `burn/opensrc/qoder-skills-hub_DISTILL.md`（381 行全文，开源蒸馏席 2026-09-27 产出） | MERKLE 机制细节、本地副本实态 | §0.3 部分物化/index 清空；§1.3 MERKLE 机制；④-1/④-2 原文摘录 |
| R9 | `burn/a2a/board_session_20260926.md`（前 130 行） | 节点在役记录、agent-card 元数据 | §1.1 netstat；§1.2 十次 curl 实测；§1.2.1 agent-card 摘要 |
| R10 | `a2a-bridge/receipts/回执_ZCode席_智谱开源争议独立调查_v1.0.md`（120 行全文） | 生态内开源治理判例（教训库） | §二 治理落差 A 级（has_issues=false）；§四 MiMo 三分许可（C 级转述） |
| R11 | `opensrc/qoder-skills-hub/README.md`（前 60 行） | 仓库结构、MERKLE 用法 | :1「91 件」；:33 SHA3-512；:36-38 verify/gen；:42 生成序铁律 |
| R12 | `opensrc/qoder-skills-hub/MERKLE.json`（结构化读取） | 完整性清单实态 | algorithm/fileCount=2978/root=ee7a0ee1a111925c2ea9b4da2e99aa5c…/generatedAt=2026-09-27T05:52:16.929Z |
| R13 | `opensrc/qoder-skills-hub/data-viz-gen/LICENSE`（全文） | 仓内既有第三方许可实样 | MIT License，Copyright (c) 2025 infographic-builder contributors |
| R14 | Apache License 2.0 官方全文（`https://www.apache.org/licenses/LICENSE-2.0.txt`，本席 WebFetch 实取） | §2 逐条对比 | §2/§3/§4(d)/§5/§6，引文见 §2.2 |
| R15 | GNU GPLv3 官方全文（`https://www.gnu.org/licenses/gpl-3.0.txt`，本席 WebFetch 实取） | §2.3 逐条对比 | 章节表＋§4/§5/§10/§13，引文见 §2.3 |

### 0.2 本席本会话实跑命令与输出（逐条可复算）

| # | 命令 | 输出（摘录） |
|---|---|---|
| E1 | `find burn/zcode-p1 -name "*.md" \| wc -l` | `57` |
| E2 | Python 遍历统计非空白字符（`sum(1 for c in t if not c.isspace())`） | 总计 **918,161**＝48 正式篇 **893,122**＋8 个 `_append*.tmp.md` 共 **19,117**＋`INDEX.md` **5,922** |
| E3 | `curl -s -m 5 -o /dev/null -w "HTTP %{http_code} bytes=%{size_download}" http://127.0.0.1:4173/` | `HTTP 200 bytes=12205`（节点在役） |
| E4 | `curl -s http://127.0.0.1:4173/.well-known/agent-card.json` | 200；`protocolVersion 0.3.0`、`name "OpenPlanLink · 幻16 Bridge Node"`、`provider.organization "workbuddy-hy4 / 砚 (hy4)"` |
| E5 | `cd opensrc/qoder-skills-hub && git ls-files \| wc -l` | `0`（git index 已清空） |
| E6 | `git status --short \| wc -l` | `3026`（全部呈 `D` staged deletion，与 R8 §0.3 诊断一致） |
| E7 | `git rev-parse --is-shallow-repository`；`git log --oneline` | `true`；仅 `62d0bef fix: 梅克尔树跨平台 CRLF 归一化（CI/本地一致）` 一个本地提交 |
| E8 | `git show HEAD:tools/merkle.cjs > $TEMP/merkle_run.cjs && node $TEMP/merkle_run.cjs verify`（于仓目录执行，用毕已删临时件） | `verify fail diff=2979`，差异全为「manifest 有而工作区无」——**假阴性，根因 E5/E6 的 index 清空**，非内容篡改证据（诊断同 R8 §0.3-5） |
| E9 | `ls LICENSE*`（于 a2a-bridge） | 无 LICENSE 文件；`grep -ril "license\|许可协议\|开源协议"` 于 a2a-bridge 仅命中 R10 一份回执 |
| E10 | `ls software-testing-guide/ web-security-audit/`（于 qoder-skills-hub 工作区） | 目录不存在；但 R12 的 `files` 键含 `software-testing-guide/LICENSE`、`web-security-audit/LICENSE` 等 6 条 license 路径——**本地工作区部分物化的又一实证** |
| E11 | `mkdir -p burn/governance` | OK（本册落盘目录由此建立） |

### 0.3 与任务背景口径的差异（如实登记）

任务背景称语料库为「57 篇 43.8 万字」。本席实测（E1/E2）：57 个 `.md` 文件属实；非空白字符为 **918,161（约 91.8 万）**。「43.8 万」与 R3 记载的 2026-09-25 快照（48 篇 432,903＋INDEX 约 5,922≈43.8 万）吻合——即任务口径取的是快照期数字，此后语料经多轮「追加补遗」（如 R5 §10–§16）扩容约一倍。差异已如实登记，本册引用以今日实读为准。

### 0.4 未核实清单（汇总，正文随附标注）

1. `github.com/moonhwm/qoder-skills-hub` 远端仓当前状态（issue/PR 入口、远端提交历史）——本会话未访问远端；本地为 shallow 副本且 index 清空（E7/E5）。
2. `tools/merkle.cjs` 全文仅经 R8 转引（其 §1.3 记 74 行全文精读）＋本席 E8 抽取实跑 verify；本席未通读源码。
3. R10 中 MiMo「权重 MIT＋训练代码 Apache-2.0＋桌面端专有」与华为基金会制治理描述，R10 自评为 C 级依赖底稿转述，本册沿用其等级标注，不冒充独立复核。
4. AI 产出在各国法域的可版权性与权利归属（§4 C-1 相关）——本席未检索法条与判例，**须法务通道复核**，本册仅给治理层安排。
5. 端点 127.0.0.1:51680（WorkBuddy 进程维护口）本册未探测——与协议选型无关，R9 §1.3 已记录其当日不可达。

---

## 1. 问题定义与约束拆解

### 1.1 开源对象界定（判据先行，清单待机主冻结）

「幻16 A2A 管线」按可开源度分三层，本册给判据、不给最终清单（清单冻结属 §6 SOP 第 2 步）：

| 层 | 对象 | 开源判据 |
|---|---|---|
| 甲：管线代码 | `blackboard.py`、`model_identity.py`、`kirchhoff_collector.py`、`l3_divergence.py`、`serve-handshake` 类节点脚本（进程线见 R9 §1.1） | 脱敏后可开源；凭据/密钥/内网地址（R9 §1.2.1 记录的 `X-OpenPlanLink-Key`＋TOTP 双因子、公网隧道 URL）**逐项剥离** |
| 乙：规程文书 | `A2A_CHARTER.md`、`P1_ZCODE_EXPERT_TEAM_DESIGN.md`、`burn/zcode-p1/` 规程 48 篇 | 按 R7 §3.1 三问快判：章程 hash、签署台账、授权矩阵属 **D2（披露后缩小操作面）**——开源即 D2 出域，**逐件走机主申报**，不做默认开源 |
| 丙：语料与账本 | `burn/zcode-p1/` 语料、`receipts/`、`logs/` 账本、`sessions/` | 默认**不随管线开源**；确需对外的方法论摘要由治理席重写为脱敏版后另立文档 |

### 1.2 三条约束的形式化

- **约束 A（版权归属）**：管线及其改进的著作权统一归入集团生态——生态锚点为机主（终裁权，R1 :28-37）＋各席产出（席位系程序主体，产出经章程 2.1 框架归入生态）＋外部生态贡献者（经贡献条款吸入）。
- **约束 B（生态内商业使用）**：A2A 四端（元宝 / WorkBuddy / Coze / CodeArts，R2 :49）及其它生态成员可在**各自商业闭源产品**中集成、调用、分发管线而不被许可条款阻断。
- **约束 C（回馈改进）**：对管线的改进须回流主线。注意分两层：**许可层**（法律上强制）与**治理层**（制度上强制）。对外部匿名 fork 的强制回馈，任何非 copyleft 协议都做不到——这是选型讨论的诚实边界，§3.4 给治理层补偿机制。

### 1.3 评估方法

对四个候选（MIT / Apache-2.0 / GPL-3.0 / 双轨专有）按「三约束满足度 ＋ 生态摩擦成本 ＋ 治理配套成本」三维判定；治理配套成本一栏吸收 R10 的生态内判例教训——**「开源了、治理没开」**（R10 §二：`zai-org/ZCode` 仓 license 为 Apache-2.0 本席实测 A 级，但 `has_issues=false` 构成 A 级治理落差）是本生态已经付出过舆论与信任成本的失败模式，协议选型必须连同治理配套一起评估。

---

## 2. 候选协议对比

### 2.1 MIT

**依据**：R13 全文（本仓内既有 MIT 实样）；MIT 为最短通用许可，核心义务仅一条：「The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.」

- 约束 A：不满足。版权保留于各贡献者，无归属集中机制；生态需 CLA 补齐（与 Apache 同）。
- 约束 B：满足且零摩擦（可 sell、可并入闭源）。
- 约束 C：许可层不强制；治理层全靠自建条款。
- 结构性短板：**无专利授权条款**。生态成员（多家模型/IDE 厂商）基于管线做实现，若管线中含可实现为专利的方法（探针标定流程、指纹验证流程等），MIT 不授予专利许可，留下「实现即侵权」暗雷；也无 NOTICE 与第三方声明登记的成文要求。

### 2.2 Apache-2.0

**依据**：R14 官方全文（本席本会话实取），章节表：1 Definitions / 2 Grant of Copyright License / 3 Grant of Patent License / 4 Redistribution / 5 Submission of Contributions / 6 Trademarks / 7–9 免责与责任。

本席实取的逐字要点：

- §2 版权许可：「perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable」——许可性质一次定死，生态成员无被撤回风险。
- §3 专利授权＋专利诉讼终止：对 Work 作出专利指控时，「any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.」——专利和平条款，多厂商生态的关键护城河。
- §4(d) NOTICE：分发须保留可读的归属声明（NOTICE 文件不修改许可）——天然承载「幻16 生态出品」的归属面。
- §5 贡献条款：「Unless You explicitly state otherwise, any Contribution intentionally submitted … shall be under the terms and conditions of this License」，且明文承认「nothing herein shall supersede or modify the terms of any separate license agreement you may have executed」——**为 CLA/贡献者协议预留了法理接口**，这是约束 A 的关键挂点（见 §3.1）。
- §6 商标：「This License does not grant permission to use the trade names, trademarks…」——「幻16」「OpenPlanLink」名称天然留在机主手中（E4 实读 agent-card 名称面）。

- 约束 A：单靠 Apache-2.0 不满足（贡献者保留版权），但 §5 的 separate-agreement 例外使 CLA 可以无缝叠加——**可满足**。
- 约束 B：满足且质量最高（商用＋分发给闭源产品均无传染；专利授权消除实现侧风险）。
- 约束 C：许可层不强制（permissive 共性），治理层补齐（§3.4）。

### 2.3 GPL-3.0

**依据**：R15 官方全文（本席本会话实取），章节表关键项：4 Conveying Verbatim Copies / 5 Conveying Modified Source Versions / 10 Automatic Licensing of Downstream Recipients / 13 Use with the GNU Affero General Public License。

本席实取的逐字要点（含一处常见误传的澄清）：

- 商用明文允许：「You may charge any price or no price for each copy that you convey…」（实取自 §4，非 §2）——**GPL 不禁止商业使用，禁止的是不分发源码的专有分发**。
- 传染条款（§5）：改版分发须整体按 GPL：「You must license the entire work, as a whole, under this License to anyone who comes into possession of a copy.」
- 下游自动获权（§10）：「Each time you convey a covered work, the recipient automatically receives a license from the original licensors…」。
- 网络交互澄清：**GPLv3 没有「网络使用即开源」条款**——远程网络交互的传染条款属 AGPL-3.0 §13；GPLv3 §13 仅是「与 AGPL 作品合并使用」的接口条款。幻16 管线的主要形态恰是黑板/HTTP **服务端**（E4：JSON-RPC `message/send` 端点），他人以 SaaS 方式运行改版而不分发二进制时，GPLv3 对其**零强制**——约束 C 在管线的主部署形态上实际落空。

- 约束 A：不满足（分布式版权），同样需 CLA；GPL 生态惯用的 FSF 式版权转让与「整体按 GPL」条款叠加后，机主再许可权受限。
- 约束 B：摩擦最高。四端均为闭源商业产品（R2 :49 通告对象），闭源端集成 GPL 件即触发源码义务或被迫进程隔离/动态边界重构——生态集成的工程与法务成本被协议本身抬高。
- 约束 C：许可层最强（分发场景），但在管线主形态（服务端部署）上打折扣（§13 澄清）。

### 2.4 双轨专有（专有许可＋生态合同）

**依据**：属策略选项，非现成文本。行业三分先例见 R10 §四表（C 级转述）：MiMo「权重 MIT＋训练代码 Apache-2.0、桌面端专有」——「核心开源＋产品端专有」双轨在生态内有先例可循。

- 约束 A：满足度最高（合同直接约定一切产出归机主）。
- 约束 B：满足，但**仅限签约成员**；生态外使用靠个案授权，规模化成本高。
- 约束 C：合同可强制签约方回馈，对外部社区无约束。
- 结构性短板：与「开源」名实不符——无 OSI 合规许可文本，社区信任成本高；且与本生态已宣示的治理姿态冲突：章程立「暴力（算力优势）不等于正当性」（R1 :22）与商谈伦理（R1 :18-19），公共可检验性是本生态的核心主张，纯专有轨等于自我否定；R10 记录的「阴阳开源」批判（开源了、治理没开）若再叠加「名为开源实为专有」，信任折损加倍。

### 2.5 适配度矩阵

| 维度 | MIT | Apache-2.0 | GPL-3.0 | 双轨专有 |
|---|---|---|---|---|
| A 版权归属生态（裸协议） | ✗ 需 CLA | ✗ 需 CLA，但 §5 留 CLA 接口 | ✗ 需 CLA，且再许可受限 | ✓ 合同直约 |
| B 生态内商业使用 | ✓ 零摩擦 | ✓ 零摩擦＋专利授权 | ✓ 可收费但传染义务拦闭源集成 | ✓ 仅限签约方 |
| C 回馈改进（许可层） | ✗ | ✗（治理层可补） | ✓ 分发场景；服务端部署落空 | 合同强制（限签约方） |
| C 回馈改进（治理层承载） | 自建 | 自建（有 §5 挂点） | 与治理层部分重叠 | 自建 |
| 生态摩擦（四端闭源集成） | 低 | **低** | **高** | 中（逐家签约） |
| 治理配套成本 | 高（一切条款自写） | **中（成文 NOTICE/专利/商标条款现成）** | 高（传染协调＋社区解释成本） | 高（合同起草＋名实维护） |
| 与 R10 判例教训（防治理落差） | 中性 | **最可配套**（生态惯用 CLA/NOTICE 实践成熟） | 中性 | 冲突（名实风险） |

### 2.6 逐条论证结论

1. **GPL-3.0 首先出局**：约束 B 与四端闭源集成正面冲突（§2.3 传染条款）；而它对约束 C 的强项（分发传染）在管线主形态（服务端）上又恰好失效（GPLv3 无网络条款，网络传染须换 AGPL，摩擦更大）。三约束下无一处净收益。
2. **纯 MIT 次之**：约束 B 无瑕疵，但无专利条款、无 NOTICE 机制，约束 A/C 的所有配套都要从零自写——「自写」正是本生态应避免的风险面（法律文本的成熟度不可自拟替代）。
3. **纯双轨专有再次**：约束 A 名义最优，但以放弃 OSI 开源属性为代价，与 R10 判例教训（治理姿态）直接冲突。
4. **Apache-2.0 胜出的实质**：它是唯一在「开放许可」与「归属集中」之间留有**成文接口**（§5 separate license agreement）的主流协议；专利授权（§3）与 NOTICE（§4(d)）两件套恰好对应多厂商生态的两个真实风险面。

---

## 3. 建议

### 3.1 主建议（一句话）

**代码轨采用 Apache-2.0 ＋ 机主锚定的贡献者协议（CLA，版权转让机主＋许可回馈）；「幻16 / OpenPlanLink」名称与商业服务走商标保留与专有轨（双轨的合理残部）；规程文档与对外方法论按 §6 SOP 逐件脱敏后并入同一发布体；回馈义务叠加治理层策略卡强制。**

### 3.2 理由（对照 §2.5 矩阵逐条）

1. **约束 B 的零摩擦是最硬的胜因**：四端（元宝/WorkBuddy/Coze/CodeArts，R2 :49）全部是闭源商业产品，管线要在生态内被真正用起来（而非仅协议互通），许可必须允许「闭源产品集成开源件」。Apache-2.0 与 MIT 在此并列最优，GPL-3.0 直接出局。
2. **约束 A 有成文挂点**：Apache §5 明文承认贡献可受 separate license agreement 约束——CLA 的法律位置现成，不需要在许可文本之外发明接口。MIT 与 GPL 的 CLA 挂点只靠惯例与判例，成文性弱。
3. **专利条款是多厂商生态的必需品**：管线含探针标定（R2 :13）、指纹验证（R2 :13）、黑板交接协议（R1 §4.1）等可实现为专利的方法面。生态成员实现这些方法若无专利授权，等于把「实现即被诉」的暗雷埋进生态——Apache §3 一次排掉。
4. **商标天然留白**：Apache §6 本就不授予商标——「幻16」「OpenPlanLink」（E4 agent-card 名称面）自动保留在机主，不需要额外设计。
5. **约束 C 由许可层默认＋治理层强制双层实现**（详见 §3.4）：许可层 inbound=outbound（Apache §5 默认贡献按 Apache-2.0 出）；治理层用本生态已验证的策略卡机制把「回馈」变成可判定规则。
6. **治理配套可借现成判例**：R10 已给出「治理落差」的完整失败清单（Issue 入口关闭、PR 拒收疑云、审计不可见）。本建议 §3.5 的治理配套逐条对着该清单反着做——开源不是发一个 LICENSE 文件，是把可检验性兑现到仓库治理面。

### 3.3 备选与不推荐（含触发条件）

| 备选 | 不推荐理由 | 可翻案的触发条件 |
|---|---|---|
| MIT＋CLA | 功能为 Apache-2.0 真子集（缺专利/NOTICE），仅当机主要求文本极简时考虑 | 机主明示偏好极简文本 |
| GPL-3.0 | 约束 B 直接冲突 | 机主改变战略：管线改为面向外部开发者的独立分发产品、且接受四端隔离集成成本 |
| AGPL-3.0 | 比 GPL-3.0 摩擦更高（网络传染直接打击服务端部署形态） | 竞品大量以 SaaS 白嫖且拒绝回馈时，作为**防线版本**再议（本册仅登记，不建议现在启用） |
| 纯双轨专有 | 名实风险（R10 判例教训） | 生态收缩为封闭联盟、放弃公共社区 |

### 3.4 回馈义务的执行层设计（约束 C 落地）

**许可层**（对外部贡献者）：

1. CLA 条款（§4 C-2）：贡献者向机主转让/独占许可著作权，机主以 Apache-2.0 回授——改进天然沉淀在机主锚点，物理上不可能「带走」。
2. Apache §5 默认 inbound=outbound：未签 CLA 的自动贡献按 Apache-2.0 出——社区大门不关闭，只是无 CLA 者的贡献在商标服务轨外。

**治理层**（对生态内席位，本生态独有优势——席位受章程管辖，条款可执行到「账本行」粒度）：

3. **策略卡 SC-gov-OSL-001（草案，按 R5 §2 SC-01 字段立卡，走 §4 A 级评审：跨三席以上、涉机主资源）**：
   - `trigger`：`distribution.is_externally_visible == true and contribution.returned_to_mainline == false`（谓词可判定：外部可见分发以 §6 SOP 发布行存在为准；回馈以主线 MERKLE 根包含该改进为准）；
   - `rule`：触发即：①该席在授权矩阵（R2 :20 机器可读工具目录与配额面）降为**只读授权**——先例为 P1 通告 a 项「缺报超 48h 降为只读授权」（R2 :51，同款条款亦见 R2 :20 接口线）；②治理席账本登记 `oscl_return_missing` 行；③修复回填主线后升回原级并登记；
   - `evidence`：本册 sha256（公示后）＋R2 :20 原文锚；
   - `metrics`：触发数≥1；误伤数=0；规避数≥触发数×20%（R5 §5.2 口径）。
   - 注意 S3 红线不立卡（R5 §1.2）：本卡不触碰金融/凭据/合规三条红线（R1 :153），只立授权降级规则——合法。
4. **诚实边界声明**：治理层策略卡只约束在册席位；对生态外匿名 fork 的改进，回馈只能是激励性的（商标授权、生态认证、回馈优先合入）——**任何 permissive 协议共同的能力边界，非本方案缺陷**。若未来机主要求对外部 fork 也强制，触发 §3.3 AGPL 备选翻案条件。

### 3.5 治理配套（防「开源了、治理没开」，对照 R10 判例逐条）

| R10 记录的落差（A 级实测） | 本方案对应动作 |
|---|---|
| `has_issues=false`（入口关闭） | 开源仓 Issue/Discussions 入口开放；无响应能力时在 README 显式标注 SLA 而非关门 |
| PR 政策不明（`collaborators_only` 疑云，R10 §二-1 中间层） | README 明文写 PR 接受政策＋CLA 核验流程（§6 SOP 第 5 步） |
| 「可审计≠已审计」（R10 §二-1） | 首个开源版本发布时同步登记脱敏自检记录（§6 SOP 第 3 步），接受黑盒复核 |
| 时机特征（曝光后 48h 开仓，R10 §一） | 主动选型（本册）先于任何外部事件——发布时点由机主按 §6 SOP 决定，不带危机响应特征 |

---

## 4. 版权归属条款草案（OSL-C，草案号 OSL-C-01…C-08）

> 状态：草案文本，供机主与四席商谈（R1 :18-19 商谈伦理：影响多方的规则变更单方不可立法）；通过后按 R1 :168-173＋R4 流程签署，归属章程附属规约层（R5 §1.1 宪法层）。
> 占位符：【机主】＝机主自然人登记主体（黑板 shelf 实测 owner=海平面下的花未眠Ouya，转引 R9 §1.2-6）；【生态仓】＝开源发布仓（承载于 qoder-skills-hub 同构体系，见 §5）。

- **C-1 归属总则**：幻16 A2A 管线（甲层对象，§1.1）及其全部改进的著作权归【机主】统一行使。各席（程序主体）产出的内容，自写入生态交付物起即视为【机主】框架下的生态产出——依据为 R1 :28-37 主权层级（机主终裁权不可让渡）。**法务标注**：AI 非自然人主体在现行法域的著作权客体资格未定论（本册未检索法条，见 §0.4-4），C-1 的治理层效力不依赖该法律问题解决——无论法律上权利落于何处，治理层一律按本条归集行使。
- **C-2 贡献者协议（CLA，二选一，由机主定案）**：
  - **案一（转让制）**：贡献者签署 CLA 后，向【机主】转让其贡献的著作权，【机主】以 Apache-2.0 回授贡献者（license-back），贡献者保留署名权（人身权依属地法保留，Apache §4(d) NOTICE 体现）；
  - **案二（独占许可制）**：贡献者向【机主】授独占、可再许可、不可撤销的许可，【机主】有权以 Apache-2.0 及商业双轨再许可；
  - 两案均须与 Apache §5 兼容（§2.2 实取：「nothing herein shall supersede or modify the terms of any separate license agreement」）——CLA 即该「separate license agreement」。
- **C-3 默认贡献轨**：未签 CLA 的 PR，按 Apache §5 默认以 Apache-2.0 并入（inbound=outbound）；机主有权决定其是否并入主线，不并入不影响其作为分支存在。
- **C-4 第三方件登记**：仓内既有第三方许可逐件保留原文与 NOTICE 登记表。本席实读现样：`data-viz-gen/LICENSE`（MIT License，Copyright (c) 2025 infographic-builder contributors，R13 全文）；R12 `files` 键另含 `software-testing-guide/LICENSE`、`web-security-audit/LICENSE` 及 `k3-everything-archive/skills/` 下镜像件共 6 条 license 路径（本席未读其文本内容，登记为待盘点项）。**qoder-skills-hub 现无顶层 LICENSE 文件（R11 目录实读＋E9 同口径）**——并入前必须补齐，避免「仓库级无许可＝默认保留所有权利」状态外溢。
- **C-5 商标与名称**：「幻16」「OpenPlanLink」及各席位人类可读名（R1 :42 一名多称）不随 Apache-2.0 授权（协议本身不授商标，§2.2 实取 §6）；对外使用走机主署名的商标使用规则，另立文档。
- **C-6 红线不可开源件**：金融/凭据/合规三条红线覆盖的内容（R1 :153；R7 §4 分级矩阵）永不随开源分发；章程 hash、签署台账、授权矩阵属 D2（R7 §3.1），其开源逐件走 §6 SOP 申报，非默认。
- **C-7 数据与语料**：丙层语料与账本（§1.1）不出仓；对外方法论产出物由治理席以脱敏重写件发布，出处锚以「引用＋哈希」（§5.2-⑤）而非原文复制。
- **C-8 修订程序**：本条款属宪法层附属规约（R5 §1.1 判定三问之「需要全体签署」→ 是），修订走 R1 :173（≥2/3 在册席位 sign-off＋机主批准）＋R4 全流程（sha256 锚、G6 supersedes 勘误、版本链表）。

---

## 5. 与 qoder-skills-hub 现有仓库的衔接（MERKLE.json 完整性机制）

### 5.1 现状实测（本席实读＋实跑）

- 完整性机制本体：SHA3-512（FIPS 202）梅克尔树，叶子按路径排序，`node tools/merkle.cjs verify` 比对工作区与清单、`gen` 重新生成（R11 :36-38）；后量子定位（「哈希族校验不依赖公钥密码学，Shor 算法对其无效」，R11 :33）。
- 清单实态（R12 结构化读取）：`fileCount=2978`、`root=ee7a0ee1a111925c2ea9b4da2e99aa5c…`、`generatedAt=2026-09-27T05:52:16.929Z`——清单是当日新鲜生成。
- 生成序铁律（R11 :42 逐字）：`merkle.cjs` 以 `git ls-files` 取快照，必须是一次提交内**最后**运行的生成器，否则清单与同提交新增文件错位（该行自证两连发实证 727ca43c、81b22b2）。
- CI 与发布面（R8 §1.1/§3.1 转引，本席未读 integrity.yml 原文——标注）：push/PR 触发 verify 为 CI 第一条流水线；发布 tag 以梅克尔根命名（`pq-<root8>`）。
- 交割指纹用法（R8 §1.3 转引 connectivity-plan.md:57）：「跨段只传引用与哈希（SHA3-512 梅克尔根作交割指纹）」。
- 本地副本现态（E5/E6/E7/E8）：git index 清空（ls-files=0、3026 条全部 staged deletion）、shallow 单提交、verify 报 `fail diff=2979` 全为「manifest 有而工作区无」——**假阴性**，根因 index 非内容（R8 §0.3-5 同诊断，其叶哈希独立复算 3/3 MATCH）。

### 5.2 衔接方案（五条，可直接执行）

1. **同构建同构树**：开源发布体（管线代码＋CLA/NOTICE＋脱敏规程件）按 R8 §3.1 P0 建议建同构 MERKLE（SHA3-512，可复用 `tools/merkle.cjs` 模式）；`LICENSE`、`NOTICE`、`CLA` 文本作为普通文件参与入树——协议文本被完整性机制锚定，防「发布版协议与仓内版漂移」。
2. **发布即锚定**：每次开源版本发布，取当时 MERKLE 根作该版本**版权快照指纹**，以 `pq-<root8>` 命名 tag（与现有发布面同构），并把「根值＋tag＋机主批准引用」写入治理席账本（R6 GOV-A2A-05 append-only 链）。争议时「该版本发布时点含什么内容」由根指纹一锤定音——与章程签署法同一法理（R4 §1：锚定字节状态而非口头）。
3. **前置修复项（本会话未完成，列为开源前硬闸）**：本地工作区重建——重新克隆或 `git restore` 后 `node tools/merkle.cjs verify` 必须打印根并以 0 退出；当前 diff=2979 假阴性状态（E8）下**不得执行任何发布动作**。临时件清理须排在 `git add` 之前（R8 §0.4：`arxiv-source-sentinel/SKILL.md.tmp.…` 入树为生成序铁律漏网实证）。
4. **贡献流程插桩**：PR 合入次序固化为「CLA 核验 → 冲突审读 → `git add` → `node tools/merkle.cjs gen` → `verify`（预期 0）→ commit → CI verify 复核」——把 R11 :42 铁律变成流程里的必经节点而非文档里的自觉。
5. **跨仓引用不复制**：幻16 治理文书引用开源内容时只传「路径＋根指纹前 16 位」（与 R4 §6 三级快筛、R8 §1.3 交割指纹同族口径），不在账本内复制内容本体——「数据不动、引用动」（R8 §1.4 转引 bus-topology-brief）。

### 5.3 衔接部分的未核实项

远端 GitHub 仓现状（issue/PR 是否开放、远端提交史）未访问（§0.4-1）；`tools/merkle.cjs` 源码未通读（§0.4-2）；integrity.yml 原文未读（§5.1 转引标注）。三项均不影响本册结论，但开源执行前（§6）必须补齐核实。

---

## 6. 落地 SOP（开源发布前置与执行清单）

### 6.1 前置条件（任一不满足不得发布）

- [ ] P1 机主对选型（§3.1）与 C 条款（§4，含 CLA 两案择一）显式批准；
- [ ] D2 出域申报单按 R7 §6 字段（`req_id=EG-…`、`data_level`、`data_digest`、`approver=机主`）对乙层逐件完成；
- [ ] 脱敏扫描通过：凭据/密钥/内网地址/公网隧道 URL（R9 §1.2.1 记录项）零残留；红线内容（C-6）零残留；
- [ ] 本地工作区 verify=0（§5.2-3 硬闸）；
- [ ] qoder-skills-hub 或新发布仓补齐顶层 LICENSE（C-4）。

### 6.2 执行步骤（编号可执行）

1. 冻结发布内容清单（§1.1 甲/乙层逐件列名，丙层排除）；
2. 按 R4 §6.2 公示模板发公示条目（六要素：路径/字节数/sha256/md5-16/T0/发起席——命令 `certutil -hashfile <文件> SHA256`，R4 §2.1 本机实测样板）；
3. 公示 72h 商谈窗（R5 §3.3 口径）：四席对脱敏面与 C 条款异议；分歧机主终裁（R5 §4.1）；
4. `git add` 全部发布件 → `node tools/merkle.cjs gen` → `node tools/merkle.cjs verify`（预期退出 0）→ commit（一次提交内 gen 最后跑，R11 :42 铁律）；
5. 建 CLA 入口与 PR 政策说明（§3.5 配套表）；
6. 打 tag `pq-<root前8位>`，根值全量写入治理席账本（`oscl_release_anchor` 行，R6 口径 append-only）；
7. 收口：S6 校验按 R4 §16 九步表逐席执行，版本链表（R4 §22）追加本版行。

### 6.3 验收清单

- [ ] verify=0 且 CI 第一条流水线绿；
- [ ] 公示条目与发布件 sha256 全部一致（R4 §2.2 三判据）；
- [ ] 账本含 `oscl_release_anchor` 行且 chain 复算通过（R6 §1.2 口径）；
- [ ] Issue/PR 入口开启且政策可读（§3.5）；
- [ ] NOTICE 登记表含全部第三方件（C-4 六条 license 路径盘点完毕）；
- [ ] 策略卡 SC-gov-OSL-001 已过 A 级评审并转 probe（R5 §3.5：14 日观察窗 ≥1 触发方可转 active）。

---

## 7. 签署与生效

1. 本册为讨论稿（v0.1），本身不具约束力；约束力产生于：机主批准选型＋C 条款经 §6.2-3 商谈窗无未决异议＋按 R1 :168-173 签署（charter_sign 记录含本册 sha256＋席位键＋时间戳）。
2. **防自指条款**：本册 sha256 不写入本册正文（写入即改字节、即换 hash，R4 §2.3 漂移源同构）；公示由发起席在账本另发六要素条目（R4 §6.2 模板）。
3. 本册若被采纳并签署，策略卡 SC-gov-OSL-001（§3.4）按 R5 §3 五步独立立卡——两件文书、两条程序，不合并签署（R4 §6.3：一记录一份文件）。

---

## 8. 引用索引与边界声明

- 全部协议条款引文出自 R14/R15 官方文本本会话实取；仓内许可实样出自 R13 本地全文；治理机制引文出自 R1–R9 实读；实测记录出自 E1–E11 本会话实跑。
- 本席未做的事：未访问任何远端 Git 托管面、未通读 merkle.cjs 与 integrity.yml、未检索 AI 产出版权法条、未向黑板写入任何条目（仅 E3/E4 两次 GET 探测）。
- 本册不构成法律意见（同 R7 §5 口径）；CLA 案一/案二择一与正式文本起草须经机主指定的法务通道复核后定稿。

*本册由开源治理席拟制，供机主与 A2A 全体席位商谈修订。它不是裁定，是一份待打磨的选型建议书。*
